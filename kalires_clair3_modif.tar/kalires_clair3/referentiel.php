<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
affichehead(_s("R�f�rentiel d'analyses") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
entete();

if ($_SESSION["refAnalyse"] == 0) {
	klredir("consultation.php", 3, _s("Vous n'avez pas acc�s � cette page."));
	exit();
}

echo "<H1>Liste des r�f�rentiels d'analyses</H1>";

switch ($patientLogged->niveau) {
case "patient":
	$type = "Patient";
	break;

case "medecin":
	$type = "Medecin";
	break;

case "correspondant":
	$type = "Corres";
	break;

case "preleveur":
	$type = "Preleveur";
	break;
}

$scd = new SoapClientKalires();

if (!is_dir($conf["dataDir"] . "referentiel/" . $patientLogged->niveau)) {
	mkdir($conf["dataDir"] . "referentiel/" . $patientLogged->niveau);
}

$dir = opendir($conf["dataDir"] . "referentiel/" . $patientLogged->niveau . "/");
$arrayNomReferentiel = array();

while ($file = readdir($dir)) {
	$extension = pathinfo($file);

	if ($extension["extension"] == "pdf") {
		$infoFile = explode("_", substr($file, 0, -4));
		$arrayNomReferentiel[$infoFile[1]] = $infoFile[0];
	}
}

$scd->majKaliresReferentiel($type, $arrayNomReferentiel);
$listeRef = $scd->getKaliresReferentiel($type);
if (is_array($listeRef) && (0 < count($listeRef))) {
	echo "<br /><div id=\"div_content\"><table align=center cellpadding=1 cellspacing=1 border=0 width=50% style=\"border:1px solid #ccc;\">\n\t\t\t<tr class=titreBleu>\n\t\t\t\t<td width=60%>" . _s("Titre") . "&nbsp;</td>\n\t\t\t\t<td widrh=40%>" . _s("T�l�chargement") . "&nbsp;</td>\n\t\t\t</tr>";

	foreach ($listeRef as $key => $value ) {
		if (file_exists($conf["dataDir"] . "referentiel/" . $patientLogged->niveau . "/" . $value["modifDate"] . "_" . $value["id"] . ".pdf")) {
			echo "<tr class=\"corps\">\n\t\t\t\t\t<td>" . $value["nom"] . "</td>\n\t\t\t\t\t<td align=center>\n\t\t\t\t\t\t<img src=\"" . imagepath("icopdf2.gif") . "\" title=\"" . _s("Afficher le r�f�rentiel") . "\" onClick=\"makeRemote('dico','pjGet.php?src=referentiel&file=" . $value["modifDate"] . "_" . $value["id"] . ".pdf',800,600);\" class=hand>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>";
		}
	}

	echo "</table></div>";
}
else {
	echo _s("Aucun r�f�rentiel disponible.");
}

affichefoot();

?>
