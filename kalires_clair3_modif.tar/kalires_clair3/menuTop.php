<?php

global $conf;
echo "<font style=\"font-weight:bold;font-size:13px;\">";
echo $laboNom;
echo "</font><br /><span style=\"font-size:9px;\">";
echo $laboAddresse . " " . $laboCodePostal . " " . $laboVille . ($laboTelephone != "" ? "&nbsp;&nbsp;<img src=\"images/tel.gif\">&nbsp;" . $laboTelephone . "" : "");
echo "</span>\n";

?>
