<?php

class apps_kalidom_auth extends RestController
{
	public function get()
	{
		global $sc;

		if (!$this->paramsRequired(array("userCode", "customerCode", "apiVersion", "softVersion"))) {
			return false;
		}

		$tokenTmp = hash("sha256", "po8*" . $this->param("userCode") . "la#4" . date("Y-m-d") . "+5Ak");
		$prelev = $sc->authKaliDom($this->param("userCode"), $tokenTmp);
		if (is_array($prelev) && (0 < count($prelev)) && ($prelev["token"] != "")) {
			$this->response = array("resultCode" => 0, "userCode" => $this->param("userCode"), "token" => $prelev["token"]);
			$this->responseStatus = 200;
			kddebug("Auth OK, Token is : " . $prelev["token"], $this->param("userCode"));
			return true;
		}

		kddebug("Auth error 1 User unknown : " . $this->param("userCode"));
		$this->response = array("resultCode" => "1", "resultMessage" => "User unknown");
		$this->responseStatus = 200;
		return false;
	}

	public function post()
	{
		return NULL;
	}

	public function put()
	{
		return NULL;
	}

	public function delete()
	{
		return NULL;
	}
}


?>
