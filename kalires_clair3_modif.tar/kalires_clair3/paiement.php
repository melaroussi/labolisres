<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
$type = getsroption("interfacePaiement");
if (($type == "CBI") && isset($_GET["token"])) {
	$scd = new SoapClientKalires();
	$params = array("token" => $_GET["token"]);
	$ret = $scd->encaisseDemande($params);

	if ($ret !== false) {
		echo "OK";
		exit();
	}
}
else if ($type !== "CBI") {
	include_once ("include/epaiement/paiementEnLigne.ctrl.php");

	if (paiementEnLigneCtrl::isInterfaceMonoSite($type)) {
		$idSite = $_REQUEST["idSite"];
		$merchantId = getsiteoption("MERCHANT_ID_PAIEMENT", $idSite);
		$secretKey = getsiteoption("SECRET_KEY_PAIEMENT", $idSite);
	}
	else {
		$merchantId = getsroption("merchantIdPaiement");
		$secretKey = getsroption("secretKeyPaiement");
	}

	$paiement = paiementEnLigneCtrl::get($type, $merchantId, $secretKey, getsroption("tpeNumber"), getsroption("testPaiement"));

	if (($ret = $paiement->verifRetour()) === true) {
		$token = $paiement->calculateToken();
		$scd = new SoapClientKalires();
		$params = array("token" => $token);
		$ret = $scd->encaisseDemande($params);
		if (($ret !== false) && ($type != "PAYBOX")) {
			echo "OK";
			exit();
		}
	}

	exit();
}

sleep(10);
header("HTTP/1.0 403 Forbidden");

?>
