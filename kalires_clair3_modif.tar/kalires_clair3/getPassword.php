<?php

include_once ("include/conf.inc.php");
define("KALILAB_SESSION_NO_UPDATE", "1");
include_once ("include/lib.inc.php");
affichehead(getsroption("laboNom"), "", true);
entete();

if ($patientLogged->isAuth()) {
	$patientLogged->logout();
}

$loginPatient = getsroption("kaliResPatient");
$loginMedecin = getsroption("kaliResMedecin") || getsroption("kaliResCorrespondant") || getsroption("kaliResPreleveur");
if ((($sNiveau == "patient") && !$loginPatient) || (($sNiveau == "demandeur") && !$loginMedecin)) {
	klredir("index.php", 5, _s("Redirection en cours ..."));
	affichefoot();
	exit();
}

if ($choix == "changePassword") {
	if (($_SESSION["keyForm"] != "") && ($keyFormForm == $_SESSION["keyForm"])) {
		if ((0 < strlen($sLogin)) && (0 < strlen($sMail))) {
			$sc = new SoapClientKalires();
			$changePassw = $sc->regenPassword($sNiveau, $sLogin, $sMail);

			if ($changePassw->result == "1") {
				$sMsg = "" . _s("Le nouveau mot de passe a bien �t� demand�, vous allez le recevoir par e-mail � l'adresse sp�cifi�e") . "";
				affichemessage($sMsg);
				klredir("index.php", 5, _s("Redirection en cours ..."));
				affichefoot();
				exit();
			}
			else if ($changePassw == "multiAccount") {
				$sMsg = "<font color=red>" . _s("Erreur : veuillez contacter le laboratoire, plusieurs comptes correspondent � vos identifiants.") . "</font>";
			}
			else {
				$sMsg = "<font color=red>" . _s("Erreur : le changement de mot de passe a �chou�") . "</font>";
			}
		}
		else {
			$sMsg = "<font color=red>" . _s("Erreur : il faut saisir votre identifiant et adresse e-mail") . "</font>";
		}
	}
	else {
		$sMsg = "<font color=red>" . _s("Erreur : session incorrecte") . "</font>";
	}
}

unset($_SESSION["keyForm"]);
affichemessage($sMsg);
$keyForm = uniqid(date("YmdHis"));
$_SESSION["keyForm"] = $keyForm;
echo "<form name=principal action=\"getPassword.php\" method=post>";
echo "<input type=hidden name=choix value=\"changePassword\"><input type=\"hidden\" name=\"keyFormForm\" value=\"" . $keyForm . "\"><input type=\"hidden\" name=\"sNiveau\" value=\"" . $sNiveau . "\">";
echo "\t<table class=\"corps\" width=500 align=center cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\">\n\t<tr class=titre><td align=center colspan=2>";
echo _s("Demande de nouveau mot de passe");
echo " :</td></tr>\n\t";
if (($sNiveau == "patient") && (getsroption("passwordPerso") == 0)) {
	echo "\t\t<tr class=corpsFonce><td colspan=2 style=\"font-size:11px;\">";
	echo _s("Votre mot de passe a expir�");
	echo ".</td></tr>\n\t";
}

echo "\t\t<tr class=corpsFonce><td colspan=2 style=\"font-size:11px;\">";
echo _s("Veuillez saisir vos identifiant et adresse e-mail avec lesquels vous �tes identif�s aupr�s du laboratoire. Si vous n'avez pas ces informations, merci de contacter le laboratoire.");
echo "</td></tr>\n\t\t<tr><td align=right>";
echo _s("Identifiant");
echo " : </td><td><input type=\"text\" value=\"\" name=\"sLogin\" autocomplete=\"off\" ></td></tr>\n\t\t<tr><td align=right>";
echo _s("Adresse e-mail");
echo " : </td><td><input type=\"text\" value=\"\" name=\"sMail\" autocomplete=\"off\" ></td></tr>\n\t\t<tr><td align=\"center\" colspan=2><input type=\"submit\" name=\"send\" value=\"";
echo _s("Demander un nouveau mot de passe");
echo "\"></td></tr>\n\t</table>\n";
echo "</form>";
affichefoot();

?>
