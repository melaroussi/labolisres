<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");

// Add responsive styles
$responsiveCSS = <<<EOT
<style>
/* Responsive styles */
@media screen and (max-width: 768px) {
    table {
        width: 100% !important;
        font-size: 14px;
    }
    
    td, th {
        padding: 8px !important;
    }
    
    .corpsFonce {
        white-space: normal !important;
    }
    
    .descr {
        font-size: 12px;
    }
    
    .titreBleu {
        font-size: 14px;
    }
    
    .corps {
        font-size: 14px;
    }
    
    #div_content {
        padding: 10px;
    }
    
    .hand {
        display: block;
        padding: 5px;
    }
    
    .img {
        display: inline-block;
    }
    
    .champPrescription {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    textarea {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    select {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    input[type="text"] {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    .symbole {
        font-size: 12px;
    }
    
    fieldset {
        width: 100% !important;
        margin: 10px 0;
    }
    
    legend {
        font-size: 14px;
    }
    
    .obligatoire {
        font-size: 12px;
    }
    
    .login-form {
        width: 100% !important;
        margin-bottom: 20px;
    }
}

/* Base styles */
table {
    border-collapse: collapse;
    margin: 10px 0;
}

.corpsFonce {
    background-color: #f5f5f5;
}

.descr {
    color: #666;
}

.hand {
    cursor: pointer;
}

.img {
    text-decoration: none;
}

.champPrescription {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

.symbole {
    color: #666;
    font-style: italic;
}

.obligatoire {
    color: #ff0000;
    font-weight: bold;
}

fieldset {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px 0;
}

legend {
    padding: 0 5px;
    font-weight: bold;
}

textarea {
    resize: vertical;
    min-height: 80px;
}

select {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="text"] {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    padding: 8px 15px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
    background-color: #f5f5f5;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #e5e5e5;
}
</style>
EOT;

// Function to override standard affichehead function with responsive meta tag
function customAffichehead($titre, $script, $javascript = false) {
	global $conf;
	global $responsiveCSS;
	
	// Start HTML
	echo "<html><head><title>" . $titre . "</title>";
	
	// Add responsive viewport meta tag
	echo "\n\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">";
	
	// Add favicon
	echo "\n\t<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"" . $conf["baseURL"] . "favico.kalires.ico\" />";
	echo "\n\t<link rel=\"icon\" type=\"image/gif\" href=\"" . $conf["baseURL"] . "images/kalires.gif\" />";
	
	// Add stylesheets
	echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/kalires2.css\">";
	echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/calendar-system.css\">";
	echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "style2.css\">";
	echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/qtip.css\">";
	
	// Add scripts
	echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
	echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/validator.js\" ></script>";
	echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.js\" ></script>";
	echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.plugin.qtip.js\" ></script>";
	echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar.js\"></script>";
	echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar-fr.js\"></script>";
	
	// Add responsive styles
	echo $responsiveCSS;
	
	echo "\n</head><body topmargin=0 leftmargin=0 >";
}

// Use custom responsive head function
customAffichehead(_s("Saisie d'une prescription") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
entete();

if (!$_SESSION["accesPC"]) {
	klredir("consultation.php", 3, "Vous n'avez pas accs cette page.");
	exit();
}

echo "<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/sprintf.js\" ></script>";
echo "<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
echo "<H1>" . _s("Saisie d'une prescription") . "</H1>";

if ($keyFormForm == $_SESSION["keyFormSession"]) {
	if ($_POST["choix"] == "enregistrerPresc") {
		unset($_SESSION["keyFormSession"]);
		$scd = new SoapClientPrescription();
		$data["statusPrescription"] = "saisie";
		$data["kaliresType"] = $patientLogged->niveau;
		$envoiDemande = $scd->envoiDemandePresc($data);

		if (0 < $data["idPrescription"]) {
			if (0 < $envoiDemande) {
				klredir("prescription.php?idPrescription=" . $data["idPrescription"] . "", 3, _s("Prescription enregistr�e"));
			}
			else {
				klredir("listePrescription.php", 3, _s("La presctiption n'a pas pu �tre enregistr�e car elle a d�j� �t� saisie sur KaliSil"));
			}
		}
		else {
			klredir("prescription.php", 3, _s("Prescription enregistr�e"));
		}

		exit();
	}
	else if ($_POST["choix"] == "validerPresc") {
		unset($_SESSION["keyFormSession"]);
		$scd = new SoapClientPrescription();
		$data["statusPrescription"] = "valide";
		$data["kaliresType"] = $patientLogged->niveau;
		$envoiDemande = $scd->envoiDemandePresc($data);

		if (0 < $envoiDemande) {
			klredir("listePrescription.php", 3, _s("Prescription valid�e"));
		}
		else {
			klredir("listePrescription.php", 3, _s("La prescription n'a pas pu �tre valid�e car elle a d�j� �t� saisie sur KaliSil"));
		}

		exit();
	}
}
else {
	if (($_POST["choix"] == "enregistrerPresc") || ($_POST["choix"] == "validerPresc")) {
		affichemessage(_s("Session incorrecte : aucune donn�e enregistr�e"));
	}
}

if (!isset($dataPrescription)) {
	if (isset($_SESSION["dataPrescription"])) {
		$dataPrescription = $_SESSION["dataPrescription"];
	}
	else {
		$scp = new SoapClientPrescription();
		$params = array("idReference" => $patientLogged->id, "idType" => $patientLogged->niveau);
		$dataPrescription = $scp->getDataPrescription($params);
	}
}

echo "<script type=\"text/javascript\">\n\nvar retNum = true;\nvar erreurMessage = \"\";\nvar msgNum =\"\";\nvar isMaroc = ";
echo issroption("typeLabo", "maroc") ? 1 : 0;
echo ";\n\nfunction changeCouleur(box, id) {\n\tif($(box).prop(\"checked\")==true) {\n\t\t$(\"#\"+id).removeClass(\"corpsFonce\").addClass(\"titre\");\n\t} else {\n\t\t$(\"#\"+id).removeClass(\"titre\").addClass(\"corpsFonce\");\n\t}\n}\n\nfunction toHide(nom){\n\tvar ret = true;\n\t$(\"input:checked\").each(function(){\n\t\tif($(this).attr(\"data-code\") && $(this).attr(\"data-code\").indexOf(\",\")>0){\n\t\t\ttabCode = $(this).attr(\"data-code\").split(',');\n\t\t\tif($.inArray(nom, tabCode)>=0){\n\t\t\t\tret = false;\n\t\t\t}\n\t\t}else{\n\t\t\tif($(this).attr(\"data-code\") == nom){\n\t\t\t\tret = false;\n\t\t\t}\n\t\t}\t\n\t});\n\treturn ret;\n}\n\nfunction showTR(nom){\n\n\tvar tabAna = nom.split(\",\");\n\tfor(var i=0 ; i<tabAna.length ; i++){\n\t\t$(\"tr[dataType='data[\"+tabAna[i]+\"]']\").each(function() {\n\t\t\tif($( this ).css(\"display\") == \"none\"){\n\t  \t\t\t$( this ).show();\n\t  \t\t\t$(this).prop('disabled', false);\n\t  \t\t}else{\n\t  \t\t\tif(toHide(tabAna[i]) === true){\n\t\t\t\t\t$( this ).hide();\n\t\t\t\t\t$(this).prop('disabled', true);\n\t\t\t\t}\n\t\t\t}\t\t\n\t\t});\n\t}\n}\n\nfunction checkNum(elm){\n\terreurMessage = \"\";\n\tvar nom = elm.getAttribute(\"nom\");\n\tvar msg = \"- La valeur de \\\"\"+nom+\"\\\" doit �tre num�rique.\\r\\n\";\n\tvar valSaisie = elm.value;\n\t\n\tif(elm.value.length != 0 && !valSaisie.match(/^[<>]?\s?[0-9]+\.?[0-9]*$/g)){\n\t\talert(\"La valeur doit �tre num�rique.\\r\\nCaract�res autoris�s : de 0 � 9, <, >, espace et point.\");\n\t\tif(msgNum.indexOf(msg)){\n\t\t\tmsgNum += msg;\n\t\t}\t\n\t\tretNum = false;\n\t}else{\n\t\tmsgNum = msgNum.replace(msg,\"\") \n\t\tretNum=true;\n\t}\t\n}\n\nvar cleCalcule= '';\n\nfunction verifNumSecu(numSecu) {\n\tcleCalcule= '';\n\tvar cleValidation=97;\n\tvar indiceCorse=6;\n\tnumSecu = numSecu.toUpperCase();\n\t\n\tif (numSecu.length==0) return true;\n\telse {\n    \tif (numSecu.length!=15 && numSecu.length!=14 && numSecu.length!=13) return false;\n    \telse {\n    \t\tnumSecu = numSecu.replace(\"2A\",\"19\");\n    \t\tnumSecu = numSecu.replace(\"2B\",\"18\");\n    \t\tif (!lib_isInt(numSecu)) return false;\n    \t\tvar num = numSecu.substr(0, 13);\n    \t\tvar cle = numSecu.substr(13, 2);\n    \t\ttmp = cleValidation - (num % cleValidation);\n    \t\tcleCalcule= tmp;\n\t\tif (cleCalcule<10) cleCalcule=\"0\"+cleCalcule;\n\n    \t\tif (tmp==cle) return true;\n    \t\telse return false;\n    \t\n    \t}\n\t}\n}\n\nfunction validePrescription(event,leForm){\n\tvar ret = true;\n \tvar erreurAccueil = false;\n \tvar labelNS = \"le num�ro de s�curit� sociale\";\n\terreurMessage = \"\";\n\t\n\tif(isMaroc == 1) {\n\t\tlabelNS = \"le num�ro CIN\";\n\t}\n\t\n\tif(getById(\"numPermanent\").value == \"\" && getById(\"numPatientExterne\").value == \"\" && getById(\"numeroSecu\").value == \"\"){\n\t\terreurMessage += \"- Vous devez saisir le N�KaliSil, l'IPP ou \" + labelNS + \".\\r\\n\";\n\t\tret=false;\n\t}\n\t$('#nom').val($('#inputNom').val());\n\t\n\tif (isMaroc == 0 && getById(\"numeroSecu\").value != \"\") {\n\t\tif (verifNumSecu(getById(\"numeroSecu\").value)===false) {\n\t\t\tif (cleCalcule=='') {\n\t\t\t\terreurMessage += \"- Le num�ro de s�curit� sociale doit contenir 15 caract�res.\\r\\n\";\n\t\t\t\tret=false;\n\t\t\t} else {\n\t\t\t\terreurMessage += \"- Le num�ro de s�curit� sociale est faux (cl� calcul� = \"+cleCalcule+\")\\r\\n\";\n\t\t\t\tret=false;\n\t\t\t}\n\t\t}\n\n\t}\n\t\n\tif(getById(\"nomJeuneFille\").value == \"\" || getById(\"prenom\").value == \"\"){\n\t\terreurMessage += \"- Vous devez saisir le nom et le pr�nom du patient.\\r\\n\";\n\t\tret=false;\n\t}\n\t\n\tif(getById(\"civilite\").value == \"\"){\n\t\terreurMessage += \"- Vous devez choisir la civilit� du patient.\\r\\n\";\n\t\tret=false;\n\t}\n\t\n\tif(getById(\"dateOrdonnance\").value == \"\"){\n\t\terreurMessage += \"- Vous devez saisir la date d'ordonnance.\\r\\n\";\n\t\tret=false;\n\t}\n\t\n\tif (getById(\"rangNaissance\").value != \"\" && !((getById(\"rangNaissance\").value * 1) >= 0)) {\n\t\terreurMessage += \"- Le rang g�mellaire doit �tre un chiffre\";\n\t\tret=false;\n\t}\n\t\n\t$.each($(\"input[name^='data[infoAccueil]']\"), function() {\n\t  if($(this).is(\":visible\") && $(this).data(\"valVide\") == 0 && $(this).val() == \"\"){\n\t  \terreurAccueil = true;\n\t  \tret=false;\n\t  \t$(this).css(\"border\",\"1px solid red\");\n\t  }\n\t});\n\t\n\t$.each($(\"select[name^='data[infoAccueil]']\"), function() {\n\t  if($(this).is(\":visible\") && $(this).data(\"valVide\") == 0 && $(this).val() == \"\"){\n\t  \terreurAccueil = true;\n\t  \tret=false;\n\t  \t$(this).css(\"color\",\"red\");\n\t  }\n\t});\n\t\n\n\terreurMessage += msgNum;\n\tif(erreurAccueil) erreurMessage += \"- Vous devez renseigner les informations accueil obligatoires.\\r\\n\";\n\t\n\tif (erreurMessage != \"\") {\n\t\talert(erreurMessage);\n\t}\n\t\n\tret = ret && retNum && validator_verifie_date(event,getById('dateNaissance'),false,true); \n\n\treturn ret;\n}\n\nfunction completionForm(numIPP) {\n\t$('#imageWait').show(); \n\t$(\"#numPatientExterne\").prop('disabled', true);\n\tif(isMaroc == 1) {\n\t\tlabelNS = \"CIN\";\n\t} else {\n\t\tlabelNS = \"NSS\"\n\t}\n\n\t$.getJSON('prescription.ajax.php',{'numIPP':numIPP}, function(data) {\n\t\tif (data != false) {\n\t\t\tvar strConfirm = \"Ce num�ro IPP correspond aux informations suivantes : \\n\"\n\t\t\t\t\t\t\t +(data[\"civilite\"] != \"\" ? \"- Civilit� : \"+data[\"civilite\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"nom\"] != \"\" ? \"- Nom usuel : \"+data[\"nom\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"nomJeuneFille\"] != \"\" ? \"- Nom de naissance : \"+data[\"nomJeuneFille\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"prenom\"] != \"\" ? \"- Pr�nom : \"+data[\"prenom\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"dateNaissance\"] != \"\" ? \"- Date de naissance : \"+afficheDate(data[\"dateNaissance\"])+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"numSecu\"] != \"\" ? \"- \" + labelNS + \" : \"+data[\"numSecu\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"numPermanent\"] != \"\"  && data[\"numPermanent\"] != null ? \"- Num�ro patient KaliSil : \"+data[\"numPermanent\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +(data[\"rangNaissance\"] != null ? \"- Rang g�mellaire : \"+data[\"rangNaissance\"]+\"\\n\" : \"\")\n\t\t\t\t\t\t\t +\"\\n Confirmez-vous ces informations ?\"\n\t\t\n\t\t\tif (confirm(strConfirm)) {\n\t\t\t\t$(\"#civilite\").val(data[\"civilite\"]);\t\t\t\t\n\t\t\t\t$(\"#inputNom\").val(data[\"nom\"]);\n\t\t\t\tif (data[\"nomJeuneFille\"] != \"\") $(\"#nomJeuneFille\").val(data[\"nomJeuneFille\"]);\n\t\t\t\telse $(\"#nomJeuneFille\").val(data[\"nom\"])\n\t\t\t\t$(\"#prenom\").val(data[\"prenom\"]);\n\t\t\t\t$(\"#dateNaissance\").val(afficheDate(data[\"dateNaissance\"]));\n\t\t\t\t$(\"#rangNaissance\").val(data[\"rangNaissance\"]);\n\t\t\t\t$(\"#numPermanent\").val(data[\"numPermanent\"]);\n\t\t\t\t$(\"#numeroSecu\").val(data[\"numSecu\"]);\n\t\t\t}\n\t\t\t$('#imageWait').hide();\n\t\t\t$(\"#numPatientExterne\").prop('disabled', false);\n\t\t}\n\t\telse {\n\t\t\talert(\"Aucun patient ne correspond � ce num�ro IPP.\");\n\t\t\t$('#imageWait').hide();\t\t\n\t\t\t$(\"#numPatientExterne\").prop('disabled', false);\n\t\t}\n\t});\n}\n\n</script>\n";
$keyForm = uniqid(date("YmdHis"));
$_SESSION["keyFormSession"] = $keyForm;
$dateAdmission = "";
$heureAdmission = "";
$dateOrdonnance = date("d-m-Y");
$ipp = "";
$demandeUrgente = 0;
$numeroAdmission = "";
$numPermanent = "";
$numSecu = "";
$nomNaissance = "";
$dateNaissance = "";
$nomUsuel = "";
$sexe = "";
$prenom = "";
$rangGemellaire = "1";
$commentaire = "";
$analyseSupp = "";
$analysePresc = array();
$infoAcceuil = array();
$typeRequete = "insert";
$statusPrescription = "saisie";
$nomJF = 1;
$datePrelevement = date("d-m-Y");
$heurePrelevement = date("H:i");
$prelevePar = "";
if (isset($idPrescription) && (0 < $idPrescription)) {
	$scd = new SoapClientPrescription();
	$info = $scd->getPrescription(array("idPrescription" => $idPrescription, "idIntervenant" => $patientLogged->id, "typeIntervenant" => $patientLogged->niveau));

	if ($info != false) {
		$infoPrescription = stripslashesrecurse(unserialize($info["donneeHPRIM"]));
		$dateAdmission = $infoPrescription["dateAdmission"];
		$heureAdmission = $infoPrescription["heureAdmission"];
		$dateOrdonnance = $infoPrescription["dateOrdonnance"];
		$ipp = $infoPrescription["numPatientExterne"];
		$civilitePresc = $infoPrescription["civilite"];
		$numeroAdmission = $infoPrescription["numDemandeExterne"];
		$numPermanent = $infoPrescription["numPermanent"];
		$numSecu = $infoPrescription["caisse"]["numeroSecu"];
		$nomNaissance = $infoPrescription["nomJeuneFille"];
		$dateNaissance = $infoPrescription["dateNaissance"];
		$nomUsuel = $infoPrescription["nom"][0];
		$sexe = $infoPrescription["sexe"];
		$demandeUrgente = $infoPrescription["urgent"];
		$prenom = $infoPrescription["nom"][1];
		$rangGemellaire = $infoPrescription["caisse"]["rangNaissance"];
		$commentaire = $infoPrescription["commentaires"]["autre"];
		$analyseSupp = $infoPrescription["commentaires"]["analyseSup"];
		$analysePresc = $infoPrescription["analyses"];
		$infoAcceuil = $infoPrescription["infoAccueil"];
		$typeRequete = "update";
		$statusPrescription = $info["statusPrescription"];
		$idPrescription = $info["id"];
		$datePrelevement = $infoPrescription["datePrelevement"];
		$heurePrelevement = $infoPrescription["heurePrelevement"];
		$prelevePar = $infoPrescription["prelevePar"];
		$nomJF = 0;

		foreach ($dataPrescription["tabCivilite"] as $keyCiv => $valueCiv ) {
			if (is_array($valueCiv) && in_array($civilitePresc, $valueCiv)) {
				$nomJF = $valueCiv["jeuneFille"];
			}
		}
	}
	else {
		klredir("listePrescription.php", 3, _s("Vous n'avez pas le droit d'acc�der � cette prescription"));
		exit();
	}
}

if (isset($_POST["dataPatient"])) {
	$dataPatient = $_POST["dataPatient"];
	$ipp = _secho($dataPatient["ipp"], "sts");
	$numeroAdmission = _secho($dataPatient["numAdm"], "sts");
	$numPermanent = _secho($dataPatient["numPerm"], "sts");
	$numSecu = _secho($dataPatient["numSecu"], "sts");
	$nomNaissance = _secho($dataPatient["nomNaissance"], "sts");
	$dateNaissance = affichedate($dataPatient["dateN"]);
	$nomUsuel = _secho($dataPatient["nomUsuel"], "sts");
	$sexe = _secho($dataPatient["sexe"], "sts");
	$prenom = _secho($dataPatient["prenom"], "sts");
	$rangGemellaire = _secho($dataPatient["rangG"], "sts");
	$civilitePresc = _secho($dataPatient["civ"], "sts");
}

echo "<FORM id=\"prescription\" AUTOCOMPLETE=off NAME=\"principal\" METHOD=\"POST\" ACTION=\"prescription.php\" onSubmit=\"return validePrescription(event,this);\">\n\t<fieldset>\n\t\t<legend>L�gende</legend>\n\t\t<span class=\"symbole obligatoire\">AAA</span>: ";
echo _s("Champs obligatoires");
echo "<br />\n\t\t<span class=\"symbole\">*</span>: ";
echo _s("Au moins un des champs doit �tre renseign�");
echo "<br>\n\t\t<span class=\"symbole\"><img width=14 src=\"";
echo imagepath("icocal.gif");
echo "\" /></span>: ";
echo sprintf(_s("Utilisez %sEspace%s pour remplir les champs de date et heure avec la date actuelle (JJ-MM-AAAA / HH:MM)"), "<span class=\"gras italique\">", "</span>");
echo "\t</fieldset>\n\t<br>\n\t<input id=\"form_choix\" type=\"hidden\" name=\"choix\" value=\"\" />\n\t<input id=\"idPrescripteur\" type=\"hidden\" name=\"data[kaliresReference]\" value=\"";
echo $patientLogged->id;
echo "\" />\n\t<input id=\"typeRequete\" type=\"hidden\" name=\"data[typeRequete]\" value=\"";
echo $typeRequete;
echo "\">\n\t<input id=\"idSiteDest\" type=\"hidden\" name=\"data[idSiteDest]\" value=\"";
echo $dataPrescription["idSiteDest"];
echo "\" />\n\t<input id=\"idPrescription\" type=\"hidden\" name=\"data[idPrescription]\" value=\"";
echo $idPrescription;
echo "\" />\n\t<input id=\"origine\" type=\"hidden\" name=\"data[origine]\" value=\"kalires\" />\n\t<input type=\"hidden\" name=\"keyFormForm\" value=\"";
echo $keyForm;
echo "\">\n\t<table align=\"center\" width=\"670\" cellpadding=1>\n\n\t\t<tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\">";
echo _s("Informations sur l'admission");
echo "</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce\" width='25%'><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Date d'admission au format JJ-MM-AAAA");
echo "\" />";
echo _s("Date d'admission");
echo "</td>\n\t\t\t<td width='25%'>";
echo navgetinputdate(array("id" => "datePrescription", "name" => "data[dateAdmission]", "dataType" => "date", "value" => $dateAdmission, "class" => "champPrescription"), true, false, true, false, true);
echo "</td>\n\t\t\t<td class=\"corpsFonce\" width='25%'><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Heure d'admission au format HH:MM");
echo "\" />";
echo _s("Heure d'admission");
echo "</td>\n\t\t\t<td width='25%'>\n\t\t\t\t<INPUT size=\"10\" class=\"champPrescription\" TYPE=\"text\" id=\"heureAdmission\" NAME=\"data[heureAdmission]\" value=\"";
echo _secho($heureAdmission, "input");
echo "\" onKeyUp=\"if(kKeyCode(event,32)) $(this).val(getHeure())\" onBlur=\"formatSaisieHeure(this,true);\" />\n\t\t\t\t<IMG class=\"hand\" src=\"";
echo imagepath("clock.gif");
echo "\" onClick=\"$('#heureAdmission').val(getHeure());\" \>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4 class=\"titreBleu\"> </td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce obligatoire\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Date de l'ordonnance au format JJ-MM-AAAA");
echo "\" />";
echo _s("Date d'ordonnance");
echo " </td>\n\t\t\t<td>";
echo navgetinputdate(array("id" => "dateOrdonnance", "name" => "data[dateOrdonnance]", "dataType" => "date", "value" => $dateOrdonnance, "class" => "champPrescription"), true, false, true, false, true);
echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Lancer une recherche de patient en appuyant sur la touche Entr�e.");
echo "\" />";
echo _s("N� IPP");
echo " *</td>\n\t\t\t<td><INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"numPatientExterne\" ";
echo $patientLogged->niveau != "preleveur" ? "onKeyUp=\"if(kKeyCode(event,13)) { completionForm(this.value);  }\"" : "";
echo " NAME=\"data[numPatientExterne]\" value=\"";
echo _secho($ipp, "input");
echo "\" /><img name=\"imageWait\" id=\"imageWait\" title=\"";
echo _s("Recherche en cours...");
echo "\" style=\"margin-left:4px; display:none;\" src=\"";
echo imagepath("wait16.gif");
echo "\"></td>\n\t\t</tr>\n\t\t<tr> \n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Demande urgente");
echo "</td>\n\t\t\t<td>\n\t\t\t\t<input type=\"radio\" name=\"data[urgent]\" id=\"urgentOui\" value=\"1\" ";

if ($demandeUrgente == 1) {
	echo "checked=\"checked\"";
}

echo "/><label class=\"corps\" for=\"urgentOui\">";
echo _s("Oui");
echo "</label>\n\t\t\t\t<input type=\"radio\" name=\"data[urgent]\" id=\"urgentNon\" value=\"0\" ";

if ($demandeUrgente == 0) {
	echo "checked=\"checked\"";
}

echo " /><label class=\"corps\" for=\"urgentNon\">";
echo _s("Non");
echo "</label>\n\t\t\t</td>\n\t\t\t<td class=\"corpsFonce\">";
echo _s("N� d'Admission");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" id=\"numDemandeExterne\" NAME=\"data[numDemandeExterne]\" value=\"";
echo _secho($numeroAdmission, "input");
echo "\" /></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4 class=\"titreBleu\"> </td>\n\t\t</tr>\n\t\t<tr> \n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Pr�leveur");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" id=\"prelevePar\" NAME=\"data[prelevePar]\" value=\"";
echo _secho($prelevePar, "input");
echo "\" /></td>\n\t\t\t<td class=\"corpsFonce\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Date du pr�l�vement au format JJ-MM-AAAA");
echo "\" />";
echo _s("Date/heure pr�l�vement");
echo "</td>\n\t\t\t<td width='25%'>\n\t\t\t\t";
echo navgetinputdate(array("id" => "datePrelevement", "name" => "data[datePrelevement]", "dataType" => "date", "value" => $datePrelevement, "class" => "champPrescription"), true, false, true, false, true);
echo "\t\t\t\t<INPUT size=\"6\" class=\"champPrescription\" TYPE=\"text\" id=\"heurePrelevement\" NAME=\"data[heurePrelevement]\" value=\"";
echo _secho($heurePrelevement, "input");
echo "\" onKeyUp=\"if(kKeyCode(event,32)) $(this).val(getHeure())\" onBlur=\"formatSaisieHeure(this,true);\" />\n\t\t\t\t<IMG class=\"hand\" src=\"";
echo imagepath("clock.gif");
echo "\" onClick=\"$('#heurePrelevement').val(getHeure());\" \>\t\t\t\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4><br /></td>\n\t\t</tr>\n\t\t<tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\">";
echo _s("Informations sur le patient");
echo "</td>\n\t\t</tr>\t\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce obligatoire\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Date de naissance au format JJ-MM-AAAA");
echo "\" />";
echo _s("Date de naissance");
echo "</td>\n\t\t\t<td>";
echo navgetinputdate(array("id" => "dateNaissance", "name" => "data[dateNaissance]", "dataType" => "date", "class" => "champPrescription", "value" => $dateNaissance), true, false, true, false, true);
echo "</td>\n\t\t\t<td class=\"corpsFonce obligatoire\" align=\"right\">";
echo _s("Civilit�");
echo "</td>\n\t\t\t<td>\n\t\t\t<select id=\"civilite\" class=\"champPrescription\" name=\"data[civilite]\" style=\"padding:0px;margin:0px;\">\n\t\t\t\t\t<option value=\"\" selected=\"selected\">(";
echo _s("S�lectionnez");
echo ")</option>\n\t\t\t\t";

foreach ($dataPrescription["tabCivilite"] as $civilite ) {
	$selectedCiv = "";

	if ($civilite["civilite"] == $civilitePresc) {
		$selectedCiv = "selected=\"selected\"";
	}

	echo "<option value=\"" . $civilite["civilite"] . "\" sexe=\"" . $civilite["sexe"] . "\" nomJF=\"" . $civilite["jeuneFille"] . "\" " . $selectedCiv . ">" . $civilite["civilite"] . ($civilite["sexe"] != "" ? " (" . $civilite["sexe"] . ")" : "") . "</option>";
}

echo "\t\t\t\t</select>\n\t\t\t\t<input type=\"hidden\" id=\"sexe\" name=\"data[sexe]\" value=\"";
echo _secho($sexe, "input");
echo "\" />\n\t\t\t</td>\t\n\t\t\t\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce obligatoire\">";
echo _s("Nom de naissance");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"nomJeuneFille\" NAME=\"data[nomJeuneFille]\" value=\"";
echo _secho($nomNaissance, "input");
echo "\" maxlength=\"50\" /></td>\n\t\t\t<td class=\"corpsFonce obligatoire\">";
echo _s("Pr�nom");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"prenom\" NAME=\"data[nom][1]\" value=\"";
echo _secho($prenom, "input");
echo "\" maxlength=\"40\" /></td>\t\t\t\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("� saisir si diff�rent du nom de naissance");
echo "\" />";
echo _s("Nom usuel");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"inputNom\" value=\"";
echo _secho($nomUsuel, "input");
echo "\" ";
echo $nomJF == 0 ? "disabled" : "";
echo " maxlength=\"50\" />\n\t\t\t\t<INPUT size=\"14\" class=\"champPrescription\" TYPE=\"hidden\" id=\"nom\" NAME=\"data[nom][0]\" value=\"";
echo _secho($nomUsuel, "input");
echo "\" maxlength=\"50\" />\n\t\t\t</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Rang de naissance du patient dans le cas de naissances multiples. Exemple, pour des jumeaux : renseigner 2 pour le deuxi�me n�.");
echo "\" />";
echo _s("Rang g�mellaire");
echo "</td>\n\t\t\t<td><INPUT size=\"3\" class=\"champPrescription\" TYPE=\"text\" id=\"rangNaissance\" NAME=\"data[caisse][rangNaissance]\" value=\"";
echo _secho($rangGemellaire, "input");
echo "\" maxlength=\"1\" /></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce\" align=\"right\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Num�ro du patient dans KaliSil");
echo "\" />";
echo _s("N� Patient KaliSil");
echo " *</td>\n\t\t\t<td><INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"numPermanent\" NAME=\"data[numPermanent]\" value=\"";
echo _secho($numPermanent, "input");
echo "\" /></td>\n\t\t\t";

if (issroption("typeLabo", "maroc")) {
	$recupCle = "";
	$labelNumSecu = _s("N� CIN");
}
else {
	$recupCle = "if (!verifNumSecu(this.value)) { if(cleCalcule == '') { alert('" . _s("Votre num�ro de s�curit� sociale est faux\n\nImpossible de calculer la cl�", "javascript") . "'); } else { if(confirm('" . _s("Votre num�ro de s�curit� sociale est faux", "javascript") . " (cl� calcul�e:'+cleCalcule+')" . _s("Voulez-vous r�cup�rer la cl� calcul�e ?", "javascript") . "')) this.value=this.value.substring(0,13)+cleCalcule; } }";
	$labelNumSecu = _s("N� de S�curit� Sociale");
}

echo "\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo $labelNumSecu;
echo " *</td>\n\t\t\t<td>\n\t\t\t<INPUT size=\"14\" class=\"champPrescription\" TYPE=\"text\" id=\"numeroSecu\" NAME=\"data[caisse][numeroSecu]\" value=\"";
echo _secho($numSecu, "input");
echo "\" maxlength=\"15\" onBlur=\"";
echo $recupCle;
echo "\"/>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4><br></td>\n\t\t</tr>\n\t";

if (0 < count($dataPrescription["tabAnalyses"])) {
	echo "\t\t<tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\">";
	echo _s("Analyses");
	echo "</td>\n\t\t</tr>\n\t</table>\n\t<table align=\"center\" width=\"670\">\n\t";
	$nombreColonnes = 4;
	$i = 0;
	$nbAnalyses = 0;
	$longueurTronquer = 20;
	$analyseDejaFaite = array();
	$listeCodesPrescription = listecodeprescription($analysePresc);
	$infoAControle = array();

	foreach ($dataPrescription["tabAnalyses"] as $chapitre ) {
		foreach ($chapitre as $code => $analyse ) {
			if (!is_array($analyse)) {
				if (0 < $i) {
					while ($i < $nombreColonnes) {
						echo "<td class=\"corpsFonce\"></td>";
						$i++;
					}

					echo "</tr>";
				}

				echo "<tr class=\"soustitre descr\">\n\t\t\t\t\t\t\t\t<td colspan=4>" . $chapitre["nomChapitre"] . "</td>\n\t\t\t\t\t\t\t</tr><tr>";
				$i = 0;
			}
			else {
				$champs = array();
				$bonusTitle = "";

				if (isset($analyse["groupe"])) {
					$bonusTitle = "\nTubes : " . $analyse["listeTube"];
				}

				if ($i == $nombreColonnes) {
					echo "</tr><tr>";
					$i = 0;
				}

				$selectedAnalysePres = "";
				$classTdSelected = "corpsFonce";
				if (is_array($listeCodesPrescription) && (0 < count($listeCodesPrescription))) {
					if (in_array($code, $listeCodesPrescription)) {
						$selectedAnalysePres = "checked=\"checked\"";
						$classTdSelected = "titre";
					}
				}

				if (is_array($analyse["infoAccueil"])) {
					foreach ($analyse["infoAccueil"] as $tabAna ) {
						$champs[$tabAna["nomAnalyse"]] = "\"" . $tabAna["nomAnalyse"] . "\"";
					}
				}

				if ($oldCode == "") {
					$oldCode = $code;
				}

				if (isset($analyse["infoAccueil"])) {
					echo "<td width=\"" . (100 / $nombreColonnes) . "%\" class=\"" . $classTdSelected . "\" id=\"" . $code . "_" . $nbAnalyses . "\"><label class=\"hand\" style=\"width:100%;display:inline-block;\" title=\"" . $analyse["nom"] . $bonusTitle . "\" ><input type=\"checkbox\" name=\"data[analyses][][actes][]\" data-code=\"" . implode(",", array_keys($champs)) . "\" onclick='changeCouleur(this, \"" . $code . "_" . $nbAnalyses . "\");showTR(\"" . implode(",", array_keys($champs)) . "\");' value=\"" . $code . "\"  " . $selectedAnalysePres . "/>" . tronquer($analyse["nom"], $longueurTronquer) . "</label></td>";
					$countTab = true;

					foreach ($analyse["infoAccueil"] as $data ) {
						$data = stripslashesrecurse($data);
						$span = "";
						if ($countTab && !isset($analyse["groupe"])) {
							$span = "<td rowSpan=" . count($analyse["infoAccueil"]) . " valign=\"top\" class=\"corpsFonce\">" . $data["nomAnalyse"] . "</td>";
							$countTab = false;
						}
						else if (isset($analyse["groupe"])) {
							$span = "<td class=\"corpsFonce\">" . $data["nomAnalyse"] . "</td>";
						}
						else {
							$span = "";
						}

						$infoAcceuilPresent = false;
						$displayInfoAcceuil = "style=\"display:none;\" disabled=\"disabled\"";
						$valueInfoAcceuil = "";

						if (isset($data["valeurDefaut"])) {
							$valueInfoAcceuil = $data["valeurDefaut"];
							$infoAcceuilPresent = true;
						}

						if (is_array($infoAcceuil) && array_key_exists($data["id"], $infoAcceuil)) {
							$infoAcceuilPresent = true;
							$displayInfoAcceuil = "style=\"display:block;\"";
							$valueInfoAcceuil = $infoAcceuil[$data["id"]];
						}

						if ($data["valeurVideAutorise"] == 0) {
							$classObligatoire = "obligatoire";
						}
						else {
							$classObligatoire = "";
						}

						if (($code == $oldCode) || (($code != $oldCode) && !in_array($data["nomAnalyse"], $analyseDejaFaite))) {
							switch ($data["type"]) {
							case "texteCodifie":
							case "texte":
								if ((($data["type"] == "texte") || ($data["type"] == "texteCodifie")) && (0 < count($data["texteCodifie"]))) {
									$str = "<tr  " . $displayInfoAcceuil . " class=\"data[" . $code . "]\" dataType=\"data[" . $data["nomAnalyse"] . "]\" >" . $span . "<td class=\"corpsFonce $classObligatoire\">" . $data["nom"] . "</td><td><select data-val-vide=\"" . $data["valeurVideAutorise"] . "\" id=\"" . $data["id"] . "\" NAME=\"data[infoAccueil][" . $data["id"] . "]\" style=\"width:200px\" class=\"champPrescription\" >";
									$str .= "<option selected=\"selected\" value=\"\">Choisissez une valeur</option>";

									foreach ($data["texteCodifie"] as $textCodifie ) {
										$selectedTexte = "";
										if (($infoAcceuilPresent === true) && ($textCodifie == $valueInfoAcceuil)) {
											$selectedTexte = "selected=\"selected\"";
										}

										$str .= "<option " . $selectedTexte . ">" . $textCodifie . "</option>";
									}

									$str .= "</select></td></tr>";
									$input[] = $str;
								}
								else {
									$input[] = "<tr " . $displayInfoAcceuil . " class=\"data[" . $code . "]\" dataType=\"data[" . $data["nomAnalyse"] . "]\"  >" . $span . "<td class=\"corpsFonce $classObligatoire\">" . $data["nom"] . "</td>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td><input data-val-vide=\"" . $data["valeurVideAutorise"] . "\" size=\"25\" type=\"text\" id=\"" . $data["id"] . "\" NAME=\"data[infoAccueil][" . $data["id"] . "]\" value=\"" . _secho($valueInfoAcceuil, "input") . "\"/>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td></tr>";
								}

								break;

							case "date":
								$input[] = "<tr " . $displayInfoAcceuil . " class=\"data[" . $code . "]\"  dataType=\"data[" . $data["nomAnalyse"] . "]\" >" . $span . "<td class=\"corpsFonce $classObligatoire\">" . $data["nom"] . "</td><td>" . navgetinputdate(array("id" => $data["id"], "name" => "data[infoAccueil][" . $data["id"] . "]", "dataType" => "date", "value" => $valueInfoAcceuil, "data-val-vide" => $data["valeurVideAutorise"]), true, false, true, false, true) . "</td></tr>";
								break;

							case "heure":
								$input[] = "<tr " . $displayInfoAcceuil . " class=\"data[" . $code . "]\" dataType=\"data[" . $data["nomAnalyse"] . "]\" >" . $span . "<td class=\"corpsFonce $classObligatoire\">" . $data["nom"] . "</td>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<td><INPUT data-val-vide=\"" . $data["valeurVideAutorise"] . "\"  size=\"8\" TYPE=\"text\" id=\"" . $data["id"] . "\" NAME=\"data[infoAccueil][" . $data["id"] . "]\"  value=\"" . _secho($valueInfoAcceuil, "input") . "\" onKeyUp=\"if(kKeyCode(event,32)) ajouteHeure(this)\" onBlur=\"formatSaisieHeure(this,true);\" />\n\t\t\t\t\t\t\t\t\t\t\t\t\t<IMG class=\"hand\" src=" . imagepath("clock.gif") . " onClick=\"$('#" . $data["id"] . "').val(getHeure());\" \>\n\t\t\t\t\t\t\t\t\t\t\t\t\t</td></tr>";
								break;

							case "numerique":
								$input[] = "<tr " . $displayInfoAcceuil . " class=\"data[" . $code . "]\" dataType=\"data[" . $data["nomAnalyse"] . "]\" >" . $span . "<td class=\"corpsFonce $classObligatoire\">" . $data["nom"] . "</td><td class=\"champPrescription\"><input data-val-vide=\"" . $data["valeurVideAutorise"] . "\" size=\"30\" type=\"text\" NAME=\"data[infoAccueil][" . $data["id"] . "]\" id=\"" . $data["id"] . "\" nom=\"" . $data["nom"] . "\" value=\"" . _secho($valueInfoAcceuil, "input") . "\" onblur=\"checkNum(this);\" />&nbsp;" . $data["unite"] . "</td></tr>";
								break;
							}

							$analyseDejaFaite[$data["id"]] = $data["nomAnalyse"];
							$oldCode = $code;
						}
					}
				}
				else {
					echo "<td width=\"" . (100 / $nombreColonnes) . "%\" class=\"" . $classTdSelected . "\" id=\"" . $code . "_" . $nbAnalyses . "\">\n\t\t\t\t\t\t\t\t<label class=\"hand\" style=\"width:100%;display:inline-block;\" title=\"" . $analyse["nom"] . $bonusTitle . "\" >\n\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" name=\"data[analyses][][actes][]\" onclick='changeCouleur(this, \"" . $code . "_" . $nbAnalyses . "\");' value=\"" . $code . "\" " . $selectedAnalysePres . "/>" . tronquer($code . " - " . $analyse["nom"], $longueurTronquer) . "\n\t\t\t\t\t\t\t\t</label>\n\t\t\t\t\t\t\t</td>";
				}

				$i++;
				$nbAnalyses++;
			}
		}
	}

	if (0 < $i) {
		while ($i < $nombreColonnes) {
			echo "<td class=\"corpsFonce\"></td>";
			$i++;
		}

		echo "</tr>";
	}

	echo "\t\t</tr>\n\t";
}

echo "\t</table>\n\t";

if (0 < count($input)) {
	echo "<table align=\"center\" width=\"670\" id='infosAccueil'><tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\"> </td>\n\t\t</tr>";

	for ($i = 0; $i < count($input); $i++) {
		echo $input[$i];
	}

	echo "</table>";
}

echo "\t<table align=\"center\" width='670'>\n\t\t<tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\"> </td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Renseignez ici les analyses souhait�es qui ne figurent pas dans la liste ci-dessus.");
echo "\" />";
echo _s("Analyses suppl�mentaires");
echo "</td>\n\t\t\t<td colspan=\"3\"><textarea cols=35 rows=4 class=\"champPrescription\" id=\"analyseSup\" NAME=\"data[commentaires][analyseSup]\">";
echo _secho($analyseSupp, "input");
echo "</textarea></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4><br></td>\n\t\t</tr>\t\t\n\t\t<tr>\t\n\t\t\t<td colspan=4 class=\"titreBleu\">";
echo _s("Divers");
echo "</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td class=\"corpsFonce\"><img src=\"";
echo imagepath("help.gif");
echo "\" style=\"float: right;\" title=\"";
echo _s("Renseignements, pr�cisions, autres, ...");
echo "\" />";
echo _s("Commentaire");
echo "</td>\n\t\t\t<td colspan=\"3\"><textarea cols=35 rows=4 class=\"champPrescription\" id=\"commentaire\" NAME=\"data[commentaires][autre]\" >";
echo _secho($commentaire, "input");
echo "</textarea></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=4><br></td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=\"4\" style=\"text-align:center;\">\n\t\t\t\t";

if ($statusPrescription == "saisie") {
	echo "\t\t\t\t\t<INPUT TYPE=\"submit\" VALUE=\"";
	echo _s("Enregistrer la prescription");
	echo "\" onClick=\"document.getElementById('form_choix').value='enregistrerPresc'\"/>\n\t\t\t\t\t<INPUT TYPE=\"submit\" VALUE=\"";
	echo _s("Valider la prescription");
	echo "\" onClick=\"document.getElementById('form_choix').value='validerPresc'\"/>\n\t\t\t\t";
}

echo "\t\t\t</td>\n\t\t</tr>\n\t</table>\n\n</FORM>\n<script type=\"text/javascript\">\n\n $('#prescription').bind('keypress keydown keyup', function(e){\n       if(e.keyCode == 13) { e.preventDefault(); }\n});\n\n$(document).ready(function(){\n\t$(\"#civilite\").change(function(){\n\t\tvar sexe = $(\"option:selected\",this).attr(\"sexe\");\n\t\tif(sexe != \"\" && sexe != \"U\" && sexe != \"F\" && sexe != \"M\") sexe = \"\";\n\t\t$(\"#sexe\").val(sexe);\n\t\tvar nomJF = $(\"option:selected\",this).attr(\"nomJF\");\n\t\tif(nomJF == 0){\n\t\t\t$(\"#inputNom\").prop('disabled', true);\n\t\t\t$(\"#inputNom\").val($(\"#nomJeuneFille\").val());\n\t\t\t$(\"#nom\").val($(\"#nomJeuneFille\").val());\n\t\t} else {\n\t\t\t$(\"#inputNom\").prop('disabled', false);\n\t\t}\n\n\t});\n});\n</script>\n";
affichefoot();

?>
