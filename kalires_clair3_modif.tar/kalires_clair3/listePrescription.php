<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");

// Add responsive styles
$responsiveCSS = <<<EOT
<style>
/* Responsive styles */
@media screen and (max-width: 768px) {
    table {
        width: 100% !important;
        font-size: 14px;
    }
    
    td, th {
        padding: 8px !important;
    }
    
    .corpsFonce {
        white-space: normal !important;
    }
    
    .descr {
        font-size: 12px;
    }
    
    .titreBleu {
        font-size: 14px;
    }
    
    .corps {
        font-size: 14px;
    }
    
    #div_content {
        padding: 10px;
    }
    
    .hand {
        display: block;
        padding: 5px;
    }
    
    .img {
        display: inline-block;
    }
    
    .champPrescription {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    textarea {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    select {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    input[type="text"] {
        width: 100% !important;
        max-width: 100% !important;
    }
    
    .symbole {
        font-size: 12px;
    }
    
    fieldset {
        width: 100% !important;
        margin: 10px 0;
    }
    
    legend {
        font-size: 14px;
    }
    
    .obligatoire {
        font-size: 12px;
    }
    
    .login-form {
        width: 100% !important;
        margin-bottom: 20px;
    }
    
    .sousTitrePC {
        font-size: 12px;
    }
    
    .titre {
        font-size: 14px;
    }
    
    .descrFonce {
        font-size: 12px;
    }
    
    .qtipOn {
        font-size: 12px;
    }
    
    .defaultCursor {
        font-size: 12px;
    }
    
    .nobr {
        white-space: normal !important;
    }
    
    #div_wait {
        padding: 20px;
    }
}

/* Base styles */
table {
    border-collapse: collapse;
    margin: 10px 0;
}

.corpsFonce {
    background-color: #f5f5f5;
}

.descr {
    color: #666;
}

.hand {
    cursor: pointer;
}

.img {
    text-decoration: none;
}

.champPrescription {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

.symbole {
    color: #666;
    font-style: italic;
}

.obligatoire {
    color: #ff0000;
    font-weight: bold;
}

fieldset {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px 0;
}

legend {
    padding: 0 5px;
    font-weight: bold;
}

textarea {
    resize: vertical;
    min-height: 80px;
}

select {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="text"] {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

input[type="submit"] {
    padding: 8px 15px;
    margin: 5px;
    border: 1px solid #ccc;
    border-radius: 3px;
    background-color: #f5f5f5;
    cursor: pointer;
}

input[type="submit"]:hover {
    background-color: #e5e5e5;
}

.sousTitrePC {
    background-color: #e5e5e5;
    font-weight: bold;
}

.titre {
    background-color: #d5d5d5;
    font-weight: bold;
}

.descrFonce {
    color: #666;
    font-style: italic;
}

.qtipOn {
    cursor: help;
}

.defaultCursor {
    cursor: default;
}

#div_wait {
    text-align: center;
    padding: 20px;
}
</style>
EOT;

// Function to override standard affichehead function with responsive meta tag
function customAffichehead($titre, $script, $javascript = false) {
    global $conf;
    global $responsiveCSS;
    
    // Start HTML
    echo "<html><head><title>" . $titre . "</title>";
    
    // Add responsive viewport meta tag
    echo "\n\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">";
    
    // Add favicon
    echo "\n\t<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"" . $conf["baseURL"] . "favico.kalires.ico\" />";
    echo "\n\t<link rel=\"icon\" type=\"image/gif\" href=\"" . $conf["baseURL"] . "images/kalires.gif\" />";
    
    // Add stylesheets
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/kalires2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/calendar-system.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "style2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/qtip.css\">";
    
    // Add scripts
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/validator.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.plugin.qtip.js\" ></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar.js\"></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar-fr.js\"></script>";
    
    // Add responsive styles
    echo $responsiveCSS;
    
    echo "\n</head><body topmargin=0 leftmargin=0 >";
}

// Use custom responsive head function
customAffichehead(_s("Liste des prescriptions") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
entete();
echo "<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
echo "<H1>" . _s("Liste des prescriptions") . "</H1>";

if (!$_SESSION["accesPC"]) {
	klredir("consultation.php", 3, _s("Vous n'avez pas accés à cette page."));
	exit();
}

echo " \n<script type=\"text/javascript\">\n\tfunction masqueMessage(afficher) {\n\t\tif($('#messageLabo').is(':visible')) {\n\t\t\t$('#messageLabo').hide();\n\t\t\t$('#messageReduit').show();\n\t\t\t$('#imgMessage').attr('src','images/plus.gif');\n\t\t\tvar afficher = 0;\n\t\t} else {\n\t\t\t$('#messageReduit').hide();\n\t\t\t$('#messageLabo').show();\n\t\t\t$('#imgMessage').attr('src','images/minus.gif');\n\t\t\tvar afficher = 1;\n\t\t}\n\t\tjQuery.ajax({\n\t        type: \"POST\",\n\t        url: 'consultation.ajax.php?afficher='+afficher,\n\t        success: function(responseText,textStatus,msgObj){ }\n\t\t});\n\t}\n\n\n\n\tfunction clickRecherche() {\n\t\tgetById('div_content').style.display = \"none\";\n\t\tgetById('div_wait').style.display = \"block\";\n\t}\n\tfunction setSort(type) {\n\t\tgetById('filterLP_sort').value = type;\n\t\tclickRecherche();\n\t\tgetById('form_filterLP').submit();\n\t}\n</script>\n\n";

if ($_POST["choix"] == "reset") {
	unset($filterLP);
	unset($_SESSION["filterLP"]);
}

if ($_POST["choix"] == "filtrer") {
	$_SESSION["filterLP"] = $filterLP = $_POST["filterLP"];
}

if (!isset($filterLP)) {
	if (isset($_SESSION["filterLP"])) {
		$filterLP = $_SESSION["filterLP"];
	}
	else {
		$filterLP = array("nomPatient" => "", "prenomPatient" => "", "numDemande" => "", "nomNaissancePatient" => "", "dateNaissance" => "", "dateDebut" => date("d-m-Y", time() - 2592000), "dateFin" => date("d-m-Y"), "etat" => "");
	}
}

$scp = new SoapClientPrescription();
$params = array("idDemandeur" => $patientLogged->id(), "typeDemandeur" => $patientLogged->niveau, "filtre" => $filterLP);
$listePrescription = $scp->getListePrescriptionConnectee($params);
echo "\n\n<FORM id=\"form_filterLP\" NAME=\"principal\" METHOD=\"POST\" ACTION=\"listePrescription.php\">\n\t<input id=\"form_choix\" type=\"hidden\" name=\"choix\" value=\"filtrer\" />\n\t<input id=\"filterLP_sort\" type=\"hidden\" name=\"filterLP[sort]\" value=\"";
echo $filterLP["sort"];
echo "\" />\n\t<table align=\"center\" width=\"98%\">\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Nom usuel");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filterLP[nomPatient]\" value=\"";
echo $filterLP["nomPatient"];
echo "\" /></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Prénom");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filterLP[prenomPatient]\" value=\"";
echo $filterLP["prenomPatient"];
echo "\"></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Date naissance");
echo "</td>\n\t\t\t<td>";
echo navgetinputdate(array("style" => "font-size:11px;", "id" => "dateNaissance", "name" => "filterLP[dateNaissance]", "dataType" => "date", "value" => $filterLP["dateNaissance"]), true, false, true, false, true, "16");
echo "</td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("N°Dem/ADM/IPP");
echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filterLP[numDemande]\" value=\"";
echo $filterLP["numDemande"];
echo "\"></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Période du");
echo "</td>\n\t\t\t<td>";
echo navgetinputdate(array("style" => "font-size:11px;", "id" => "dateDebut", "name" => "filterLP[dateDebut]", "dataType" => "date", "value" => $filterLP["dateDebut"]), true, false, true, false, true, "16");
echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">&nbsp;";
echo _s("au");
echo "</td>\n\t\t\t<td>";
echo navgetinputdate(array("style" => "font-size:11px;", "id" => "dateFin", "name" => "filterLP[dateFin]", "dataType" => "date", "value" => $filterLP["dateFin"]), true, false, true, false, true, "16");
echo "</td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
echo _s("Etat de prescription");
echo "</td>\n\t\t\t<td>\n\t\t\t\t<select name=\"filterLP[etat]\" style=\"width:120px;font-size:11px;\">\n\t\t\t\t\t<option value=\"tout\" ";
echo ($filterLP["etat"] != "enCours") && ($filterLP["etat"] != "valide") ? "selected" : "";
echo ">";
echo _s("Tout");
echo "</option>\n\t\t\t\t\t<option value=\"saisie\" ";
echo $filterLP["etat"] == "saisie" ? "selected" : "";
echo ">";
echo _s("Enregistrée");
echo "</option>\n\t\t\t\t\t<option value=\"valide\" ";
echo $filterLP["etat"] == "valide" ? "selected" : "";
echo ">";
echo _s("Validée");
echo "</option>\n\t\t\t\t\t<option value=\"cloture\" ";
echo $filterLP["etat"] == "cloture" ? "selected" : "";
echo ">";
echo _s("Saisie");
echo "</option>\n\t\t\t\t</select>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=\"4\">\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
echo _s("Rechercher");
echo "' onclick=\"clickRecherche();\" />\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
echo _s("Effacer le filtre");
echo "' onclick=\"getById('form_choix').value='reset'; clickRecherche();\" />\n\t\t\t</td>\n\t\t</tr>\n\t</table>\n</FORM>\n\n\n";
$nbPC = count($listePrescription["dossierSaisi"]["cloture"]) + count($listePrescription["dossierNonSaisi"]["pcval"]) + count($listePrescription["dossierNonSaisi"]["pcsaisie"]);
echo "\n\n<div id=\"div_content\">\n\t<div align=\"center\">\n\t\t";
echo sprintf(_s("%s prescription(s) trouvée(s)"), $nbPC);
echo "\t</div>\t\t\n\t\t\n\n\t<table align=center cellpadding=1 cellspacing=1 border=0 width=98% style=\"border:1px solid #ccc;\">\n\t\t<tr class=titreBleu>\n\t\t\t<td colspan=2 width=20%><div >";
echo _s("Numéro");
echo "&nbsp;\n\t\t\t</td>\n\t\t\t<td width=30%><div >";
echo _s("Patient");
echo "&nbsp;</div>\n\t\t\t</td>\n\t\t\t<td width=30%>";
echo _s("Analyses");
echo "</td>\n\t\t\t<td width=20%>";
echo _s("Date");
echo "<br />";
echo _s("Etat labo.");
echo "\t\t\t</td>\n\t\t</tr>\n\t\t";
$iD = 0;
$_SESSION["listeDemandesSess"] = array();
$_SESSION["listeDemandesNomSess"] = array();

foreach ($listePrescription as $etatDossier => $listePC ) {
	echo "\t\t\t\t\t<tr class=\"titre\">\n\t\t\t\t\t\t<td colspan=5 align=center><b>\n\t\t\t\t\t\t\t";

	if ($etatDossier == "dossierNonSaisi") {
		echo "\t\t\t\t\t\t\t\t";
		echo _s("Demandes non saisies");
		echo "\t\t\t\t\t\t\t";
	}
	else if ($etatDossier == "dossierSaisi") {
		echo "\t\t\t\t\t\t\t\t";
		echo _s("Demandes saisies");
		echo "\t\t\t\t\t\t\t";
	}

	echo "\t\t\t\t\t\t</b></td>\n\t\t\t\t\t</tr>\n\t\t\t\t";

	if (is_array($listePC)) {
		foreach ($listePC as $PCEtat => $dossier ) {
			if ($etatDossier == "dossierNonSaisi") {
				echo " <tr class=\"sousTitrePC\">\n\t\t\t\t\t\t\t\t<td colspan=5 align=center><b>\n\t\t\t\t\t\t\t\t\t";

				if ($PCEtat == "pcsaisie") {
					echo _s("Prescriptions enregistrées (à valider)");
				}
				else if ($PCEtat == "pcval") {
					echo _s("Prescriptions validées");
				}

				echo "\t\t\t\t\t\t\t\t</b></td>\n\t\t\t\t\t\t\t</tr> ";
			}

			$qtipNS = (issroption("typeLabo", "maroc") ? _s("N° CIN du patient : ") : _s("NSS du patient : "));
			$labelNS = (issroption("typeLabo", "maroc") ? _s("N° CIN") : _s("NSS"));

			foreach ($dossier as $key => $data ) {
				$donneeHprim = unserialize($data["donneeHPRIM"]);
				$nomPatient = strtoupper($data["nom"]) . " " . ucfirst(strtolower($data["prenom"]));
				$_SESSION["listeDemandesSess"][$iD] = $data["numDemande"];
				$_SESSION["listeDemandesNomSess"][$iD] = $nomPatient;
				$iD++;
				$analysePresc = $donneeHprim["analyses"];
				$tabAnalyse = listecodeprescription($analysePresc, true);
				$qtipInfo = "";

				if ($data["numDemande"]) {
					$qtipInfo .= _s("N° de demande Kalisil : ") . $data["numDemande"] . "<br />";
				}

				if ($donneeHprim["numPermanent"]) {
					$qtipInfo .= _s("N° patient KaliSil : ") . $donneeHprim["numPermanent"] . "<br />";
				}

				if ($donneeHprim["numPatientExterne"]) {
					$qtipInfo .= _s("IPP du patient : ") . $donneeHprim["numPatientExterne"] . "<br />";
				}

				if ($donneeHprim["numDemandeExterne"]) {
					$qtipInfo .= _s("N° d'admission : ") . $donneeHprim["numDemandeExterne"] . "<br />";
				}

				if ($donneeHprim["caisse"]["numeroSecu"]) {
					$qtipInfo .= $qtipNS . $donneeHprim["caisse"]["numeroSecu"] . "<br />";
				}

				if ($data["saisieDate"] && $data["saisieDate"]) {
					$qtipInfoDmd = _s("Demande saisie le ") . affichedate($data["saisieDate"]) . _s(" à ") . $data["saisieHeure"];
				}

				echo "\t\t\t\t\t\t\t<tr style=\"height:25px\" class=\"corpsFonce\" >\n\t\t\t\t\t\t\t\t<td style=\"marging-right: 0; padding-right: 0; \" width=\"4%\" align=center>\n\t\t\t\t\t\t\t\t\t";

				if ($data["status"]) {
					echo "\t\t\t\t\t\t\t\t\t\t<a class=\"img\" href=\"afficheDossier.php?sNumDossier=";
					echo $data["numDemande"];
					echo "&sIdDossier=";
					echo $data["idDemande"];
					echo "\" ><img border=0 src=\"";
					echo imagepath("icoloupe.gif");
					echo "\" /></a>\n\t\t\t\t\t\t\t\t\t";
				}
				else {
					echo "\t\t\t\t\t\t\t\t\t\t<a class=\"img\" href=\"prescription.php?idPrescription=";
					echo $data["id"];
					echo "\" ><img border=0 src=\"";
					echo imagepath("icoloupe.gif");
					echo "\" /></a>\n\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t\t<td align=\"center\" style=\"border: 30px; marging-left: 0; padding-left: 0; \" class=\"defaultCursor qtipOn\" help=\"";
				echo $qtipInfo;
				echo "\" width=\"16%\" >\n\t\t\t\t\t\t\t\t \t<nobr>\n\t\t\t\t\t\t\t\t \t\t";

				if ($data["numDemande"]) {
					echo _s("N°Demande") . " " . $data["numDemande"];
					echo "\t\t\t\t\t\t\t\t\t</nobr><nobr>\n\t\t\t\t\t\t\t\t\t\t";
				}
				else if ($donneeHprim["numPermanent"]) {
					echo _s("N°Patient") . " " . $donneeHprim["numPermanent"];
					echo "\t\t\t\t\t\t\t\t\t</nobr><nobr>\n\t\t\t\t\t\t\t\t\t\t";
				}
				else if ($donneeHprim["numPatientExterne"]) {
					echo _s("IPP") . " " . $donneeHprim["numPatientExterne"];
					echo "\t\t\t\t\t\t\t\t\t</nobr><nobr>\n\t\t\t\t\t\t\t\t\t\t";
				}
				else if ($donneeHprim["numDemandeExterne"]) {
					echo _s("ADM") . " " . $donneeHprim["numDemandeExterne"];
					echo "</nobr><nobr>\n\t\t\t\t\t\t\t\t\t\t";
				}
				else if ($donneeHprim["caisse"]["numeroSecu"]) {
					echo $labelNS . " " . $donneeHprim["caisse"]["numeroSecu"];
					echo "\t\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t\t</nobr>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t\t<td  align=\"center\">\n\t\t\t\t\t\t\t\t\t";
				echo $nomPatient;
				echo "<BR><span class=descrFonce>";
				echo affichedate($data["dateNaissance"]);
				echo "</span>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t\t<td align=\"center\">";
				echo is_array($tabAnalyse) ? afficheanalyses($tabAnalyse, $filter) : "";
				echo "</td>\n\t\t\t\t\t\t\t\t<td align=\"center\" class=\"defaultCursor qtipOn\" help=\"";
				echo $qtipInfoDmd;
				echo "\"><NOBR>\n\t\t\t\t\t\t\t\t\t";
				echo affichedate($data["dateAdmission"]) . " " . $data["heureAdmission"];
				echo "\t\t\t\t\t\t\t\t\t<br />\n\t\t\t\t\t\t\t\t\t";

				if ($data["status"]) {
					echo "\t\t\t\t\t\t\t\t\t\t";
					echo getdemandestatusstr($data["status"]);
					echo "\t\t\t\t\t\t\t\t\t";
				}
				else {
					echo "\t\t\t\t\t\t\t\t\t\t";
					echo "<i>" . _s("Non saisie") . "</i>";
					echo "\t\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t\t\t</NOBR>\n\t\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t";
			}
		}
	}
}

echo "\t</table>\n</div>\n\n<div id=\"div_wait\" style=\"display:none;\">\n\t\t<center><img src=\"";
echo imagepath("wait16.gif");
echo "\" /></center>\n</div>\n\n";
affichefoot();

?>
