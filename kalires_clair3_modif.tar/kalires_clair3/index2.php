<?php

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
if (!isset($choix) || ($choix == "")) {
	define("KALILAB_SESSION_NO_UPDATE", "1");
}

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
session_start();

if ($conf["debug"]) {
	$conf["debug_filtrageAcces"] = true;
}

if ((getsroption("kaliResMedecinPermalink") || getsroption("kaliResCorrespondantPermalink") || getsroption("kaliResPreleveurPermalink")) && isset($_GET["sha"]) && isset($_GET["login"])) {
	if (logwithsha(array("sha" => $_GET["sha"], "login" => $_GET["login"], "numId" => $_GET["numId"], "user" => $_GET["user"]))) {
		if ($patientLogged->isAuth()) {
			$_SESSION["patientLogged"] = $patientLogged;
		}
		else {
			$_SESSION["loginError"] = 4;
			$goToDeny = true;
		}
	}
	else {
		$_SESSION["loginError"] = 5;
		$goToDeny = true;
	}
}

if ($patientLogged && $patientLogged->isAuth() && isset($_GET["to"])) {
	$lienTo = "";
	if (($_SESSION["accesPermalinkLevel"] == 0) || ($_SESSION["accesPermalinkLevel"] == 2)) {
		switch ($_GET["to"]) {
		case "consultation":
			if (!$_GET["numId"] && !$_GET["numIPP"]) {
				$_SESSION["loginError"] = 6;
				$goToDeny = true;
			}
			else {
				$lienTo = "consultation.php?numId=" . $_GET["numId"] . "&numIPP=" . $_GET["numIPP"];
				unset($_SESSION["listeDemandesSess"]);
				unset($_SESSION["listeDemandesNomSess"]);
			}

			break;

		default:
			$_SESSION["loginError"] = 6;
			$goToDeny = true;
			break;
		}
	}
	else {
		switch ($_GET["to"]) {
		case "prescription":
			$lienTo = "prescription.php";
			break;

		case "consultation":
			$lienTo = "consultation.php" . (isset($_GET["numId"]) ? "?numId=" . $_GET["numId"] : "");
			break;

		default:
			$_SESSION["loginError"] = 6;
			$goToDeny = true;
			break;
		}
	}

	if (!$goToDeny && ($lienTo != "")) {
		header("Location:" . $lienTo);
		exit();
	}
	else {
		$logout = 1;
	}
}

if (($logout == 1) && $patientLogged && $patientLogged->isAuth()) {
	$patientLogged->logout();
}

if ($choix == "changePassword") {
	if (($_SESSION["keyForm"] != "") && ($keyFormForm == $_SESSION["keyForm"])) {
		if ((($sPasswordOld != "") || ($_SESSION["keyFormToken"][$_SESSION["keyForm"]] != "")) && ($sPassword1 != "") && ($sPassword2 != "")) {
			if (5 <= strlen($sPassword1)) {
				if ($sPassword1 == $sPassword2) {
					$sc = new SoapClientKalires();
					$changePassw = $sc->changePassword($sNiveau, $sLogin, $sPasswordOld, $sPassword1, $_SESSION["keyFormToken"][$_SESSION["keyForm"]]);

					if ($changePassw->result == "1") {
						$sMsg = "" . _s("Le nouveau mot de passe a bien �t� enregistr�") . "";
						$patientLogged = new PatientLogged($sLogin, $sPassword1, "", $sNiveau);
					}
					else if ($changePassw->result == "2") {
						$sMsg = "<font color=red>" . _s("Erreur : le nouveau mot de passe doit �tre diff�rent de l'ancien") . "</font>";
					}
					else {
						$sMsg = "<font color=red>" . _s("Erreur : le changement de mot de passe a �chou�") . "</font>";
					}
				}
				else {
					$sMsg = "<font color=red>" . _s("Erreur : les 2 mots de passe ne sont pas identiques") . "</font>";
				}
			}
			else {
				$sMsg = "<font color=red>" . _s("Erreur : le mot de passe doit faire au minimum 5 caract�res") . "</font>";
			}
		}
		else {
			$sMsg = "<font color=red>" . _s("Erreur : veuillez remplir tous les champs requis") . "</font>";
		}
	}
	else {
		$sMsg = "<font color=red>" . _s("Erreur : session incorrecte") . "</font>";
	}
}

unset($_SESSION["keyForm"]);
unset($_SESSION["keyFormToken"]);
unset($_SESSION["refAnalyse"]);
unset($_SESSION["accesPC"]);
unset($_SESSION["accesPermalink"]);
$sessSessionIdKaliResOld = $_COOKIE["sessSessionIdKaliRes"];
$sessSessionIdKaliRes = uniqid("sessLogKaliRes");
setcookie("sessSessionIdKaliRes", $sessSessionIdKaliRes, time() + (52 * 7 * 24 * 60 * 60));
if (($sessionId != "") && (($sessSessionIdKaliResOld != $sessionId) || ($sessSessionIdKaliResOld == ""))) {
	$sMsg = _s("Session incorrecte ou expir�e : veuillez saisir votre mot de passe une nouvelle fois.");
}
else {
	if (($sessionId != "") && isset($sessSessionIdKaliResOld)) {
		unset($_SESSION["patientLogged"]);
		if ((trim($sNumSecu) != "") && (trim($sPassword) != "")) {
			$patientLogged = new PatientLogged($sNumSecu, $sPassword, $sNumDoss, "patient");
		}
		else {
			if ((trim($sNumAdeli) != "") && (trim($sPasswordM) != "")) {
				$patientLogged = new PatientLogged($sNumAdeli, $sPasswordM, $sNumDossM, "medecinCorrespondant");
			}
		}

		if ($patientLogged && $patientLogged->isLogin()) {
			if ($patientLogged->passwordExpired == 3) {
				$patientLogged->logout();
echo <<<HTML
'<script type=\"text/javascript\"> document.location.href='getPassword.php?sNiveau=patient'; </script>'
HTML;
				affichefoot();
				exit();
			}
			else {
				if (($patientLogged->passwordExpired == 1) || ($patientLogged->passwordExpired == 2)) {
					affichehead(_s("Identification"), "", false);
					entete();
					$keyForm = uniqid(date("YmdHis"));
					$_SESSION["keyForm"] = $keyForm;
					$_SESSION["keyFormToken"][$keyForm] = $patientLogged->passwordToken;
echo <<<HTML
'<form name=principal action=\"index.php\" method=post>'
					echo "<input type=hidden name=choix value=\"changePassword\"><input type=\"hidden\" name=\"keyFormForm\" value=\"" . $keyForm . "\"><input type=\"hidden\" name=\"sLogin\" value=\"" . ($patientLogged->niveau == "patient" ? $sNumSecu : $sNumAdeli) . "\"><input type=\"hidden\" name=\"sNiveau\" value=\"" . $patientLogged->niveau . "\"><input type=\"hidden\" name=\"sessionId\" value=\"" . $sessSessionIdKaliRes . "\">";
					echo "				<table class=\"corps\" align=center cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\">
HTML;
					";

					if ($patientLogged->passwordExpired == 2) {
echo <<<HTML
'						<tr class=titre><td align=center colspan=2>'
						echo _s("Votre mot de passe a expir�, veuillez saisir un nouveau mot de passe personnel");
						echo " :</td></tr>
HTML;
					";
					}
					else {
echo <<<HTML
'						<tr class=titre><td align=center colspan=2>'
						echo _s("Veuillez saisir un mot de passe personnel pour acc�der � KaliRes");
						echo " :</td></tr>
HTML;
					";
					}

echo <<<HTML
'					<tr class=corpsFonce><td align=center colspan=2 style=\"font-size:11px;\">'
					echo _s("Note : le mot de passe doit faire au minimum 5 caract�res et doit �tre diff�rent du dernier utilis�.");
					echo "</td></tr>
HTML;
					<tr><td align=right>";
echo <<<HTML
_s("Identifiant")
					echo " : </td><td>";
					echo $patientLogged->niveau == "patient" ? $sNumSecu : $sNumAdeli;
					echo "</td></tr>
HTML;
					";

					if ($patientLogged->passwordToken != "") {
echo <<<HTML
'
HTML;
					";
					}
					else {
echo <<<HTML
'						<tr><td align=right>'
						echo _s("Mot de passe actuel");
						echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPasswordOld\" autocomplete=\"off\" ></td></tr>
HTML;
					";
					}

echo <<<HTML
'					<tr><td colspan=2 class=titre></td></tr>
HTML;
					<tr><td align=right>";
echo <<<HTML
_s("Nouveau mot de passe personnel")
					echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPassword1\" autocomplete=\"off\" ></td></tr>
HTML;
					<tr><td align=right>";
echo <<<HTML
_s("Nouveau mot de passe personnel (v�rification)")
					echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPassword2\" autocomplete=\"off\" ></td></tr>
HTML;
					<tr><td align=right></td><td align=\"right\"><input type=\"submit\" name=\"send\" value=\"";
echo <<<HTML
_s("Enregistrer")
					echo "\"></td></tr>
HTML;
				</table>
			";
echo <<<HTML
'</form>'
HTML;
					exit();
				}
				else {
					$_SESSION["patientLogged"] = $patientLogged;
					affichehead(_s("Identification"), "", false);
					entete();
					$patientLogged->loadAccesSession();

					if ($patientLogged->cgu == 0) {
echo <<<HTML
'<center>
HTML;
						<table class=corps>
						<tr>
							<td>
					<form method=post action=index.php onSubmit=\"if(!document.getElementById('accord').checked) {alert('" . _s("Vous devez cocher la case prise de connaissance !", "javascript") . "');return false;}\"><input type=hidden name=choix value=accepter><input type=hidden name=sNumDoss value=\"" . $sNumDoss . "\"><br /><table class=\"corps\" align=center cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\"><tr><td align=left class=corpsFonce>" . _s("Conditions d'utilisation") . "</td></tr><tr><td align=left class=corps>" . nl2br(getsroption("kaliresCGU"));

						if ($patientLogged->datePasswordExpired != "") {
echo <<<HTML
'<br /><br />" . sprintf(_s("Votre mot de passe est valable jusqu'au %s"), "<b>" . affichedate({$patientLogged}->datePasswordExpired) . "</b>")
HTML;

							if (getsroption("passwordPerso") == 0) {
echo <<<HTML
'<br />" . _s("Pass� cette date vous pourrez en g�n�rer un nouveau sur le site ou en demander un aupr�s du laboratoire.")
HTML;
							}
							else {
echo <<<HTML
'<br />" . _s("Pass� cette date vous devrez saisir un nouveau mot de passe personnel.")
HTML;
							}
						}

echo <<<HTML
'<br /><br /><label><input type=checkbox name=accord id=accord value=1>&nbsp;" . _s("J'ai pris connaissance et j'accepte les conditions d'utilisation") . "</label><br /><br><input type=submit value=\"" . _s("J'accepte") . "\"></td></tr></table></form>
HTML;
							</td>
						</tr>
					</table></center>";
					}
					else {
						unset($_SESSION["rechDossier"]);

						if ($sNumDoss == "") {
							klredir("consultation.php", 1, _s("Connexion en cours ..."));
						}
						else {
							klredir("afficheDossier.php?sNumDossier=" . $sNumDoss . "", 1, _s("Connexion en cours ..."));
						}
					}

					affichefoot();
					exit();
				}
			}
		}
		else {
			if ($patientLogged->accountLocked) {
				$_SESSION["loginError"] = 1;
			}
			else {
				if ((empty($sNumSecu) && empty($sNumAdeli)) || empty($sPassword)) {
					$_SESSION["loginError"] = 2;
				}
				else {
					$_SESSION["loginError"] = 3;
				}
			}

			$goToDeny = true;
		}
	}
	else {
		if (($choix == "accepter") && $accord) {
			$patientLogged = $_SESSION["patientLogged"];
			$patientLogged->loadAccesSession();
			$patientLogged->setAccordSigne();
			affichehead(_s("Identification"), "", false);
			entete();

			if ($sNumDoss == "") {
				klredir("consultation.php", 1, _s("Connexion en cours ..."));
			}
			else {
				klredir("afficheDossier.php?sNumDossier=" . $sNumDoss . "", 1, _s("Connexion en cours ..."));
			}

			affichefoot();
			exit();
		}
	}
}

if ($goToDeny) {
	affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
	entete();
	klredir("denied.php?type=" . $_SESSION["loginError"], 1, "<span style=\"color:red;\">" . _s("L'authentification a �chou�") . "</span>");
	affichefoot();
	exit();
}

affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
entete();

if (0 < $_SESSION["loginError"]) {
	switch ($_SESSION["loginError"]) {
	case 1:
		$sMsg = _s("Erreur : Ce compte est verrouill� suite � un trop grand nombre de tentatives de connexion �chou�es. Veuillez contacter le laboratoire pour r�tablir l'acc�s");
		break;

	case 2:
		$sMsg = _s("Erreur : L'authentification a �chou� ou l'un des champs requis est vide");
		break;

	case 3:
		$sMsg = _s("Erreur : L'authentification a �chou�. Veuillez v�rifier vos identifiant et mot de passe puis vous reconnecter � nouveau");
		break;

	case 4:
		$sMsg = _s("Erreur : Vous devez vous identifier au moins une fois manuellement avec votre mot de passe et accepter les conditions g�n�rales pour activer votre compte") . "</font>";
		break;

	case 5:
		$sMsg = _s("Erreur : L'authentification a �chou�");
		break;

	case 6:
		$sMsg = _s("Erreur : Ce lien permanent ne permet pas d'acc�der � cette page. Veuillez saisir vos identifiant et mot de passe.");
		break;
	}

	$sMsg = "<font color=\"red\">" . $sMsg . "</font>";
}

affichemessage($sMsg, "width:450px;");
unset($_SESSION["KALIRES_OPTION_SITE"]);
unset($_SESSION["KALIRES_OPTION"]);
unset($_SESSION["loginError"]);
$loginPatient = getsroption("kaliResPatient");
$loginMedecin = getsroption("kaliResMedecin") || getsroption("kaliResCorrespondant") || getsroption("kaliResPreleveur");
echo <<<HTML
'<H1>'
echo _s("Serveur de r�sultats - Identification");
echo "</H1>
HTML;
<form method=\"POST\" action=\"index.php\" name=\"principal\">
	<table class=\"corps\" align=center cellpadding=\"8\" cellspacing=\"0\" border=\"0\" style=\" background-color:#F0F3F2;\" width=95%>
		<TR>
			";

if ($loginPatient) {
	$typeLoginPatient = getsroption("loginPatient");

	if ($typeLoginPatient == "numSecu") {
		$txtLogin = _s("Num�ro de S�curit� Sociale") . " : <br><i>(" . _s("15 chiffres accol�s") . ")</i>";
		$txtTxt = _s("Num�ro de S�curit� Sociale");
	}
	else {
		$txtLogin = _s("Num�ro Patient") . " : ";
		$txtTxt = _s("Num�ro Patient");
	}

echo <<<HTML
'				<TD width=50%>
HTML;
					<table class=\"corps\" align=left cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\">
						<tr class=titre><td align=center colspan=2><b>";
echo <<<HTML
_s("ACCES PATIENT")
	echo "</b></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
{$txtLogin}
	echo "</td><td ><input type=\"Text\" value=\"";
	echo $sNumSecu;
	echo "\" name=\"sNumSecu\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
_s("Mot de passe")
	echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPassword\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
_s("Num�ro de demande")
	echo " : <br><i>(facultatif)</i></td><td ><input type=\"Text\" name=\"sNumDoss\" value=\"";
	echo $sNumDoss;
	echo "\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
getsroption("passwordPerso") ? "<a href=\"getPassword.php?sNiveau=patient\">" . _s("Mot de passe oubli� ?") . "</a>" : "'
	echo "</td><td align=\"right\"><input type=\"submit\" name=\"send\" value=\"";
	echo _s("Se connecter");
	echo "\"></td></tr>
HTML;
					</table>
				</TD>
			";
}

echo <<<HTML
'			'
HTML;

if ($loginMedecin) {
echo <<<HTML
'				<TD width=50%>
HTML;
					<table class=\"corps\" align=right cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\">
						<tr class=titre><td align=center colspan=2><b>";
echo <<<HTML
_s("ACCES PROFESSIONNEL DE SANTE")
	echo "</b></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
_s("Identifiant")
	echo " : </td><td ><input type=\"Text\" value=\"";
	echo $sNumAdeli;
	echo "\" name=\"sNumAdeli\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
_s("Mot de passe")
	echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPasswordM\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right>";
echo <<<HTML
_s("Num�ro de demande")
	echo " : <br><i>(facultatif)</i></td><td ><input type=\"Text\" name=\"sNumDossM\" value=\"";
	echo $sNumDoss;
	echo "\" autocomplete=\"off\" ></td></tr>
HTML;
						<tr><td align=right><a href=\"getPassword.php?sNiveau=demandeur\">";
echo <<<HTML
_s("Mot de passe oubli� ?")
	echo "</a></td><td align=\"right\"><input type=\"submit\" name=\"send\" value=\"";
	echo _s("Se connecter");
	echo "\"></td></tr>
HTML;
					</table>
				</TD>
			";
}

echo <<<HTML
'		</TR>
HTML;
	</TABLE>
	<input type=hidden name=sessionId value=\"";
echo <<<HTML
{$sessSessionIdKaliRes}
echo "\">
HTML;
</form>
";

if (getsroption("passwordPatient") == "saisie") {
	if (0 < getsroption("passwordPerso")) {
		$txt = getsroption("accueilSaisiePerm");
	}
	else {
		$txt = getsroption("accueilSaisieTemp");
	}
}
else if (getsroption("passwordPatient") == "validation") {
	if (0 < getsroption("passwordPerso")) {
		$txt = getsroption("accueilValidePerm");
	}
	else {
		$txt = getsroption("accueilValideTemp");
	}
}
else if (getsroption("passwordPatient") == "saisieMail") {
	if (0 < getsroption("passwordPerso")) {
		$txt = getsroption("accueilSaisieMailPerm");
	}
	else {
		$txt = getsroption("accueilSaisieMailTemp");
	}
}

echo <<<HTML
'<H1>" . formatetexteaccueil(getsroption("titreAccesPatient")) . "</H1>'
echo "<UL>" . formatetexteaccueil($txt) . "</UL>";
HTML;
affichefoot();

?>
