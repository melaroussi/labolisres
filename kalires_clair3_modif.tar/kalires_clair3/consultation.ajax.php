<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
filtrageacces("patient", "index.php", "index.php");
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Content-type: text/xml; charset=ISO-8859-1");
echo "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n";
$scd = new SoapClientDemande();
$params = array("idDemandeur" => $patientLogged->id(), "typeDemandeur" => $patientLogged->niveau, "afficher" => $afficher);
$patientLogged->messageAffiche = $scd->changeMessageStatus($params);
echo "<response></response>";

?>
