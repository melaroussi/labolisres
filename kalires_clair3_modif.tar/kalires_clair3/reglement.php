<?php

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
define("KALILAB_SESSION_NO_UPDATE", "1");
include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
unset($_SESSION["KALIRES_OPTION"]);
unset($_SESSION["KALIRES_OPTION_SITE"]);
$goToDeny = false;
$sMsg = "";
$type = getsroption("interfacePaiement");
$urlPaiement = getsroption("urlPaiement");
if (((($type == "CBI") && ($urlPaiement != "")) || istypepaiementok($type)) && (0 < getsroption("offlinePaiement"))) {
}
else {
	affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
	entete();
	klredir("denied.php", 5, "<span style=\"color:red;\">" . _s("Acc�s non autoris�") . "</span>");
	affichefoot();
	exit();
}

unset($_SESSION["paiementOffline"]);

if ($_POST["choix"] == "regler") {
	if (($_SESSION["keyForm"] != "") && ($keyFormForm == $_SESSION["keyForm"])) {
		if (($_POST["numDemande"] != "") && ($_POST["dateNaissance"] != "") && ($_POST["email"] != "")) {
			$scd = new SoapClientKalires();
			$params = array("numDemande" => $_POST["numDemande"], "dateNaissance" => $_POST["dateNaissance"]);
			$ret = $scd->reglementDemandeOffline($params);

			if ($ret !== false) {
				if ($ret["status"] == "valide") {
					$idSite = (isset($ret["idSite"]) ? $ret["idSite"] : 0);
					$urlPaiement = getstrpaiement($ret["id"], $ret["numDemande"], $ret["reste"], $idSite, "redirect", $_POST["email"], $ret["idPatient"]);

					if ($urlPaiement != "") {
						$_SESSION["paiementOffline"] = "ok";
						affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
						entete();

						if ($type == "CBI") {
							klredir($urlPaiement, 1, _s("Redirection en cours..."));
						}
						else {
							echo $urlPaiement;
						}

						affichefoot();
						exit();
					}
					else {
						$sMsg = "<font color=\"red\">" . _s("Erreur : Impossible de trouver la demande correspondante. Merci de v�rifier les informations saisies ou de contacter le laboratoire.") . "</font>";
					}
				}
				else {
					$sMsg = "<font color=\"blue\">" . _s("Votre demande n'est pas encore valid�e, merci de r�-essayer ult�rieurement.") . "</font>";
				}
			}
			else {
				$sMsg = "<font color=\"red\">" . _s("Erreur : Impossible de trouver la demande correspondante. Merci de v�rifier les informations saisies ou de contacter le laboratoire.") . "</font>";
			}
		}
		else {
			$sMsg = "<font color=\"red\">" . _s("Erreur : Des informations sont manquantes. Merci de v�rifier les informations saisies.") . "</font>";
		}
	}
	else {
		$sMsg = "<font color=\"red\">" . _s("Erreur : Session expir�e. Merci de renseigner � nouveau les informations saisies") . "</font>";
	}
}

if ($sMsg != "") {
	affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
	entete();
	klredir("denied.php?origin=reglement.php", 4, $sMsg);
	affichefoot();
	exit();
}

affichehead(_s("Paiement en ligne") . " - " . getsroption("laboNom"), "", false);
entete();
unset($_SESSION["keyForm"]);
$keyForm = uniqid(date("YmdHis"));
$_SESSION["keyForm"] = $keyForm;
echo "<H1>";
echo _s("Paiement en ligne") . " - " . getsroption("laboNom");
echo "</H1>\n<form method=\"POST\" action=\"reglement.php\" name=\"principal\">\n<input type=hidden name=choix value='regler'>\n<input type=hidden name=keyFormForm value='";
echo $keyForm;
echo "'>\n\t<table class=\"corps\" align=center cellpadding=\"8\" cellspacing=\"0\" border=\"0\" style=\" background-color:#F0F3F2;\" width=95%>\n\t\t<TR>\n\t\t\t<TD width=100%>\n\t\t\t\t<table class=\"corps\" align=left cellpadding=\"4\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;width:450px;\">\n\t\t\t\t\t<tr class=titre><td align=center colspan=2><b>";
echo _s("Renseignements � saisir");
echo "</b></td></tr>\n\t\t\t\t\t<tr><td align=right>";
echo _s("R�f�rence du dossier");
echo " : </td><td><input size=30 type=\"text\" value=\"";
echo $numDemande;
echo "\" name=\"numDemande\" autocomplete=\"off\" ><img src=\"";
echo imagepath("help.gif");
echo "\" title=\"";
echo _s("Ce num�ro peut �tre trouv� sur le compte-rendu de r�sultat ou sur la facture que vous avez re�u.");
echo "\"/></td></tr>\n\t\t\t\t\t<tr><td align=right>";
echo _s("Date de naissance");
echo " : <br /><span style=\"font-style:italic;font-size:10px;\">";
echo _s("format JJ-MM-AAAA");
echo "</span></td><td>";
echo navgetinputdate(array("id" => "dateNaissance", "name" => "dateNaissance", "dataType" => "date", "value" => ""), true, false, true, false, true);
echo "</td></tr>\n\t\t\t\t\t<tr><td align=right>";
echo _s("Adresse e-mail");
echo " : </td><td ><input size=30 type=\"text\" value=\"\" name=\"email\" autocomplete=\"off\" ></td></tr>\n\t\t\t\t\t<tr><td align=\"center\" colspan=2><input type=\"submit\" name=\"send\" value=\"";
echo _s("R�gler votre demande");
echo "\"></td></tr>\n\t\t\t\t</table>\n\t\t\t</TD>\n\t\t</TR>\n\t</TABLE>\n</form>\n";
affichefoot();

?>
