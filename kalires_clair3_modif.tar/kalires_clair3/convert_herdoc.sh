#!/bin/bash

# Nom du fichier d'entrée
input_file="index.php"

# Nom du fichier de sortie
output_file="index2.php"

# Fonction pour échapper les caractères spéciaux pour sed
escape_sed() {
    echo "$1" | sed 's/[\/&]/\\&/g'
}

# Lire le fichier ligne par ligne
heredoc_started=false
buffer=""

while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ $line =~ ^[[:space:]]*echo[[:space:]]* ]] && ! $heredoc_started; then
        # Début d'un nouveau bloc echo
        if ! $heredoc_started; then
            echo "echo <<<HTML" >> "$output_file"
            heredoc_started=true
        fi
        # Extraire le contenu de l'echo
        content=$(echo "$line" | sed -E 's/^[[:space:]]*echo[[:space:]]*//; s/;[[:space:]]*$//')
        # Remplacer les guillemets doubles par des simples
        content=$(echo "$content" | sed 's/^"/'"'"'/; s/"$/'"'"'/')
        # Échapper les variables PHP
        content=$(echo "$content" | sed 's/\$\([a-zA-Z_][a-zA-Z0-9_]*\)/{\$\1}/g')
        echo "$content" >> "$output_file"
    elif $heredoc_started && [[ ! $line =~ ^[[:space:]]*echo[[:space:]]* ]]; then
        # Fin du bloc echo
        echo "HTML;" >> "$output_file"
        heredoc_started=false
        echo "$line" >> "$output_file"
    else
        # Ligne normale, l'écrire telle quelle
        echo "$line" >> "$output_file"
    fi
done < "$input_file"

# S'assurer que le dernier bloc Heredoc est fermé
if $heredoc_started; then
    echo "HTML;" >> "$output_file"
fi

echo "Traitement terminé. Le résultat a été sauvegardé dans $output_file"
