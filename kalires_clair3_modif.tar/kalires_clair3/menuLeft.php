<?php

global $conf;
echo "<ul>\n\t<br /><br /><br /><br />\n</ul>\n";

?>
