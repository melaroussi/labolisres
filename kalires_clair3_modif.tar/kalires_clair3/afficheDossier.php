<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
$typeDestinataire = $patientLogged->niveau;

// Add responsive styles
$responsiveCSS = <<<EOT
<style>
/* Responsive styles */
@media screen and (max-width: 768px) {
    table {
        width: 100% !important;
        font-size: 14px;
    }
    
    td, th {
        padding: 8px !important;
    }
    
    .corpsFonce {
        white-space: normal !important;
    }
    
    .descr {
        font-size: 12px;
    }
    
    .titreBleu {
        font-size: 14px;
    }
    
    .corps {
        font-size: 14px;
    }
    
    #div_content {
        padding: 10px;
    }
    
    .hand {
        display: block;
        padding: 5px;
    }
    
    .img {
        display: inline-block;
    }
    
    iframe {
        width: 100% !important;
        height: 500px !important;
    }
    
    .commentaireChapitre {
        font-size: 12px;
    }
    
    .descrGrand {
        font-size: 12px;
    }
    
    .titreAnalyse {
        font-size: 12px;
    }
    
    .commentaireAnalyse {
        font-size: 12px;
    }
    
    .analyse {
        font-size: 9px;
    }
    
    .analysenew, .analysevalide {
        font-size: 12px;
    }
    
    .analysehorsborne {
        font-size: 12px;
    }
    
    .login-form {
        width: 100% !important;
        margin-bottom: 20px;
    }
}

/* Base styles */
table {
    border-collapse: collapse;
    margin: 10px 0;
}

.corpsFonce {
    background-color: #f5f5f5;
}

.descr {
    color: #666;
}

.analyse {
    font-style: italic;
    color: #666;
}

.analysenew {
    font-weight: bold;
    text-decoration: underline;
}

.analysevalide {
    color: #005020;
}

.analysehorsborne {
    background-color: #F7BC8C;
    padding: 2px;
}

.hand {
    cursor: pointer;
}

.img {
    text-decoration: none;
}

.commentaireChapitre {
    color: #666;
    font-style: italic;
}

.titreAnalyse {
    font-weight: bold;
}

.commentaireAnalyse {
    color: #666;
    font-style: italic;
}

.descrGrand {
    font-size: 14px;
}
</style>
EOT;

// Function to override standard affichehead function with responsive meta tag
function customAffichehead($titre, $script, $javascript = false) {
    global $conf;
    global $responsiveCSS;
    
    // Start HTML
    echo "<html><head><title>" . $titre . "</title>";
    
    // Add responsive viewport meta tag
    echo "\n\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">";
    
    // Add favicon
    echo "\n\t<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"" . $conf["baseURL"] . "favico.kalires.ico\" />";
    echo "\n\t<link rel=\"icon\" type=\"image/gif\" href=\"" . $conf["baseURL"] . "images/kalires.gif\" />";
    
    // Add stylesheets
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/kalires2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/calendar-system.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "style2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/qtip.css\">";
    
    // Add scripts
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/validator.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.plugin.qtip.js\" ></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar.js\"></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar-fr.js\"></script>";
    
    // Add responsive styles
    echo $responsiveCSS;
    
    echo "\n</head><body topmargin=0 leftmargin=0 >";
}

// Use custom responsive head function
customAffichehead(_s("Consultation d'une demande") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
tooltip_init();
$optionRouge = getsroption("afficheRouge");
$affichAnt = getsroption("affichAnt");
$affichEncours = getsroption("affichEncours");
$afficheDossierPaye = getsroption("afficheDossierPaye");
$afficheDossierPayeMin = getsroption("afficheDossierPayeMin");
if (($patientLogged->niveau == "patient") && (getsroption("affichAnt") == 0) && ($patientLogged->numDemande != $sNumDossier)) {
	entete();
	affichemessage(_s("Erreur de slection : impossible de trouver la demande"));
	affichefoot();
	exit();
}

$scd = new SoapClientDemande();
$params = array("typeDestinataire" => $typeDestinataire, "patientId" => $patientLogged->id(), "numDemande" => $sNumDossier, "idDemande" => $sIdDossier, "patientNiveau" => $patientLogged->niveau, "referer" => $_SERVER["HTTP_REFERER"]);
$dataPatient = $scd->getDataPatient($params);
echo $dataPatient;
entete($menuAdd);

if ($dataPatient["numDemande"] == "") {
	affichemessage(_s("Impossible de trouver la demande"));
	affichefoot();
	exit();
}

if ($patientLogged->niveau == "patient") {
	affichemessagesil();
}

$demandeListLink = _s("Liste des demandes");
if (!$_SESSION["accesPermalink"] || ($_SESSION["accesPermalinkLevel"] == 1) || ($_SESSION["accesPermalinkLevel"] == 2)) {
	$demandeListLink = "<a href='consultation.php' title='" . _s("Liste des demandes") . "'>" . $demandeListLink . "</a>";
}

echo "<h1>" . $demandeListLink . " >> " . _s("Consultation") . " : $sNumDossier</h1>";
if (($sNumDossier != "") && is_array($_SESSION["listeDemandesSess"]) && in_array($sNumDossier, $_SESSION["listeDemandesSess"])) {
	$iPos = array_search($sNumDossier, $_SESSION["listeDemandesSess"]);
	$suivPrec = false;
	if ((0 < $iPos) && isset($_SESSION["listeDemandesSess"][$iPos - 1])) {
		echo "<span style=\"float:left;\"><a href=\"afficheDossier.php?sNumDossier=" . $_SESSION["listeDemandesSess"][$iPos - 1] . "&sIdDossier=" . $_SESSION["listeDemandesIdSess"][$iPos - 1] . "\"><img border=0 src=\"images/navprevpetit.gif\"> " . _s("Demande ultrieure") . " (" . $_SESSION["listeDemandesNomSess"][$iPos - 1] . ")</a></span>";
		$suivPrec = true;
	}

	if (($iPos < count($_SESSION["listeDemandesSess"])) && isset($_SESSION["listeDemandesSess"][$iPos + 1])) {
		echo "<span style=\"float:right;\"><a href=\"afficheDossier.php?sNumDossier=" . $_SESSION["listeDemandesSess"][$iPos + 1] . "&sIdDossier=" . $_SESSION["listeDemandesIdSess"][$iPos + 1] . "\">" . _s("Demande antrieure") . " (" . $_SESSION["listeDemandesNomSess"][$iPos + 1] . ") <img border=0 src=\"images/navnextpetit.gif\"></a></span>";
		$suivPrec = true;
	}

	echo "<br />";

	if ($suivPrec) {
		echo "<br />";
	}
}

echo "<FORM id=\"newPrescription\" AUTOCOMPLETE=off NAME=\"principal\" METHOD=\"POST\" ACTION=\"prescription.php\" >\n\t\t<input type=\"hidden\" id=\"ipp\" name=\"dataPatient[ipp]\" value=\"" . _secho($dataPatient["numPermanentExterne"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"numAdm\" name=\"dataPatient[numAdm]\" value=\"" . _secho($dataPatient["numDemandeExterne"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"numPerm\" name=\"dataPatient[numPerm]\" value=\"" . _secho($dataPatient["numPermanent"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"numSecu\" name=\"dataPatient[numSecu]\" value=\"" . _secho($dataPatient["assureNumSecu"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"nomNaissance\" name=\"dataPatient[nomNaissance]\" value=\"" . _secho($dataPatient["nomJeuneFille"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"dateN\" name=\"dataPatient[dateN]\" value=\"" . _secho($dataPatient["dateNaissance"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"nomUsuel\" name=\"dataPatient[nomUsuel]\" value=\"" . _secho($dataPatient["nom"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"sexe\" name=\"dataPatient[sexe]\" value=\"" . _secho($dataPatient["sexe"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"prenom\" name=\"dataPatient[prenom]\" value=\"" . _secho($dataPatient["prenom"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"rangG\" name=\"dataPatient[rangG]\" value=\"" . _secho($dataPatient["rangGemellaire"], "input") . "\"/>\n\t\t<input type=\"hidden\" id=\"civ\" name=\"dataPatient[civ]\" value=\"" . _secho($dataPatient["civilite"], "input") . "\"/>\n\t</FORM>";
$btnAddFromVisu = "";
if ($_SESSION["accesPC"] && (!$_SESSION["accesPermalink"] || ($_SESSION["accesPermalinkLevel"] == 1))) {
	$btnAddFromVisu = "<img src=\"" . imagepath("icoaddpetit.gif") . "\" title=\"" . _s("Saisir une nouvelle prescription connect�e pour ce patient") . "\" class=\"hand\" style=\"position:absolute; right:1px;bottom:3px;\" onClick=\"$('#newPrescription').submit();\"/></nobr>";
}

echo "<table class=titreBleu cellspacing=1 cellpadding=2 align=center width=650 style=\"margin-top:10px;margin-bottom:10px;\">";
echo "<tr class=corps height=\"20px\"><td width=\"14%\" class=corpsFonce>" . _s("N� Demande") . " :</td><td width=\"34%\">" . $dataPatient["numDemande"] . "</td><td width=\"18%\" class=corpsFonce>" . _s("Date saisie") . " :</td><td width=\"34%\">" . affichedate($dataPatient["saisieDate"]) . " " . $dataPatient["saisieHeure"] . ($dataPatient["saisieDate"] != $dataPatient["demandeDate"] ? " (" . affichedate($dataPatient["demandeDate"]) . ")" : "") . "</td></tr><tr class=corps height=\"20px\"><td class=corpsFonce>" . _s("N� Admission") . " :</td><td>" . $dataPatient["numDemandeExterne"] . ($dataPatient["numPermanentExterne"] != "" ? " (IPP " . $dataPatient["numPermanentExterne"] . ")" : "") . "</td><td class=corpsFonce>" . _s("Date pr�l�vement") . " :</td><td>" . ($dataPatient["preleveDate"] != "0000-00-00" ? affichedate($dataPatient["preleveDate"]) . " " . $dataPatient["preleveHeure"] : "") . ($dataPatient["saisieDate"] != $dataPatient["demandeDate"] ? " (" . affichedate($dataPatient["demandeDate"]) . ")" : "") . "</td></tr><tr class=corps height=\"20px\"><td class=corpsFonce>" . _s("Patient(e)") . " :</td><td style=\"position:relative\"><span style=\"position:absolute;left:1px;top:4px;\">" . strtoupper($dataPatient["nom"]) . " " . ucfirst(strtolower($dataPatient["prenom"])) . "</span>&nbsp;" . $btnAddFromVisu . "</td><td class=corpsFonce>" . _s("Date naissance") . " :</td><td>" . affichedate($dataPatient["dateNaissance"]) . "</td></tr><tr class=corps height=\"20px\"><td class=corpsFonce>" . _s("M�decin") . " :</td><td>" . $dataPatient["nomMedecin"] . "<span style=\"font-size:10px;\"><br />" . $dataPatient["medecinCoordonnee"] . "</span></td><td class=corpsFonce>" . _s("Correspondant") . " :</td><td>" . $dataPatient["nomCorrespondant"] . "<span style=\"font-size:10px;\"><br />" . $dataPatient["correspCoordonnee"] . "</span></td></tr>";
echo "</table>";
echo "<br />";
if (($patientLogged->niveau == "patient") && (0 < $dataPatient["restePatient"])) {
	$strPaiement = getstrpaiement($dataPatient["id"], $dataPatient["numDemande"], $dataPatient["restePatient"], $dataPatient["idSite"]);

	if ($strPaiement != "") {
		$strPaiement = "<br />" . $strPaiement;
	}

	echo "<center><div style=\"color:#222;border:1px solid #aaa;padding:4px;width:450px;background-color:#fff;\">" . _s("Cette demande n'a pas encore �t� r�gl�e") . " (" . $dataPatient["restePatient"] . " " . getmonnaie("html") . ")" . $strPaiement . "</div><br /><br /></center>";
	if ((0 < $afficheDossierPaye) && ($afficheDossierPayeMin < $dataPatient["restePatient"])) {
		echo "<center><b>" . _s("Les r�sultats seront visibles apr�s r�glement de la demande aupr�s du laboratoire") . "</b></center>";
		affichefoot();
		exit();
	}
}
else {
	if (($patientLogged->niveau == "patient") && (0 < $dataPatient["montantPatient"]) && paiementallowed($dataPatient["idSite"])) {
		$scd = new SoapClientDemande();
		$nomFichier = $scd->getFichierQuittance($dataPatient["id"]);

		if ($nomFichier != false) {
			$nomPdfDemande = str_replace(array(" ", "-", "/"), array("_"), $dataPatient["numDemande"]) . "_Quittance.pdf";
			echo "<center><div style=\"color:#222;border:1px solid #aaa;padding:4px;width:450px;background-color:#fff;\"><span class=\"hand\" onClick=\"makeRemote('quittance','pjGet.php?src=quittance&file=" . basename($nomFichier) . "&nom=" . $nomPdfDemande . "',800,600);\">" . _s("Cette demande a �t� r�gl�e, cliquez-ici pour r�cup�rer la quittance") . "<img src=\"" . imagepath("icopdf2.gif") . "\" /><br /></span></div><br /><br /></center>";
		}
		else {
			echo "<center><div style=\"color:#222;border:1px solid #aaa;padding:4px;width:450px;background-color:#fff;\">" . _s("Quittance non disponible pour le moment") . "</div><br /><br /></center>";
		}
	}
}

if (is_array($dataPatient["dataNC"]) && (0 < count($dataPatient["dataNC"]))) {
	echo "<center><div style=\"color:#222;border:1px solid #aaa;padding:4px;width:650px;background-color:#fff;text-align:left;\"><u>" . _s("Dysfonctionnement identifi� sur cette demande") . "</u><br /> &middot; ";
	echo implode("<br /> &middot; ", $dataPatient["dataNC"]);
	echo "</div><br /><br /></center>";
}

$cs = new SoapClientKalires();
$cs->trace($patientLogged->niveau, $patientLogged->id(), "consultation", $dataPatient["id"], $patientLogged->traceUser);
if (($dataPatient["status"] != "valide") && (($typeDestinataire == "preleveur") || (($typeDestinataire == "patient") && ($affichEncours == 0)) || (in_array($typeDestinataire, array("medecin", "correspondant")) && ($dataPatient["dataInter"]["kaliresNonValide"] == 2)))) {
	affichemessage(_s("Demande non valid�e, veuillez vous reconnecter ult�rieurement"));
}
else {
	if ((($dataPatient["status"] == "valide") && (($typeDestinataire == "patient") || ($typeDestinataire == "preleveur"))) || (($typeDestinataire == "patient") && ($affichEncours == 1)) || ($typeDestinataire == "medecin") || ($typeDestinataire == "correspondant")) {
		ob_start();
		$scd = new SoapClientDemande();
		$params = array("idDemande" => $dataPatient["id"], "numDemande" => $dataPatient["numDemande"], "patientId" => $patientLogged->id(), "patientNiveau" => $patientLogged->niveau, "chapitreId" => $chapitreId);
		$dataAnalyseArray = $scd->getDataAnalyse($params);
		$anterioriteTableau = false;
		$trAnterio = "";
		$colspan = 6;

		if (is_array($dataAnalyseArray[0]["anterioriteTabReference"])) {
			$anterioriteTableau = true;

			foreach ($dataAnalyseArray[0]["anterioriteTabReference"] as $keyAnterio ) {
				$trAnterio .= "<TD>" . substr($keyAnterio, 8, 2) . "-" . substr($keyAnterio, 5, 2) . "-" . substr($keyAnterio, 2, 2) . "</TD>";
				$colspan++;
			}
		}
		else {
			$colspan++;
		}

		echo "<TABLE cellspacing=1 cellpadding=2 border=0 width=98% class=titre align=center><TR class=titreBleu><TD><NOBR> " . _s("Nom") . " </NOBR></TD><TD><NOBR>&nbsp;" . _s("R�sultat") . "&nbsp;</NOBR></TD><TD><NOBR>&nbsp;" . _s("Unit�") . "&nbsp;</NOBR></TD><TD align=center><NOBR>&nbsp;" . _s("Bornes") . "&nbsp;</NOBR></TD><TD title=\"Indicateur d'anormalit�\" alt=\"Indicateur d'anormalit�\"><NOBR> " . _s("Ind") . " </NOBR></TD><TD title=\"Validation\" alt=\"Validation\"><NOBR> " . _s("Val") . " </NOBR></TD>" . ($anterioriteTableau ? $trAnterio : "<TD><NOBR> " . _s("Ant�riorit�") . " </NOBR></TD>") . "</TR>";
		$tmp2 = "";
		$cacher = false;
		$anterioDateOld = "";
		$valideDateHeureDemande = "";
		$dernierValideurBioStr = "";
		$dernierValideurBioTime = 0;
		$tabExecutant = array();
		$tabExecutantAsterisk = array();

		if (is_array($dataAnalyseArray)) {
			foreach ($dataAnalyseArray as $key => $dataAnalyse ) {
				if (isset($dataAnalyse["anterioriteTabReference"])) {
					continue;
				}

				if (isset($dataAnalyse["idChapitre"]) && ($dataAnalyse["idChapitre"] != "")) {
					$commentaireChapitre = "<span class=\"commentaireChapitre\">" . $dataAnalyse["commentaireChapitre"] . "</span>";
					echo "<TR class=titreChapitre align=center><TD colspan=\"" . $colspan . "\">" . $dataAnalyse["nomChapitre"] . ($dataAnalyse["placeCommentaireChapitre"] == 1 ? " " . $commentaireChapitre : "") . "</TD></TR>";
					$oldChapitre = $dataAnalyse["idChapitre"];
					if (($dataAnalyse["commentaireChapitre"] != "") && ($dataAnalyse["placeCommentaireChapitre"] == 0)) {
						echo "<TR class=\"commentaireChapitre\"><TD colspan=\"" . $colspan . "\">" . $dataAnalyse["commentaireChapitre"] . "</TD></TR>";
					}

					continue;
				}

				$valideDateHeureDemande = $dataAnalyse["heureValideDemande"];
				$tabPolice = unserialize($dataAnalyse["typePolice"]);
				$classListe = "";

				if ($tabPolice["B"] == 1) {
					$classListe .= " gras";
				}

				if ($tabPolice["I"] == 1) {
					$classListe .= " italique";
				}

				if ($tabPolice["U"] == 1) {
					$classListe .= " souligne";
				}

				if (($typeDestinataire == "patient") || ($typeDestinataire == "preleveur")) {
					if (isset($tabPolice["supprImpressionPatientHprim"])) {
						if ($tabPolice["supprImpressionPatientHprim"] == 1) {
							continue;
						}
					}
					else if ($tabPolice["supprImpressionPatient"] == 1) {
						continue;
					}
				}
				else if ($typeDestinataire == "medecin") {
					if (isset($tabPolice["supprImpressionMedecinHprim"])) {
						if ($tabPolice["supprImpressionMedecinHprim"] == 1) {
							continue;
						}
					}
					else if ($tabPolice["supprImpressionHprim"] == 1) {
						continue;
					}
				}
				else if ($typeDestinataire == "correspondant") {
					if (isset($tabPolice["supprImpressionCorrespondantHprim"])) {
						if ($tabPolice["supprImpressionCorrespondantHprim"] == 1) {
							continue;
						}
					}
					else if ($tabPolice["supprImpressionHprim"] == 1) {
						continue;
					}
				}

				if ($dataAnalyse["titre"] != "") {
					echo "<TR><TD colspan=\"" . $colspan . "\" class=\"titreAnalyse " . $classListe . "\" align=left><NOBR>&nbsp;&middot;&nbsp;" . changetxtana($dataAnalyse["titre"]) . " </NOBR></TD></TR>";
					continue;
				}

				if ($dataAnalyse["commentaire"] != "") {
					echo "<TR><TD colspan=\"" . $colspan . "\" class=\"commentaireAnalyse " . $classListe . "\" align=left><NOBR><img src=\"" . imagepath("icocommentaire.gif") . "\" /> " . tronquer(changetxtana(nl2br($dataAnalyse["commentaire"])), 150, "...", true) . " </NOBR></TD></TR>";
					continue;
				}

				if ($dataAnalyse["html"] != "") {
					echo "<TR><TD colspan=\"" . $colspan . "\">" . $dataAnalyse["html"] . "</TD></TR>";
					continue;
				}

				$remplacementPatient = $dataAnalyse["affichagePatient"];
				$remplacementPatientAnalyse = $dataAnalyse["affichagePatientAnalyse"];
				$remplacementMedecin = $dataAnalyse["affichageMedecin"];
				$remplacementMedecinAnalyse = $dataAnalyse["affichageMedecinAnalyse"];
				$remplacementCorrespondant = $dataAnalyse["affichageCorrespondant"];
				$remplacementCorrespondantAnalyse = $dataAnalyse["affichageCorrespondantAnalyse"];

				if ($dataAnalyse["resultatType"] == "texteCodifie") {
					if ($dataAnalyse["SremplacementPatient"] != "") {
						$remplacementPatient = $dataAnalyse["SremplacementPatient"];
					}

					if ($dataAnalyse["SremplacementPatientAnalyse"] != "") {
						$remplacementPatientAnalyse = $dataAnalyse["SremplacementPatientAnalyse"];
					}

					if ($dataAnalyse["SremplacementMedecin"] != "") {
						$remplacementMedecin = $dataAnalyse["SremplacementMedecin"];
					}

					if ($dataAnalyse["SremplacementMedecinAnalyse"] != "") {
						$remplacementMedecinAnalyse = $dataAnalyse["SremplacementMedecinAnalyse"];
					}

					if ($dataAnalyse["SremplacementCorrespondant"] != "") {
						$remplacementCorrespondant = $dataAnalyse["SremplacementCorrespondant"];
					}

					if ($dataAnalyse["SremplacementCorrespondantAnalyse"] != "") {
						$remplacementCorrespondantAnalyse = $dataAnalyse["SremplacementCorrespondantAnalyse"];
					}
				}

				if (($typeDestinataire == "patient") && ($dataAnalyse["valideBioPar"] == 0)) {
					$remplacementPatient = "<I><B><SPAN style='color:orange'>" . _s("En cours") . "</SPAN><B></I>";
				}
				else {
					if ((0 < $dataAnalyse["valideBioPar"]) || ((0 < $dataAnalyse["valideTechPar"]) && ($dataPatient["dataInter"]["kaliresNonValide"] == 1) && ($dataAnalyse["bloqueAffBio"] == 0))) {
					}
					else {
						$remplacementMedecin = "<I><B><SPAN style='color:orange'>" . _s("En cours") . "</SPAN><B></I>";
						$remplacementCorrespondant = "<I><B><SPAN style='color:orange'>" . _s("En cours") . "</SPAN><B></I>";
					}
				}

				$monAnalyse = $dataAnalyse["nom"];
				$monResultat = $dataAnalyse["resultat"];
				$resReplaced = false;

				if ($typeDestinataire == "medecin") {
					if ($remplacementMedecin != "") {
						$resReplaced = true;
						$monResultat = $remplacementMedecin;
					}

					if ($remplacementMedecinAnalyse != "") {
						$resReplaced = true;
						$monAnalyse = $remplacementMedecinAnalyse;
						$monResultat = $remplacementMedecinAnalyse;
					}
				}
				else if ($typeDestinataire == "correspondant") {
					if ($remplacementCorrespondant != "") {
						$resReplaced = true;
						$monResultat = $remplacementCorrespondant;
					}

					if ($remplacementCorrespondantAnalyse != "") {
						$resReplaced = true;
						$monAnalyse = $remplacementCorrespondantAnalyse;
						$monResultat = $remplacementCorrespondantAnalyse;
					}
				}
				else {
					if ($remplacementPatient != "") {
						$resReplaced = true;
						$monResultat = $remplacementPatient;
					}

					if ($remplacementPatientAnalyse != "") {
						$resReplaced = true;
						$monAnalyse = $remplacementPatientAnalyse;
						$monResultat = $remplacementPatientAnalyse;
					}
				}

				$borne = "-";
				$img = "";
				$borne = $dataAnalyse["borne"];
				$img = "<IMG SRC='images/" . afficheborneimg($dataAnalyse["borneBiologique"]) . "'>";
				if ($optionRouge && ($dataAnalyse["borneBiologique"] != 0)) {
					$class = "rouge";
				}
				else {
					$class = "corps";
				}

				if (($dataAnalyse["borneBiologique"] != 0) && ($typeDestinataire != "patient")) {
					$class = "rouge";
				}

				if ($anterioriteTableau) {
					$anterio = "";
					$anterioConv = "";

					foreach ($dataAnalyseArray[0]["anterioriteTabReference"] as $keyAnterio ) {
						$anterio .= "<TD class=\"descrGrand\" align=right>";
						$anterio .= ($dataAnalyse["anterioTableauBrut"][$keyAnterio]["valTech"] == 1 ? "*&nbsp;" : "");
						$tooltip = sprintf(_s("Le %s"), affichedate($dataAnalyse["anterioTableauBrut"][$keyAnterio]["valideTechDate"])) . "\n" . $dataAnalyse["anterioTableauBrut"][$keyAnterio]["valideTechHeure"];

						if ($dataAnalyse["resultatType"] == "texteCodifie") {
							$anterio .= "<span style=\"" . ($dataAnalyse["anterioTableauBrut"][$keyAnterio]["borne"] != 0 ? "color:red;" : "") . "\">" . tronquer($dataAnalyse["anterioTableauBrut"][$keyAnterio]["anterio"], 150, "...", true, $tooltip . "<br/><br/>");
						}
						else {
							$anterio .= "<NOBR><span style=\"" . ($dataAnalyse["anterioTableauBrut"][$keyAnterio]["borne"] != 0 ? "color:red;" : "") . "\" title=\"" . $tooltip . "\">" . $dataAnalyse["anterioTableauBrut"][$keyAnterio]["anterio"] . "</span></NOBR>";
						}

						$anterio .= "</TD>";
						$anterioConv .= "<TD class=\"descrGrand\" align=right><NOBR>" . $dataAnalyse["anterioConvTableau"][$keyAnterio] . "</NOBR></TD>";
					}
				}
				else {
					$anterio = "-";
					$anterioDate = "";

					if ($dataAnalyse["SanterioriteBrut"] != "") {
						$tooltip = sprintf(_s("Le %s"), affichedate($dataAnalyse["SanterioriteDate"])) . "\n" . $dataAnalyse["SanterioriteHeure"];

						if ($dataAnalyse["resultatType"] == "texteCodifie") {
							$anterio = "<span style=\"" . ($dataAnalyse["SanterioriteBorne"] != 0 ? "color:red;" : "") . "\">" . tronquer($dataAnalyse["SanterioriteBrut"], 200, "...", true, $tooltip . "<br/><br/>") . "</span>";
						}
						else {
							$anterio = "<NOBR><span style=\"" . ($dataAnalyse["SanterioriteBorne"] != 0 ? "color:red;" : "") . "\" title=\"" . $tooltip . "\">" . $dataAnalyse["SanterioriteBrut"] . "</span></NOBR>";
						}
					}

					if ($dataAnalyse["SanterioriteDate"] != "") {
						$anterioDate = $dataAnalyse["SanterioriteDate"];
					}

					if (($anterioDate != "") && ($anterioDate != $anterioDateOld)) {
						echo "<TR class=corps><TD colspan=\"" . ($colspan - 1) . "\"></TD><TD class=corpsFonce style=\"text-align:right\">" . affichedate($anterioDate) . "</TD></TR>";
						$anterioDateOld = $anterioDate;
					}

					$anterio = "<TD class=\"descrGrand\" align=right>" . ($dataAnalyse["SanterioriteValTech"] == 1 ? "*&nbsp;" : "") . $anterio . "</TD>";
				}

				if (0 < $dataAnalyse["valideBioPar"]) {
					$bonusStyleResu = "";
					$strValPar = $dataAnalyse["initialBiologiste"];
					$strValParTitle = $dataAnalyse["nomBiologiste"] . " " . $dataAnalyse["prenomBiologiste"] . " / " . affichedate($dataAnalyse["valideBioDate"]) . " " . substr($dataAnalyse["valideBioHeure"], 0, 5);
					$timestampValCur = strtotime($dataAnalyse["valideBioDate"] . " " . $dataAnalyse["valideBioHeure"]);

					if ($dernierValideurBioTime < $timestampValCur) {
						$dernierValideurBioTime = $timestampValCur;
						$dernierValideurBioStr = sprintf(_s("par %s le %s � %s"), $dataAnalyse["nomBiologiste"] . " " . $dataAnalyse["prenomBiologiste"], affichedate($dataAnalyse["valideBioDate"]), substr($dataAnalyse["valideBioHeure"], 0, 5));
					}
				}
				else {
					$bonusStyleResu = "font-style:italic;";
					$strValPar = "<img src=\"images/attentionPetit.gif\">";
					$strValParTitle = _s("R�sultat non valid� biologiquement");
				}

				$icoCommentaire = "";

				if ($dataAnalyse["commentaire" . ucfirst($patientLogged->niveau)] != "") {
					$icoCommentaire = "<img src=\"images/icoWarning.gif\" title=\"" . trim($dataAnalyse["commentaire" . ucfirst($patientLogged->niveau)]) . "\"> ";
				}

				$strConversion = "";
				$rowspan = "1";
				if (($dataAnalyse["resultatConversion"] != "") && !$resReplaced) {
					$strConversion = "<TR class=$class><TD class=\"descrGrand\" align=right style=\"$bonusStyleResu\">" . changetxtana($dataAnalyse["resultatConversion"]) . "</TD><TD class=\"descrGrand\" align=left><NOBR>&nbsp;" . $dataAnalyse["resultatConversionUnite"] . "</NOBR></TD><TD class=\"descrGrand\" align=center><NOBR>" . $dataAnalyse["resultatConversionBorne"] . "</NOBR> </TD>";

					if ($anterioriteTableau) {
						$strConversion .= $anterioConv;
					}
					else {
						$strConversion .= "<TD class=\"descrGrand\" align=right><NOBR>" . ($dataAnalyse["resultatConversionAnterio"] != "" ? $dataAnalyse["resultatConversionAnterio"] : "-") . "</NOBR></TD>";
					}

					$rowspan = "2";
				}

				if ($dataAnalyse["resultatType"] == "nombre") {
					if (preg_match("/^[0-9\<\>\ \.]+$/", $monResultat, $match) == 0) {
						$dataAnalyse["resultatType"] = "texteCodifie";
					}
				}

				$asterisk = "";

				if (0 < $dataAnalyse["correspId"]) {
					if (!in_array($dataAnalyse["correspNom"], $tabExecutant)) {
						$tabExecutant[] = $dataAnalyse["correspNom"];
					}

					$asterisk = "<span style=\"float:right;font-size:9px;\">(" . (array_search($dataAnalyse["correspNom"], $tabExecutant) + 1) . ")</span>";
				}

				if ($dataAnalyse["resultatType"] == "texteCodifie") {
					echo "<TR class=$class><TD class=\"descrGrand " . $classListe . "\" align=left><NOBR>" . $asterisk . "&nbsp;" . changetxtana($monAnalyse) . " </NOBR></TD><TD class=\"descrGrand\" colspan=\"3\" align=right style=\"$bonusStyleResu\">" . changetxtana($monResultat) . "</TD><TD class=\"descrGrand\" align=center><NOBR>" . $img . "</NOBR></TD><TD class=\"descrGrand\" align=center title=\"" . $strValParTitle . "\"><NOBR>" . $strValPar . "</NOBR></TD>" . $anterio . "</TR>";
				}
				else {
					echo "<TR class=$class><TD class=\"descrGrand " . $classListe . "\" rowspan=" . $rowspan . " align=left><NOBR>" . $asterisk . "&nbsp;" . changetxtana($monAnalyse) . " </NOBR></TD><TD class=\"descrGrand\" align=right style=\"$bonusStyleResu\">" . $icoCommentaire . changetxtana($monResultat) . "</TD><TD class=\"descrGrand\" align=left><NOBR>&nbsp;" . $dataAnalyse["resultatUnite"] . "</NOBR></TD><TD class=\"descrGrand\" align=center><NOBR>" . $borne["str"] . "</NOBR> </TD><TD class=\"descrGrand\" rowspan=" . $rowspan . " align=center><NOBR>" . $img . "</NOBR></TD><TD class=\"descrGrand\" rowspan=" . $rowspan . " align=center title=\"" . $strValParTitle . "\"><NOBR>" . $strValPar . "</NOBR></TD>" . $anterio . "</TR>" . $strConversion;
				}
			}
		}

		echo "</TABLE>";
		echo "<br /><SPAN class=descr><B>" . _s("Indicateur Anormalit�") . " :</B><img src=\"images/borneDepasseBas.gif\"> : " . _s("inf�rieur � la normale") . " ; <img src=\"images/borneNormale.gif\"> : " . _s("normal") . " ; <img src=\"images/borneDepasseHaut.gif\"> : " . _s("sup�rieur � la normale") . "</SPAN>";
		echo "<br /><br /><SPAN class=descr><B> * </B>: " . _s("R�sultat valid� techniquement uniquement") . "</SPAN>";

		if (0 < count($tabExecutant)) {
			echo "<br /><span class=descr><br /><b>" . _s("Laboratoire(s) ex�cutant(s)") . " :</b> ";

			foreach ($tabExecutant as $iExec => $nomExec ) {
				echo "<span style=\"font-size:9px;\"> (" . ($iExec + 1) . ") " . $nomExec . "&nbsp;&nbsp;&nbsp;";
			}
		}

		echo "<br /><br />";
		$tmp = ob_end_get_contents();
		$strGarde = "";

		if ($dataPatient["gardeBio"] != "") {
			$strGarde = " " . sprintf(_s("sous la responsabilit� de %s"), $dataPatient["gardeBio"]);
		}

		$head = "<CENTER><span class=corps style=\"font-size:14px;\"> " . _s("Etat de la demande") . " : " . (($dataPatient["status"] == "valide") && (0 < $dataPatient["garde"]) ? "<span style=\"color:#009933;font-style:italic;\">" . _s("Lib�r�e en p�riode de garde") . "</span>" : getdemandestatusstr($dataPatient["status"])) . (($patientLogged->niveau == "patient") && ($dataPatient["status"] != "valide") ? "<br /><span style=\"font-size:11px;\">" . _s("Toutes les analyses ne sont pas termin�es, le compte rendu pdf sera disponible apr�s la validation biologique compl�te.") . "</span>" : "") . (($dernierValideurBioStr != "") && (($dataPatient["status"] == "valide") || ($dataPatient["status"] == "valideValab")) ? "<br /><span style=\"font-size:10px;\">" . $dernierValideurBioStr . $strGarde . "</span>" : "") . "</span></CENTER><BR>";
		$tmp = $head . $tmp;
		if (in_array($typeDestinataire, array("medecin", "correspondant")) && in_array($dataPatient["status"], array("enCours", "complet")) && in_array($dataPatient["dataInter"]["kaliresNonValide"], array(0, 1)) && getsroption("kaliResGeneratePartiel")) {
			if ($_GET["showCRPartiel"] == "1") {
				$tmp2 .= "<IFRAME width=95% height=700 id='frameCrPartiel' src='showFileCRPartiel.php?id=" . $sIdDossier . "&numDemande=" . $sNumDossier . "'></IFRAME>";
			}
			else {
				$tmp2 .= "<br /><span class=\"corpsFonce\" style='font-size: 12px;'><b><a href=\"afficheDossier.php?sNumDossier=" . $sNumDossier . "&sIdDossier=" . $sIdDossier . "&showCRPartiel=1\">" . _s("CLIQUEZ ICI pour afficher le compte-rendu partiel") . "</b></a></span>";
			}
		}
		else {
			if (is_array($dataPatient["tabImpr"]) && (0 < count($dataPatient["tabImpr"]))) {
				$iCr = 1;
				$selectCr = "<select name=\"crSelected\" onChange=\"$('#frameCr').attr('src','showFileCR.php/'+$('option:selected',this).attr('nom')+'?id=" . $dataPatient["id"] . "&numDemande=" . $dataPatient["numDemande"] . "&crSelected='+$('option:selected',this).attr('value')+'');\">";

				foreach ($dataPatient["tabImpr"] as $key => $imprInfo ) {
					if (($imprInfo["exportKalires"] == 1) && ($dataPatient["status"] == "valide")) {
						$crSelected = $imprInfo["id"];
					}

					if (!isset($crSelected) && (count($dataPatient["tabImpr"]) == $iCr)) {
						$crSelected = $imprInfo["id"];
					}

					$dataPatient["tabImpr"][$key]["nomFichier"] = $nomPdfDemande = str_replace(array(" ", "-", "/"), array("_"), $dataPatient["numDemande"] . " " . $imprInfo["nom"] . ".pdf");
					$selectCr .= "<option value=\"" . $imprInfo["id"] . "\" nom=\"" . _secho($dataPatient["tabImpr"][$key]["nomFichier"]) . "\" " . ($crSelected == $imprInfo["id"] ? "SELECTED" : "") . ">" . affichedate($imprInfo["date"]) . " " . substr($imprInfo["heure"], 0, 5) . " - " . $imprInfo["nom"] . "</option>";
					$iCr++;
				}

				$selectCr .= "</select>";
				$tmp2 .= "<br /><center>" . $selectCr;

				if ($valideDateHeureDemande != "") {
					$tmp2 .= "<br /><br /><span style=\"font-size:11px;\"><b>" . sprintf(_s("Demande valid�e biologiquement le %s � %s"), affichedate($valideDateHeureDemande), substr($valideDateHeureDemande, -8)) . "</b></span></center><br />";
				}

				if (0 < $crSelected) {
					$tmp2 .= "<IFRAME width=95% height=700 id='frameCr' src='showFileCR.php/" . $dataPatient["tabImpr"][$crSelected]["nomFichier"] . "?id=" . $dataPatient["id"] . "&numDemande=" . $dataPatient["numDemande"] . "&crSelected=" . $crSelected . "'></IFRAME>";
				}
				else {
					$tmp2 .= "<br /><br /><span class=corpsFonce><b>" . _s("Veuillez s�lectionner un compte-rendu � afficher") . "</b></span><br /><br />";
				}
			}
			else {
				$tmp2 .= "<br /><br /><span class=corpsFonce><b>" . _s("Aucun fichier de compte-rendu accessible pour le moment") . "</b></span><br /><br />";
			}
		}

		$scd = new SoapClientDemande();
		$params = array("typeDestinataire" => $typeDestinataire, "numPermanent" => $dataPatient["numPermanent"], "patientId" => $patientLogged->id(), "patientNiveau" => $patientLogged->niveau);
		$dataAnteriorite = $scd->getDataAnteriorite($params);
		$tmp3 = "<table align=center cellpadding=1 cellspacing=1 border=0 width=98% style=\"border:1px solid #ccc;\">";
		$tmp3 .= "<tr class=titreBleu><td colspan=3>" . _s("Num�ro de demande") . "</td><td>" . _s("Date de la demande") . "</td><td>Etat</td></tr>";

		if (is_array($dataAnteriorite)) {
			foreach ($dataAnteriorite as $key => $dataAnt ) {
				if ($typeDestinataire != "patient") {
					$str = $dataAnt["strPatient"];
				}

				$tmp3 .= "<tr style=\"height:25px\" class=\"corpsFonce\"><td align=center><a class=img href=\"afficheDossier.php?sNumDossier=" . $dataAnt["numDemande"] . "&sIdDossier=" . $dataAnt["id"] . "\"><img border=0 src=\"" . imagepath("icoloupe.gif") . "\"></a></td><td " . ($typeDestinataire == "patient" ? "colspan=2" : "") . " align=\"center\"><a href=\"afficheDossier.php?sNumDossier=" . $dataAnt["numDemande"] . "&sIdDossier=" . $dataAnt["id"] . "\">" . $dataAnt["numDemande"] . "</a></td>" . ($typeDestinataire != "patient" ? "<td class=descr>$str</td>" : "") . "<td align=\"center\">" . affichedate($dataAnt["saisieDate"]) . "</td><td align=\"center\">" . getdemandestatusstr($dataAnt["status"]) . "</td></tr>";
			}
		}

		$tmp3 .= "</TABLE>";
		$ongletCr = ((($typeDestinataire == "patient") && getsroption("patientOngletCr")) || ($_GET["showCRPartiel"] == "1")) && ($nomFichier !== false);
		$tab[] = array("selected" => !$ongletCr, "name" => "<NOBR>" . _s("R�sultats") . "</NOBR>", "data" => $tmp);
		$tab[] = array("selected" => $ongletCr, "name" => "<NOBR>" . _s("Compte rendu") . "</NOBR>", "data" => $tmp2);
		if (($typeDestinataire == "medecin") || ($typeDestinataire == "correspondant") || ($typeDestinataire == "preleveur") || (($typeDestinataire == "patient") && $affichAnt)) {
			$tab[] = array("selected" => false, "name" => "<NOBR>" . _s("R�sultats ant�rieurs") . "</NOBR>", "data" => $tmp3);
		}

		echo "<center>" . navgettab("monTableau", $tab, "width=95%") . "</center>";
	}
}

echo "<!-- /phpmyvisites -->\n";
affichefoot();

?>
