<?php

function exec_log_cmd($cmd, &$log)
{
	$log .= "Ex�cution de la commande : '$cmd'\n";
	exec($cmd, $out, $ret);

	foreach ($out as $row ) {
		$log .= "output: " . $row . "\n";
	}

	$log .= "return: {$ret}\n";
	return $ret;
}

function test_services()
{
	global $SERVER_SERVICES;
	global $SERVER_TYPE;
	global $restriction_service;

	if (is_array($restriction_service)) {
		$serviceToCheck = array();

		foreach ($restriction_service as $serviceRestricted ) {
			$serviceToCheck[$serviceRestricted] = $SERVER_SERVICES[$SERVER_TYPE][$serviceRestricted];
		}
	}
	else {
		$serviceToCheck = $SERVER_SERVICES[$SERVER_TYPE];
	}

	$log_json = array();
	$log_json["nom"] = "-- Tests des services (2) -------------";
	$log_services = "\n" . $log_json["nom"] . "\n";
	$problem_service = CHECKSERVEUR_OK;

	foreach ($serviceToCheck as $name => $data ) {
		$log_json["process"][$name]["type"] = "nonCritique";
		$log_json["process"][$name]["etat"] = "";
		$process = $data["process"];
		$required = $data["critical"] == true;
		$pid = 0;
		$log_service = "$name, ";

		if ($required) {
			$log_service .= "critique, ";
			$log_json["process"][$name]["type"] = "critique";
		}

		if (service_installed($name)) {
			$log_service .= "install�, ";
			$log_json["process"][$name]["etat"] = "installe";

			if ($data["pidfile"] != "") {
				if (file_exists($data["pidfile"])) {
					$log_service .= "pid : " . service_getpid($name) . ", ";

					if (0 < $data["port"]) {
						$log_service .= "port : " . $data["port"] . ", ";
						$fp = fsockopen("127.0.0.1", $data["port"], $errno, $errstr, 30);

						if (!$fp) {
							$log_service .= "$errstr, ALERTE: REDEMARRAGE DU SERVICE";
							service_do($name, "restart", $output);
							print_output($output, $log_service);
							$problem_service = CHECKSERVEUR_ERROR;
							$log_json["process"][$name]["action"] = "restart";
							$log_json["process"][$name]["etat"] = "nonLanceNOK";
						}
						else {
							$log_json["process"][$name]["etat"] = "lanceOK";
							$log_service .= "Test de connection r�ussi.";
							fclose($fp);
						}
					}
					else {
						$log_service .= "OK.";
						$log_json["process"][$name]["etat"] = "lanceOK";
					}
				}
				else if ($required == 1) {
					$log_service .= "non lanc�, ALERTE: DEMARRAGE DU SERVICE";
					$output = array();
					service_do($name, "start", $output);
					print_output($output, $log_service);
					$problem_service = CHECKSERVEUR_ERROR;
					$log_json["process"][$name]["action"] = "start";
					$log_json["process"][$name]["etat"] = "nonLanceNOK";
				}
				else {
					$log_service .= "non lanc� : OK.";
					$log_json["process"][$name]["etat"] = "nonLanceOK";
				}
			}
			else {
				if ((0 < ($pid = service_running($name))) || (($name == "firewall") && service_firewall_running())) {
					$log_service .= "lanc� : OK.";
					$log_json["process"][$name]["etat"] = "lanceOK";
				}
				else if ($required == 1) {
					$log_service .= "non lanc�, ALERTE: DEMARRAGE DU SERVICE";
					$output = array();
					service_do($name, "start", $output);
					print_output($output, $log_service);
					$problem_service = CHECKSERVEUR_ERROR;
					$log_json["process"][$name]["action"] = "start2";
					$log_json["process"][$name]["etat"] = "nonLanceNOK";
				}
				else {
					$log_service .= "non lanc� : OK.";
					$log_json["process"][$name]["etat"] = "nonLanceOK";
				}
			}
		}
		else if ($required) {
			if (($data["alternative"] !== "") && service_installed($data["alternative"])) {
				$log_service .= "non install� : OK., service alternatif : " . $data["alternative"] . " install�.";
				$log_json["process"][$name]["etat"] = "nonInstalleOK";
			}
			else {
				$log_service .= "non install� : NOK.";
				$log_json["process"][$name]["etat"] = "nonInstalleNOK";
				$problem_service = CHECKSERVEUR_ERROR;
			}
		}
		else {
			$log_service .= "non install� : OK.";
			$log_json["process"][$name]["etat"] = "nonInstalleOK";
		}

		$log_service .= "\n";
		$log_json["process"][$name]["msg"] = $log_service;
		$log_services .= $log_service;
	}

	return array($log_services, $log_json, $problem_service);
}

function test_services_deported()
{
	global $SERVER_SERVICES_DEPORTED;
	global $SERVER_TYPE;
	global $conf;
	$log_json = array();
	$log_json["nom"] = "-- " . _s("Tests des services d�port�s") . "(2) -------------";
	$log_services = "\n" . $log_json["nom"] . "\n";
	$problem_service = CHECKSERVEUR_OK;

	foreach ($SERVER_SERVICES_DEPORTED[$SERVER_TYPE] as $name => $data ) {
		$log_json["process"][$name]["type"] = "nonCritique";
		$log_json["process"][$name]["etat"] = "";
		$required = $data["critical"] == true;
		$log_service = "$name, ";

		if ($required) {
			$log_service .= "critique, ";
			$log_json["process"][$name]["type"] = "critique";
		}

		$fp = fsockopen($conf["serveur"], $data["port"], $errno, $errstr, 30);

		if (!$fp) {
			$problem_service = CHECKSERVEUR_ERROR;
			$log_json["process"][$name]["etat"] = "nonLanceNOK";
		}
		else {
			$log_json["process"][$name]["etat"] = "lanceOK";
			$log_service .= _s("Test de connection r�ussi.");
			fclose($fp);
		}

		$log_service .= "\n";
		$log_json["process"][$name]["msg"] = $log_service;
		$log_services .= $log_service;
	}

	return array($log_services, $log_json, $problem_service);
}

function test_mail()
{
	global $SERVER_MAXMAILTIME;
	$fetchmailSleep = 30;
	$minutes = 30;
	$temporisation = 60;
	$killTime = 120;
	$service = "fetchmail";
	$log_json = array();
	$log_json["nom"] = "-- Recherche de mails -------------";
	$log_mail = "\n" . $log_json["nom"] . "\n";
	ob_start();
	$lastMail = date("d-m-Y H:i:s", getlastmail());
	$log_lastMail = ob_get_contents();
	ob_end_clean();

	if ($log_lastMail !== "") {
		$log_mail .= $log_lastMail;
		$problem_mail = CHECKSERVEUR_ERROR;
	}
	else {
		$log_mail .= "Dernier mail recu le : " . $lastMail . "\n";
		$log_json["lastMail"] = $lastMail;
		$problem_mail = CHECKSERVEUR_OK;

		if (!checklastmail()) {
			$log_mail .= "Le dernier mail re�u a plus de " . $SERVER_MAXMAILTIME . " heures.\n";
			$output = array();
			$retourCheckPid = checkpidtime(array("cmd" => $service, "minutes" => $minutes, "temporisation" => $temporisation, "timeBeforeKill" => $killTime, "log" => true));

			if ($retourCheckPid["code"] == "old") {
				$log_mail = "ERREUR : La recherche mail ne fonctionne pas - Processus en cours depuis " . $retourCheckPid["timeHR"] . " !";
				$problem_mail = CHECKSERVEUR_ERROR;
			}
			else {
				if (in_array($retourCheckPid["code"], array("new", "empty1", "empty2")) && ($retourCheckPid["avertTime"] != 0)) {
					$log_mail = "RETABLISSEMENT : La recherche mail est repartie - Alerte transmise la derni�re fois le " . $retourCheckPid["avertTimeHR"];
					$problem_mail = CHECKSERVEUR_RETABLISSEMENT;
					avertfileexists(array("name" => $service, "deleteFile" => true));
				}
				else if ($retourCheckPid["code"] == "oldTempo") {
					$log_mail = "INPROGRESS : RechercheMail en cours...temporisation de l'alerte";
					$problem_mail = CHECKSERVEUR_INPROGRESS;
				}
				else if (!in_array($retourCheckPid["code"], array("new", "current", "oldTempo"))) {
					$return = checkfetchmail($output);
					$nb = 0;
					while ((1 < (int) $return) && ($nb < 3)) {
						if ((int) $return == 8) {
							$log_mail .= "Fetchmail est d�j� lanc� ($return), on r�essaye dans $fetchmailSleep secondes.\n";
						}
						else {
							$log_mail .= "Fetchmail a retourn� une erreur $return, relance dans $fetchmailSleep secondes.\n";
						}

						sleep($fetchmailSleep);
						$return = checkfetchmail($output);
						$nb++;
					}

					if (1 < $return) {
						$log_mail .= "ERREUR: La recherche de mail ne fonctionne pas ($return).\n";
						print_output($output, $log_mail);
						$problem_mail = CHECKSERVEUR_ERROR;
					}
					else {
						$log_mail .= "La recherche de mail fonctionne. ($return)\n";
						avertfileexists(array("name" => $service, "deleteFile" => true));
					}
				}
				else {
					$log_mail .= "La recherche de mail fonctionne, t�che en cours depuis " . $retourCheckPid["timeHR"] . ".\n";
					avertfileexists(array("name" => $service, "deleteFile" => true));
				}
			}
		}
		else {
			$log_mail .= "La recherche de mail fonctionne.\n";
			avertfileexists(array("name" => $service, "deleteFile" => true));
		}
	}

	$log_json["msg"] = $log_mail;
	return array($log_mail, $log_json, $problem_mail);
}

function test_disque()
{
	global $SERVER_MINSPACEPCT;
	$log_disque = "";
	$log_json = array();
	$log_json["nom"] = "-- Espace Disque -------------";
	$log_disque = "\n" . $log_json["nom"] . "\n";
	$problem_disque = CHECKSERVEUR_OK;
	$lesPart = checkdiskspace();
	$erreur = 0;

	foreach ($lesPart as $part => $data ) {
		if (strpos(str_pad($part, 10, " "), "cdrom") === false) {
			$log_disque .= str_pad($part, 10, " ") . str_pad($data["occupe"], 10, " ") . "/ " . str_pad($data["total"], 10, " ") . " (" . $data["pct"] . "%)\n";
			$log_json["partition"][$part] = $data;

			if ($erreur == 0) {
				$erreur = $data["erreur"];
			}
		}
	}

	if ($erreur == 1) {
		$log_json["msg"] = "ALERT : Espace disque faible pour au moins une partition !!";
		$log_json["seuil"] = $SERVER_MINSPACEPCT;
		$problem_disque = CHECKSERVEUR_ERROR;
	}

	return array($log_disque, $log_json, $problem_disque);
}

function test_disque_distant()
{
	global $SERVER_DIST_MINSPACEPCT;
	$log_disque = "";
	$log_json = array();
	$log_json["nom"] = "-- Espace Disque Distant -------------";
	$log_disque = "\n" . $log_json["nom"] . "\n";
	$problem_disque = false;
	$lesPart = checkdiskspacedistant();
	$erreur = 0;

	foreach ($lesPart as $part => $data ) {
		$log_disque .= str_pad($data["serveurDistant"] . ":" . $data["repertoireDistant"], 70) . str_pad($part, 40, " ") . str_pad($data["occupe"], 10, " ") . "/ " . str_pad($data["total"], 10, " ") . " (" . $data["pct"] . "%)\n";
		$log_json["partition"][$part] = $data;

		if ($erreur == 0) {
			$erreur = $data["erreur"];
		}
	}

	if ($erreur == 1) {
		$log_json["msg"] = "ALERT : Espace disque faible pour au moins un volume distant !!";
		$log_json["seuil"] = $SERVER_DIST_MINSPACEPCT;
		$problem_disque = CHECKSERVEUR_ERROR;
	}

	return array($log_disque, $log_json, $problem_disque);
}

function test_kalirep_internet()
{
	$log_kalirep_internet = "";
	$log_json = array();
	$log_json["nom"] = "-- KaliRep Ping -------------";
	$log_kalirep_internet = "\n" . $log_json["nom"] . "\n";
	$problem_kalirep_ping = false;
	global $conf;
	$user = "root";
	$port = "22";
	$wan = "8.8.8.8";

	if (!is_array($conf["serveurReplication"])) {
		$listeServeurs = array($conf["serveurReplication"]);
	}
	else {
		$listeServeurs = $conf["serveurReplication"];
	}

	foreach ($listeServeurs as $serveur ) {
		if ($serveur != "") {
			exec("ssh -T -o StrictHostKeyChecking=no -p " . $port . " " . $user . "@" . $serveur . " <<**\n    ping -c5 " . $wan . "\n    **", $output, $res);

			if (preg_match("/[1-5] packets transmitted, [1-5] received/", implode(" ", $output))) {
				$erreur = 0;
			}
			else {
				$erreur = $output;
				$log_kalirep_internet .= "ALERT : Le serveur KaliRep '$serveur' n'a pas acc�s � Internet !";
				$log_json["msg"] = "ALERT : Le serveur KaliRep '$serveur' n'a pas acc�s � Internet !";
				$problem_kalirep_ping = CHECKSERVEUR_ERROR;
			}
		}
	}

	return array($log_kalirep_internet, $log_json, $problem_kalirep_ping);
}

function test_cups_jobs()
{
	$nbJobsMaxPerIp = 20;
	$log_cups_jobs = "";
	$log_json = array();
	$log_json["nom"] = "-- CUPS Jobs -------------";
	$log_cups_jobs = "\n" . $log_json["nom"] . "\n";
	$problem_cups_jobs = false;
	$error_cups = array();
	$listIp = array();
	$output = array();
	exec("/bin/ps axf | grep 'socket' | grep 'job'", $output, $res);

	foreach ($output as $line ) {
		if (preg_match("/^.* socket\:\/\/([0-9\.]+) .*$/", $line, $reg)) {
			$listIp[$reg[1]]++;
		}
	}

	foreach ($listIp as $ip => $nb ) {
		if ($nbJobsMaxPerIp < $nb) {
			$error_cups["SOCKET OUVERT > " . $nbJobsMaxPerIp][] = $ip . " (" . $nb . ")";
		}
	}

	$nbJobsMaxPerPrinter = 400;
	$output = array();
	exec("/bin/cat /etc/cups/printers.conf | grep '<Printer '", $output, $res);
	$printers = array();

	foreach ($output as $line ) {
		$printer = substr($line, 9, -1);

		if ($printer != "") {
			$printers[] = $printer;
		}
	}

	foreach ($printers as $printer ) {
		$output = array();
		exec("/usr/bin/lpstat -o '" . $printer . "'", $output, $res);
		$nbJobs = count($output);

		if ($nbJobsMaxPerPrinter < $nbJobs) {
			$error_cups["JOBS EN COURS > " . $nbJobsMaxPerPrinter][] = $printer . " (" . $nbJobs . ")";
		}
	}

	if (0 < count($error_cups)) {
		foreach ($error_cups as $type => $tabError ) {
			$erreur .= "<br />\r\n" . $type . " : " . implode(", ", $tabError);
		}

		$log_cups_jobs .= "ALERT : Des jobs CUPS restent en attente : " . $erreur;
		$log_json["msg"] = "ALERT : Des jobs CUPS restent en attente : " . $erreur;
		$problem_cups_jobs = CHECKSERVEUR_ERROR;
	}

	return array($log_cups_jobs, $log_json, $problem_cups_jobs);
}

function test_conf_files()
{
	$log_json = array();
	$log_json["nom"] = "-- CONF files -------------";
	$log_conf_files = "\n" . $log_json["nom"] . "\n";
	$problem_conf_files = false;
	$erreur = "";
	$files = array();
	$files[] = "/etc/apache2/apache2.conf";
	$files[] = "/etc/apache2/ports.conf";
	$files[] = "/etc/apache2/httpd.conf";
	$files[] = "/etc/apache2/sites-available/*";
	$files[] = "/etc/apache2/sites-enabled/*";
	$files[] = "/etc/mysql/*";
	$files[] = "/etc/mysql/conf.d/*";
	$files[] = "/etc/samba/smb.conf";
	$files[] = "/etc/cups/cupsd.conf";
	$files[] = "/etc/openvpn/*";
	$files[] = "/etc/vsftpd.conf";
	$files[] = "/etc/vsftpd/user_list";
	$files[] = "/etc/netika/*";
	$files[] = "/etc/netika/backup/*";
	$files[] = "/etc/netika/backup/dist.d/*";
	$files[] = "/etc/fetchmail*";
	$files[] = "/etc/dovecot/dovecot.conf";
	$files[] = "/etc/postfix/main.cf";
	$files[] = "/etc/postfix/master.cf";
	$files[] = "/etc/php5/apache2/php.ini";
	$files[] = "/etc/php5/cli/php.ini";
	$files[] = "/etc/crontab";
	$files[] = "/etc/cron.d/*";
	$files[] = "/etc/cron.daily/*";
	$files[] = "/etc/cron.hourly/*";
	$files[] = "/etc/cron.weekly/*";
	$files[] = "/etc/cron.monthly/*";
	$files[] = "/etc/hosts";
	$files[] = "/etc/network/interfaces";
	$files[] = "/etc/network/if-up.d/*";
	$files[] = "/etc/ntp.conf";
	$files[] = "/etc/passwd";
	$files[] = "/etc/group";
	$files[] = "/etc/rsyncd.conf";
	$files[] = "/etc/ssh/sshd_config";
	$files[] = "/etc/ssh/ssh_config";
	$files[] = "/root/.ssh/authorized_keys";
	$files[] = "/etc/sudoers";
	$files[] = "/etc/sudoers.d/*";
	$filesExclure = array();
	$filesExclure["/etc/cron.d/*"][] = "kalilab";
	$filesExclure["/etc/cron.d/*"][] = "demarrageConnexion*";
	$filesExclure["/etc/cron.d/*"][] = "impressionTacheFondOMR";
	$dirSave = "/home/kalilab/confSave";
	$found = array();
	@mkdir($dirSave);

	foreach ($files as $file ) {
		$strExclure = "";

		if (is_array($filesExclure[$file])) {
			$strExclure = " ! -name '" . implode("' ! -name '", $filesExclure[$file]) . "' ";
		}

		$tab = array();
		@exec("/usr/bin/find " . $file . " -maxdepth 0 -type f  ! -name 'README' " . $strExclure . "", $tab);

		foreach ($tab as $f ) {
			$found[] = $f;

			if (!file_exists($dirSave . $f)) {
				@mkdir(dirname($dirSave . $f), 493, true);
				copy($f, $dirSave . $f);
			}
			else if (md5_file($f) != md5_file($dirSave . $f)) {
				exec("/usr/bin/diff -b -I '^#' -I '^ #' " . $f . " " . $dirSave . $f . "", $tab2);

				if (0 < !empty($tab2)) {
					$erreur .= "<br />\r\n<b>" . $f . "</b> : <br />\r\n  " . implode("<br />\r\n  ", $tab2);
					$problem_conf_files = CHECKSERVEUR_ERROR;
				}

				@unlink($dirSave . $f);
				copy($f, $dirSave . $f);
			}
		}
	}

	$tab = array();
	@exec("/usr/bin/find $dirSave -maxdepth 4 -type f", $tab);

	foreach ($tab as $f ) {
		$f = str_replace($dirSave, "", $f);

		if (!in_array($f, $found)) {
			$erreur .= "<br />\r\n<b>" . $f . "</b> : <br />\r\n  Fichier supprim�";
			$problem_conf_files = CHECKSERVEUR_ERROR;
			@unlink($dirSave . $f);
		}
	}

	if ($problem_conf_files) {
		$log_conf_files .= "ALERT : Des fichiers de CONF ont �t� modifi�s : " . $erreur;
		$log_json["msg"] = "ALERT : Des fichiers de CONF ont �t� modifi�s : " . $erreur;
	}

	return array($log_conf_files, $log_json, $problem_conf_files);
}

function test_charge()
{
	$log_charge = "";
	$log_json = array();
	$log_json["nom"] = "-- Charge du syst�me -------------";
	$log_charge = "\n" . $log_json["nom"] . "\n";
	$problem_charge = CHECKSERVEUR_OK;
	$s = new sysInfo();
	$c = $s->cpu_info();
	$nombreCpus = max($c["cpus"], 1);
	$log_charge .= "Nombre de processeurs: {$nombreCpus}\n";
	$log_json["cpu"] = $nombreCpus;
	$coefficient = (double) 1 / $nombreCpus + 1.5;
	$seuil = $nombreCpus * $coefficient;
	$log_charge .= "Seuil de charge ((1/nbProcesseurs + 1.5) * nbProcesseurs): {$seuil}\n";
	$log_json["seuil"] = $seuil;
	$charge = (double) exec("cat /proc/loadavg | awk '{print \$2}'");
	$log_charge .= "Charge actuelle: {$charge}\n";
	$log_json["charge"] = $charge;

	if ($seuil < $charge) {
		$log_charge .= "Probl�me: Charge du serveur tr�s importante (" . $charge . ") !\n";
		$log_charge .= "\n";
		$problem_charge = CHECKSERVEUR_ERROR;
	}

	$log_charge .= "\n";
	$seuil_ram = 95;
	$c = $s->memory();
	$pc = 0;

	if (0 < $c["ram"]["total"]) {
		$pc = (($c["ram"]["total"] - $c["ram"]["free"] - $c["ram"]["buffers"] - $c["ram"]["cached"]) * 100) / $c["ram"]["total"];
	}

	if ($seuil_ram <= $pc) {
		$log_charge .= "Probl�me: RAM utilis�e � plus de " . $seuil_ram . "% (" . $pc . ") !\n";
		$log_charge .= "\n";
		$problem_charge = CHECKSERVEUR_ERROR;
	}

	if ($seuil_ram <= $c["swap"]["percent"]) {
		$log_charge .= "Probl�me: SWAP utilis� � plus de " . $seuil_ram . "% (" . $c["swap"]["percent"] . ") !\n";
		$log_charge .= "\n";
		$problem_charge = CHECKSERVEUR_ERROR;
	}

	if ($problem_charge == CHECKSERVEUR_ERROR) {
		$processEnCours = "";
		exec_log_cmd("ps faux", $processEnCours);
		$log_charge .= $processEnCours;
		$log_json["process"] = $processEnCours;
	}

	return array($log_charge, $log_json, $problem_charge);
}

error_reporting(30719 ^ 8 ^ 8192);
define("CHECKSERVEUR_OK", 0);
define("CHECKSERVEUR_INPROGRESS", 1);
define("CHECKSERVEUR_ERROR", 2);
define("CHECKSERVEUR_RETABLISSEMENT", 3);
$baseDir = dirname(__FILE__) . "/..";
$confFile = $baseDir . "/conf/conf.inc.php";

if (file_exists($confFile)) {
	include ($confFile);

	if (!isset($argv[1])) {
		$mode = "kalilab";

		if (KL_APP_NAME == "KaliSil") {
			$mode = "kalisil";
		}
	}
}
else {
	$confFile = $baseDir . "/include/conf.inc.php";

	if (file_exists($confFile)) {
		include ($confFile);
	}
	else {
		exit("ERROR : conf.inc.php not found");
	}
}

if (isset($argv[1]) && (strtolower($argv[1]) == "kalirep")) {
	$mode = "kalirep";
}
else {
	if (isset($argv[1]) && (strtolower($argv[1]) == "kalires")) {
		$mode = "kalires";
	}
	else {
		if (isset($argv[1]) && (strtolower($argv[1]) == "kalimodem")) {
			$mode = "kalimodem";
		}
		else {
			if (isset($argv[1]) && (substr($argv[1], 0, 5) == "test_")) {
				$mode = $argv[1];
			}
		}
	}
}

$testTodo = array();
$restriction_service = false;

switch ($mode) {
case "kalilab":
	$testTodo[] = "test_charge";
	$testTodo[] = "test_services";
	$testTodo[] = "test_mail";
	$testTodo[] = "test_disque";
	$testTodo[] = "test_disque_distant";
	break;

case "kalisil":
	$testTodo[] = "test_charge";
	$testTodo[] = "test_services";
	$testTodo[] = "test_services_deported";
	$testTodo[] = "test_mail";
	$testTodo[] = "test_disque";
	$testTodo[] = "test_disque_distant";
	$testTodo[] = "test_cups_jobs";
	$testTodo[] = "test_conf_files";
	break;

case "kalirep":
	$testTodo[] = "test_services";
	$testTodo[] = "test_charge";
	$testTodo[] = "test_disque";
	$testTodo[] = "test_disque_distant";
	$restriction_service = array("mysql");
	break;

case "kalires":
case "kalimodem":
	$testTodo[] = "test_services";
	$testTodo[] = "test_charge";
	$testTodo[] = "test_disque";
	$testTodo[] = "test_disque_distant";
	$restriction_service = array("apache2");
	break;

default:
	if (($mode != "") && function_exists($mode)) {
		$testTodo[] = $mode;
	}
	else {
		exit("ERROR : no mode defined");
	}

	break;
}

$heure = (int) date("H");
$minute = (int) date("i");
if (($heure == 3) || (($heure == 4) && ($minute <= 30))) {
	exit("$heure:$minute, en attente : non lanc�.");
}

$adresseCC = "";
if (isset($_SERVER["argv"]) && is_array($_SERVER["argv"]) && isset($_SERVER["argv"][0]) && isset($_SERVER["argv"][1]) && (strpos($_SERVER["argv"][1], "@") !== false)) {
	$adresseCC = $_SERVER["argv"][1];
}

if (!function_exists("_s")) {
	function _s($txt)
	{
		return $txt;
	}
}

$baseDir = dirname(__FILE__) . "/..";
include_once ($baseDir . "/include/lib.serverStatus.inc.php");
include_once ($baseDir . "/include/lib.sysInfo.inc.php");
include_once ($baseDir . "/include/class.phpmailer.php");

if (!function_exists("klog")) {
	function klog($dummy, $log)
	{
		echo $log . "\n";
	}
}

if (!function_exists("utf8_array")) {
	function utf8_array($array)
	{
		return is_array($array) ? array_map("utf8_array", $array) : utf8_encode($array);
	}
}

$mail_errors = "recherchemail@netika.net";
$problem = false;
$tabContent = array();
$tabContent["info"]["Licence"] = $licence["numero"];
$tabContent["info"]["Host"] = $sysInfo["hostname"];
$tabContent["info"]["Ip"] = $sysInfo["ip"];
$tabContent["info"]["Date"] = date("d-m-Y H:i:s");
$tabContent["info"]["Distribution"] = $sysInfo["distrib"];
$tabContent["info"]["Type de serveur"] = $SERVER_TYPE;
$tabContent["info"]["Application"] = KL_APP_NAME;
$tabContent["info"]["Version des fichiers"] = get_kl_version();
$tabContent["info"]["Uptime"] = trim(shell_exec("uptime"));
$log .= "== TESTS DU SERVEUR =====================\n";
$log .= "Host : " . $sysInfo["hostname"] . "\n";
$log .= "Ip : " . $sysInfo["ip"] . "\n";
$log .= "Date : " . date("d-m-Y H:i:s") . "\n";
$log .= "Distribution : " . $sysInfo["distrib"] . "\n";
$log .= "Type de serveur : {$SERVER_TYPE}\n";
$log .= "Mode : {$mode}\n";
$log .= "Application : " . KL_APP_NAME . "\n";
$log .= "Mode : " . $mode . "\n";
$log .= "Version des fichiers : " . get_kl_version() . "\n";
$log .= trim(shell_exec("uptime")) . "\n";
$test_functions = array(
	"test_charge"            => array("temporisation" => 60),
	"test_services"          => array("temporisation" => 60, "SHA1Pid" => true),
	"test_services_deported" => array("temporisation" => 60),
	"test_mail"              => array("temporisation" => 60),
	"test_disque"            => array("temporisation" => 60),
	"test_disque_distant"    => array("temporisation" => 60),
	"test_kalirep_internet"  => array("temporisation" => 60),
	"test_cups_jobs"         => array("temporisation" => 60),
	"test_conf_files"        => array("temporisation" => 60)
	);
$logTab = array();
$tabProblem = array();

foreach ($test_functions as $function => $functionParam ) {
	if (!in_array($function, $testTodo)) {
		continue;
	}

	list($logtmp, $logTab, $problemtmp) = $function();

	if (in_array($problemtmp, array(CHECKSERVEUR_ERROR, CHECKSERVEUR_RETABLISSEMENT))) {
		$log .= $logtmp;
		$tabContent["services"][$function] = array("code" => $problemtmp, "message" => $logTab);
	}

	switch ($problemtmp) {
	case CHECKSERVEUR_ERROR:
		makepidfile(array("name" => $function, "data" => $functionParam, "dataSHA1" => $logtmp));
		$dataTemporisation = checkpidtime(array("cmd" => $function, "name" => $function, "fncPerso" => "delayAvert", "log" => true, "minutes" => $functionParam["minutes"], "temporisation" => $functionParam["temporisation"], "SHA1Pid" => $functionParam["SHA1Pid"], "dataSHA1" => $logtmp, "deleteOnNew" => false));
		if (($dataTemporisation["code"] == "old") || ($dataTemporisation["code"] == "new")) {
			$problem = true;
			$tabProblem[] = $function;
		}

		break;

	case CHECKSERVEUR_OK:
		$avertissement = pidfileexists(array("name" => $function, "deleteFile" => true));

		if ($avertissement["present"]) {
			avertfileexists(array("name" => $function, "deleteFile" => true));
			$log .= "R�tablissement du service : " . $function . "\n";
			$tabContent["services"][$function] = array("code" => CHECKSERVEUR_RETABLISSEMENT, "message" => sprintf("r�tablissement - date de cr�ation de l'avertissement : %s", $avertissement["time"]));
			$problem = true;
		}

		break;

	case CHECKSERVEUR_RETABLISSEMENT:
		avertfileexists(array("name" => $function, "deleteFile" => true));
		pidfileexists(array("name" => $function, "deleteFile" => true));
		$log .= "R�tablissement du service : " . $function . "\n";
		$tabContent["services"][$function] = array("code" => CHECKSERVEUR_RETABLISSEMENT, "message" => "r�tablissement du service");
		$problem = true;
		break;
	}
}

$filtrage = array("Licence", "Date", "Application");
$tabContent = utf8_array($tabContent);
echo $log;
if ($problem && ($conf["debug"] == false)) {
	echo "\n";
	$str = "Un probleme a �t� d�tect�, envoi du mail a " . $mail_errors . ($adresseCC != "" ? " et " . $adresseCC : "");
	$nb = strlen($str) + 10;

	for ($i = 0; $i < $nb; $i++) {
		echo "-";
	}

	echo "\n| !! " . $str . " !! |\n";

	for ($i = 0; $i < $nb; $i++) {
		echo "-";
	}

	echo "\n";
	$mail = new phpmailer();
	$mail->Encoding = "base64";
	$mail->From = $conf["email"];
	$mail->FromName = $licence["detenteur"][0];
	$mail->Host = $conf["smtp"];
	$mail->Mailer = "smtp";
	$mail->AddAddress($mail_errors, "NETIKA");

	if ($adresseCC != "") {
		$mail->AddCC($adresseCC, $adresseCC);
	}

	$mail->Subject = "ALERT PROBLEME SERVEUR [NG][" . $mode . "] " . $sysInfo["hostname"] . " : " . implode(", ", $tabProblem) . "";
	$mail->Body = $log;
	$mail->IsHTML(true);

	if (($json = json_encode($tabContent)) !== false) {
		$mail->AltBody = $json;
	}
	else {
		$mail->AltBody = json_encode(array("erreur encodage JSON"));
		echo "erreur encodage JSON";
	}

	foreach ($tabContent["info"] as $tKey => $tValue ) {
		if (in_array($tKey, $filtrage)) {
			$mail->AddCustomHeader("X-NETIKA-" . str_replace(" ", "_", strtoupper($tKey)) . ":" . preg_replace("/\R/", "", $tValue));
		}
	}

	$mail->AddCustomHeader("X-NETIKA-TYPE:" . pathinfo($_SERVER["SCRIPT_FILENAME"], PATHINFO_FILENAME));

	if (!$mail->Send()) {
		echo "Erreur d'envoi du mail : " . $mail->ErrorInfo . "\n";
	}

	$mail->ClearAddresses();
	$mail->ClearAttachments();
}
else {
	echo "\nAucun mail a envoyer.\n";
}

?>
