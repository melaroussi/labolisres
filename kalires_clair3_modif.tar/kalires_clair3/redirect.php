<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
affichehead(_s("Redirection vers une demande") . " - " . getsroption("laboNom"), "", true);
entete();
$typePaiement = getsroption("interfacePaiement");
if (is_a($patientLogged, "PatientLogged") && (0 < $patientLogged->id()) && ($patientLogged->niveau == "patient") && ((isset($_GET["token"]) && ($typePaiement == "CBI")) || istypepaiementok($typePaiement))) {
	$scd = new SoapClientDemande();
	$params = array("patientId" => $patientLogged->id(), "patientNiveau" => $patientLogged->niveau);

	if ($typePaiement == "CBI") {
		$params["token"] = $_GET["token"];
	}
	else {
		include_once ($conf["baseDir"] . "include/epaiement/paiementEnLigne.ctrl.php");

		if (paiementEnLigneCtrl::isInterfaceMonoSite($typePaiement)) {
			$idSite = $_REQUEST["idSite"];
			$merchantId = getsiteoption("MERCHANT_ID_PAIEMENT", $idSite);
			$secretKey = getsiteoption("SECRET_KEY_PAIEMENT", $idSite);
		}
		else {
			$merchantId = getsroption("merchantIdPaiement");
			$secretKey = getsroption("secretKeyPaiement");
		}

		$paiement = paiementEnLigneCtrl::get($typePaiement, $merchantId, $secretKey, getsroption("tpeNumber"), getsroption("testPaiement"), "redirect");
		$retPaiement = $paiement->verifRetour();
		if (($typePaiement == "MONETICO") || ($typePaiement == "OGONE")) {
			$paiement->set("orderId", $retPaiement["idDemande"]);
			$paiement->set("transactionReference", $retPaiement["numDemande"]);
			$paiement->set("amount", $retPaiement["montant"]);
			$paiement->set("customerId", $params["patientId"]);
			$retour = $retPaiement["paiement"];

			if ($retour == "OK") {
				echo klmessage("info", "Retour de paiement", "Le paiement a r�ussi et a �t� enregistr� dans la demande.");
			}
			else if ($retour == "NOK") {
				echo klmessage("error", "Retour de paiement", "Le paiement a �chou�, veuillez essayer � nouveau.");
			}
		}

		$token = $paiement->calculateToken();
		$params["token"] = $token;
	}

	if (!isset($_GET["w"])) {
		$_GET["w"] = 0;
	}

	$ret = $scd->accesDemande($params);
	if (is_array($ret) && ($ret["status"] == "wait") && ($_GET["w"] <= 3)) {
		$$_GET["w"]++;
		klredir("redirect.php?token=" . $_GET["token"] . "&w=" . $_GET["w"] . "", 5, _s("Merci de patienter, paiement en cours de validation ..."));
		affichefoot();
		exit();
	}

	if (is_array($ret) && ($ret["status"] == "open") && ($ret["idDemande"] != "") && ($ret["numDemande"] != "")) {
		klredir("afficheDossier.php?sNumDossier=" . $ret["numDemande"] . "&sIdDossier=" . $ret["idDemande"] . "", 1, _s("Redirection en cours ..."));
		affichefoot();
		exit();
	}

	affichemessage("<font color=red>" . _s("Erreur : Vous n'avez pas acc�s � ce dossier, veuillez signaler ce probl�me au laboratoire") . "</font>");
	affichefoot();
	exit();
}
else {
	if (($_SESSION["paiementOffline"] == "ok") && ((isset($_GET["token"]) && ($typePaiement == "CBI")) || istypepaiementok($typePaiement))) {
		klredir("index.php", 5, "<span style=\"color:black;\">" . _s("Redirection en cours ...") . "</span>");
		affichefoot();
		exit();
	}
}

klredir("denied.php?type=redirect", 10, "<span style=\"color:red;\">" . _s("L'authentification a �chou�") . "</span>");
affichefoot();
exit();

?>
