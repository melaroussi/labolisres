<?php

ini_set("zlib.output_compression", "0");
if (isset($_GET["PHPSESSID"]) && ($_GET["PHPSESSID"] != "")) {
	session_id($_GET["PHPSESSID"]);
}

require_once ("include/conf.inc.php");
require_once ("include/lib.inc.php");
$token = $_REQUEST["token"];
if (!$patientLogged->isAuth() || !isset($_SESSION["kfile_token"][$token])) {
	header("HTTP/1.0 403 Forbidden");
	exit();
}

$file = $_SESSION["kfile_token"][$token]["file"];

if (($file = Kfile::get($file)) === false) {
	header("HTTP/1.0 404 Not Found");
	exit();
}

$inline = false;
if (isset($_REQUEST["inline"]) && ($_REQUEST["inline"] == "1")) {
	$inline = true;
}

ob_end_clean();
Kfile::pjGetContent(urldecode($file), "", "", $inline);

?>
