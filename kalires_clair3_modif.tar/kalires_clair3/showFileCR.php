<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
$id = $_GET["id"];
$numDemande = $_GET["numDemande"];
$crSelected = $_GET["crSelected"];
if ((0 < $id) && ($numDemande != "") && ($patientLogged->niveau != "") && (0 < $patientLogged->id()) && (0 < $crSelected)) {
	$cs = new SoapClientDemande();
	$dataCr = $cs->getFichierCR($id, $numDemande, $patientLogged->niveau, $patientLogged->id(), $crSelected);

	if ($dataCr != "") {
		$nomPdfDemande = $numDemande . ".pdf";
		header("Content-Description: File Transfer");
		header("Content-Type: application/pdf");
		header("Content-Disposition: inline; filename=\"" . $nomPdfDemande . "\"");
		header("Content-Transfer-Encoding: binary");
		header("Pragma: public");
		echo $dataCr;
	}
}

exit();

?>
