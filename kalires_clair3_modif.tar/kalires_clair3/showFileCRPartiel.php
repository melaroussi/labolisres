<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
$id = $_GET["id"];
$numDemande = $_GET["numDemande"];
if ((0 < $id) && ($numDemande != "") && ($patientLogged->niveau != "") && (0 < $patientLogged->id())) {
	$scd = new SoapClientDemande();
	$dataPartiel = $scd->getDataPartiel(array("typeDestinataire" => $patientLogged->niveau, "idDemande" => $id, "numDemande" => $numDemande, "idDestinataire" => $patientLogged->id()));

	if ($dataPartiel != "") {
		$nomPdfDemande = $numDemande . ".pdf";
		header("Content-Description: File Transfer");
		header("Content-Type: application/pdf");
		header("Content-Disposition: inline; filename=\"" . $nomPdfDemande . "\"");
		header("Content-Transfer-Encoding: binary");
		header("Pragma: public");
		echo $dataPartiel;
	}
}

exit();

?>
