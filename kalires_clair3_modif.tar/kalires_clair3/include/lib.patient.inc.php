<?php

class PatientLogged
{
	public $id = 0;
	public $numPermanent = 0;
	public $numIdentification = "";
	public $login = 0;
	public $nom = "";
	public $temps;
	public $idLog = 0;
	public $accordSigne = 0;
	public $cgu = 0;
	public $passwordExpired = false;
	public $userOption = array();
	public $messageAffiche = "";
	public $datePasswordExpired = "";
	public $numDemande = "";
	public $passwordToken = "";
	public $refAnalyse = 0;
	public $optionsUtilisateur = "";
	public $kaliresPrescription = 0;
	public $accountLocked = false;
	public $traceUser = "";
	public $tabChapitre = array();
	public $paiement = false;

	public function __construct($numeroSecu = "", $passwd = "", $numDossier = "", $typePersonne = "patient", $sha = false, $traceUser = "")
	{
		global $conf;
		global $securite;
		global $mabase;
		global $PHPSESSID;
		$_COOKIE = &$_COOKIE;
		global $cBdUniq;
		$passwd = trim($passwd);
		$this->traceUser = $traceUser;
		$this->accordSigne = false;
		$this->passwordExpired = false;
		$sc = new SoapClientKalires();

		if ($typePersonne == "patient") {
			$loginPatient = getsroption("kaliResPatient");
			$infosPatient = $sc->loginPatient($numeroSecu, $passwd, $numDossier);
			if (($infosPatient == false) || !$loginPatient) {
				$this->logout();
			}
			else if ($infosPatient->accountLocked) {
				$this->accountLocked = true;
				$this->logout();
			}
			else {
				if (0 < $infosPatient->refAnalyse) {
					$this->refAnalyse = 1;
				}

				$this->niveau = "patient";
				$this->id = $infosPatient->idPatient;
				$this->numPermanent = $infosPatient->numPermanent;
				$this->email = $infosPatient->email;
				$this->paiement = $infosPatient->paiement;
				$this->numIdentification = "";

				if (getsroption("affichAnt") == 0) {
					$this->numDemande = $infosPatient->numDemande;
				}

				$this->login = $infosPatient->idPatient;
				$this->passwordExpired = $infosPatient->changePassword;
				$this->passwordToken = $infosPatient->tokenPassword;
				$this->datePasswordExpired = $infosPatient->datePasswordExpired;
				$this->messageAffiche = $infosPatient->messageAffiche;
				$this->userOption = $infosPatient->userOption;
				$this->cgu = $infosPatient->cgu;

				if (0 < $this->cgu) {
					$this->accordSigne = true;
				}

				$this->nom = _secho($infosPatient->nom);
				$this->nom .= ($infosPatient->prenom != "" ? " " . _secho($infosPatient->prenom) : "");
				$this->temps["create"] = time();
				$cs = new SoapClientKalires();
				$cs->trace("patient", $this->id, "login", "", $this->traceUser);
			}
		}
		else {
			unset($_SESSION["filter"]);
			$loginMedecin = getsroption("kaliResMedecin");
			$loginCorrespondant = getsroption("kaliResCorrespondant");
			$loginPreleveur = getsroption("kaliResPreleveur");
			$infosLogin = $sc->loginDemandeur($numeroSecu, $passwd, $numDossier, $sha);

			if ($infosLogin == false) {
				$this->logout();
			}
			else {
				if ((($infosLogin->niveau == "medecin") && !$loginMedecin) || (($infosLogin->niveau == "correspondant") && !$loginCorrespondant) || (($infosLogin->niveau == "preleveur") && !$loginPreleveur)) {
					$this->logout();
				}
				else if ($infosLogin->accountLocked) {
					$this->accountLocked = true;
					$this->logout();
				}
				else {
					if (0 < $infosLogin->refAnalyse) {
						$this->refAnalyse = 1;
					}

					$this->niveau = $infosLogin->niveau;
					$this->id = $infosLogin->id;
					$this->numPermanent = "";
					$this->numIdentification = $infosLogin->numIdentification;
					$this->login = $infosLogin->id;
					$this->passwordExpired = $infosLogin->changePassword;
					$this->passwordToken = $infosLogin->tokenPassword;
					$this->datePasswordExpired = $infosLogin->datePasswordExpired;
					$this->messageAffiche = $infosLogin->messageAffiche;
					$this->userOption = $infosLogin->userOption;
					$this->cgu = $infosLogin->cgu;

					if (0 < $this->cgu) {
						$this->accordSigne = true;
					}

					$this->nom = _secho($infosLogin->nom);
					$this->nom .= ($infosLogin->prenom != "" ? " " . _secho($infosLogin->prenom) : "");
					$this->temps["create"] = time();
					$this->kaliresPrescription = $infosLogin->kaliresPrescription;
					$this->permalinkLevel = $infosLogin->permalinkLevel;
					$cs = new SoapClientKalires();
					$cs->trace($infosLogin->niveau, $this->id, "login", "", $this->traceUser);
					$this->optionsUtilisateur = $cs->getSrOptionsUtilisateur($this->id, $this->niveau);
					$this->tabChapitre = $infosLogin->tabChapitre;
					if (($this->userOption["clearFilter"] == 0) || (isset($_SESSION["accesPermalinkLevel"]) && ($_SESSION["accesPermalinkLevel"] == 2))) {
						if (is_array($infosLogin->filtre)) {
							$_SESSION["filter"] = $infosLogin->filtre;
						}
					}
					else {
						unset($_SESSION["filter"]);
					}
				}
			}
		}

		return true;
	}

	public function getOptionUtilisateur($option)
	{
		if (is_array($this->optionsUtilisateur)) {
			return $this->optionsUtilisateur[$option];
		}

		return false;
	}

	public function setOptionUtilisateur($option, $idUser, $typeUtilisateur)
	{
		$cs = new SoapClientKalires();
		$cs->setSrOptionsUtilisateur($option, $idUser, $typeUtilisateur);

		foreach ($option as $key => $value ) {
			$this->optionsUtilisateur[$key] = $value;
		}
	}

	public function logout()
	{
		global $PHPSESSID;
		global $cBdUniq;
		global $conf;
		$this->id = 0;
		$this->login = 0;
		$this->nom = "";
		$this->temps = array();
		$this->niveau = "";
		$this->traceUser = "";
		$this->accordSigne = false;
		unset($_SESSION["filter"]);
		unset($_SESSION["accesPermalink"]);
		unset($_SESSION["accesPermalinkLevel"]);
		unset($_SESSION["accesPermalinkNum"]);
		unset($_SESSION["accesPermalinkNumIPP"]);
	}

	public function update()
	{
		global $cBdUniq;
		global $PHPSESSID;
		global $conf;
		$sessDuree = 0;

		if ($this->niveau != "patient") {
			$sessDuree = getsroption("sessionTimePS");
		}
		else {
			$sessDuree = getsroption("sessionTimePatient");
		}

		if ((0 < $this->temps["update"]) && (0 < $sessDuree)) {
			if ($sessDuree <= (time() - $this->temps["update"]) / 60) {
				affichehead(_s("Serveur de r�sultats") . " - " . getsroption("laboNom"), "", false);
				entete();
				$this->logout();
				klredir($conf["baseURL"] . "index.php", 5, "Votre session a expir�e suite � un d�lai d'inactivit� trop long. Veuillez vous reconnecter.");
				exit();
			}
		}

		$this->temps["update"] = time();
	}

	public function id()
	{
		return $this->id;
	}

	public function nom()
	{
		return $this->nom;
	}

	public function isMe($id)
	{
		return $this->id() == $id;
	}

	public function isLogin()
	{
		return ($this->id != 0) && ($this->getNiveau() != "");
	}

	public function isAuth()
	{
		return ($this->id != 0) && ($this->getNiveau() != "") && $this->accordSigne;
	}

	public function setAccordSigne()
	{
		global $cBdUniq;
		$this->accordSigne = true;
		$this->cgu = 1;
		$sc = new SoapClientKalires();
		$sc->valideCGU($this->id, $this->niveau);
	}

	public function getNiveau()
	{
		return $this->niveau;
	}

	public function filtrageNiveau($niveauLimite, $urlNonAuth, $urlNonAcces)
	{
		global $conf;
		global $idSiteSelectedTransfert;
		global $_modules;

		if ($this->isAuth() != 1) {
			$sMsg .= _s("Vous devez vous identifier pour acc�der � cette page.") . "<br /><br /><a href=\"$urlNonAuth\">" . _s("Cliquez ici pour vous identifier") . "</a>";
			echo "<br><br><p>";
			affichemessage($sMsg, "width:450px;");
			echo "<TABLE HEIGHT=75% WIDTH=100%><TR valign=middle><TD align=center><a href=\"$urlNonAuth\"><IMG BORDER=0 SRC='" . $conf["baseURL"] . "images/seringue2.gif'></a></TD></TR></TABLE></a>";
			exit();
		}
		else {
			if (($niveauLimite == "administrateur") || ($niveauLimite == "admin")) {
				$sMsg .= _s("Vous devez vous identifier pour acc�der � cette page.") . "<br /><br /><a href=\"$urlNonAuth\">" . _s("Cliquez ici pour vous identifier") . "</a>";
				echo "<br><br><p>";
				affichemessage($sMsg, "width:450px;");
				echo "<TABLE HEIGHT=75% WIDTH=100%><TR valign=middle><TD align=center><a href=\"$urlNonAuth\"><IMG BORDER=0 SRC='" . $conf["baseURL"] . "images/seringue2.gif'></a></TD></TR></TABLE></a>";
				exit();
			}
		}
	}

	public function loadAccesSession()
	{
		if (0 < $this->refAnalyse) {
			$_SESSION["refAnalyse"] = 1;
		}
		else {
			$_SESSION["refAnalyse"] = 0;
		}

		if (($this->kaliresPrescription == 1) && (getsroption("kaliResPCAccesGlobal") == 1)) {
			$_SESSION["accesPC"] = 1;
		}
		else {
			$_SESSION["accesPC"] = 0;
		}

		if ($_SESSION["accesPermalink"]) {
			$_SESSION["accesPermalinkLevel"] = $this->permalinkLevel;
		}
	}
}


?>
