<?php

class sysInfo
{
	public function vhostname()
	{
		if (!$result = getenv("SERVER_NAME")) {
			$result = "N.A.";
		}

		return $result;
	}

	public function chostname()
	{
		if ($fp = fopen("/proc/sys/kernel/hostname", "r")) {
			$result = trim(fgets($fp, 4096));
			fclose($fp);
			$result = gethostbyaddr(gethostbyname($result));
		}
		else {
			$result = "N.A.";
		}

		return $result;
	}

	public function ip_addr()
	{
		if (!$result = getenv("SERVER_ADDR")) {
			$result = gethostbyname($this->chostname());
		}

		return $result;
	}

	public function kernel()
	{
		if ($fd = fopen("/proc/version", "r")) {
			$buf = fgets($fd, 4096);
			fclose($fd);

			if (preg_match("/version (.*?) /", $buf, $ar_buf)) {
				$result = $ar_buf[1];

				if (preg_match("/SMP/", $buf)) {
					$result .= " (SMP)";
				}
			}
			else {
				$result = "N.A.";
			}
		}
		else {
			$result = "N.A.";
		}

		return $result;
	}

	public function uptime()
	{
		global $text;
		$fd = fopen("/proc/uptime", "r");
		$ar_buf = explode(" ", fgets($fd, 4096));
		fclose($fd);
		$sys_ticks = trim($ar_buf[0]);
		return $sys_ticks;
	}

	public function users()
	{
		$who = explode("=", executeprogram("who", "-q"));
		$result = $who[1];
		return $result;
	}

	public function loadavg()
	{
		if ($fd = fopen("/proc/loadavg", "r")) {
			$results = explode(" ", fgets($fd, 4096));
			fclose($fd);
		}
		else {
			$results = array("N.A.", "N.A.", "N.A.");
		}

		return $results;
	}

	public function cpu_info()
	{
		$results = array();
		$ar_buf = array();

		if ($fd = fopen("/proc/cpuinfo", "r")) {
			while ($buf = fgets($fd, 4096)) {
				list($key, $value) = preg_split("/\s+:\s+/", trim($buf), 2);

				switch ($key) {
				case "model name":
					$results["model"] = $value;
					break;

				case "cpu MHz":
					$results["mhz"] = sprintf("%.2f", $value);
					break;

				case "cycle frequency [Hz]":
					$results["mhz"] = sprintf("%.2f", $value / 1000000);
					break;

				case "clock":
					$results["mhz"] = sprintf("%.2f", $value);
					break;

				case "cpu":
					$results["model"] = $value;
					break;

				case "L2 cache":
					$results["cache"] = $value;
					break;

				case "revision":
					$results["model"] .= " ( rev: " . $value . ")";
					break;

				case "cpu model":
					$results["model"] .= " (" . $value . ")";
					break;

				case "cache size":
					$results["cache"] = $value;
					break;

				case "bogomips":
					$results["bogomips"] += $value;
					break;

				case "BogoMIPS":
					$results["bogomips"] += $value;
					break;

				case "BogoMips":
					$results["bogomips"] += $value;
					break;

				case "cpus detected":
					$results["cpus"] += $value;
					break;

				case "system type":
					$results["model"] .= ", " . $value . " ";
					break;

				case "platform string":
					$results["model"] .= " (" . $value . ")";
					break;

				case "processor":
					$results["cpus"] += 1;
					break;

				case "Cpu0ClkTck":
					$results["mhz"] = sprintf("%.2f", hexdec($value) / 1000000);
					break;

				case "Cpu0Bogo":
					$results["bogomips"] = $value;
					break;

				case "ncpus probed":
					$results["cpus"] = $value;
					break;
				}
			}

			fclose($fd);
		}

		$keys = array_keys($results);
		$keys2be = array("model", "mhz", "cache", "bogomips", "cpus");

		while ($ar_buf = each($keys2be)) {
			if (!in_array($ar_buf[1], $keys)) {
				$results[$ar_buf[1]] = "N.A.";
			}
		}

		return $results;
	}

	public function memory()
	{
		if ($fd = fopen("/proc/meminfo", "r")) {
			$results["ram"] = array();
			$results["swap"] = array();
			$results["devswap"] = array();

			while ($buf = fgets($fd, 4096)) {
				if (preg_match("/^MemTotal:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["ram"]["total"] = $ar_buf[1];
				}
				else if (preg_match("/^MemFree:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["ram"]["free"] = $ar_buf[1];
				}
				else if (preg_match("/^Cached:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["ram"]["cached"] = $ar_buf[1];
				}
				else if (preg_match("/^Buffers:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["ram"]["buffers"] = $ar_buf[1];
				}
				else if (preg_match("/^SwapTotal:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["swap"]["total"] = $ar_buf[1];
				}
				else if (preg_match("/^SwapFree:\s+(.*)\s*kB/i", $buf, $ar_buf)) {
					$results["swap"]["free"] = $ar_buf[1];
				}
			}

			$results["ram"]["shared"] = 0;
			$results["ram"]["used"] = $results["ram"]["total"] - $results["ram"]["free"];
			$results["swap"]["used"] = $results["swap"]["total"] - $results["swap"]["free"];
			fclose($fd);
			$swaps = file("/proc/swaps");
			$swapdevs = explode("\n", $swaps);

			for ($i = 1; $i < (sizeof($swapdevs) - 1); $i++) {
				$ar_buf = preg_split("/\s+/", $swapdevs[$i], 6);
				$results["devswap"][$i - 1] = array();
				$results["devswap"][$i - 1]["dev"] = $ar_buf[0];
				$results["devswap"][$i - 1]["total"] = $ar_buf[2];
				$results["devswap"][$i - 1]["used"] = $ar_buf[3];
				$results["devswap"][$i - 1]["free"] = $results["devswap"][$i - 1]["total"] - $results["devswap"][$i - 1]["used"];
				$results["devswap"][$i - 1]["percent"] = round(($ar_buf[3] * 100) / $ar_buf[2]);
			}

			$results["ram"]["t_used"] = $results["ram"]["used"];
			$results["ram"]["t_free"] = $results["ram"]["total"] - $results["ram"]["t_used"];
			$results["ram"]["percent"] = round(($results["ram"]["t_used"] * 100) / $results["ram"]["total"]);
			$results["swap"]["percent"] = round(($results["swap"]["used"] * 100) / $results["swap"]["total"]);
		}
		else {
			$results["ram"] = array();
			$results["swap"] = array();
			$results["devswap"] = array();
		}

		return $results;
	}

	public function filesystems()
	{
		$df = executeprogram("df", "-kP");
		$mounts = explode("\n", $df);
		$fstype = array();

		if ($fd = fopen("/proc/mounts", "r")) {
			while ($buf = fgets($fd, 4096)) {
				list($dev, $mpoint, $type) = preg_split("/\s+/", trim($buf), 4);
				$fstype[$mpoint] = $type;
				$fsdev[$dev] = $type;
			}

			fclose($fd);
		}

		$i = 1;

		for ($max = sizeof($mounts); $i < $max; $i++) {
			$ar_buf = preg_split("/\s+/", $mounts[$i], 6);
			$results[$i - 1] = array();
			$results[$i - 1]["disk"] = $ar_buf[0];
			$results[$i - 1]["size"] = $ar_buf[1];
			$results[$i - 1]["used"] = $ar_buf[2];
			$results[$i - 1]["free"] = $ar_buf[3];
			$results[$i - 1]["percent"] = round(($results[$i - 1]["used"] * 100) / $results[$i - 1]["size"]) . "%";
			$results[$i - 1]["mount"] = $ar_buf[5];
			$fstype[$ar_buf[5]] ? $results[$i - 1]["fstype"] = $fstype[$ar_buf[5]] : $results[$i - 1]["fstype"] = $fsdev[$ar_buf[0]];
		}

		return $results;
	}

	public function distro()
	{
		if ($fd = fopen("/etc/debian_version", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = "Debian " . trim($buf);
		}
		else if ($fd = fopen("/etc/SuSE-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/mandrake-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/fedora-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/redhat-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/gentoo-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/slackware-version", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/eos-version", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/trustix-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else if ($fd = fopen("/etc/arch-release", "r")) {
			$buf = fgets($fd, 1024);
			fclose($fd);
			$result = trim($buf);
		}
		else {
			$result = "N.A.";
		}

		return $result;
	}

	public function userapache()
	{
		$user = "apache";
		if (preg_match("/^[Dd]ebian/", sysInfo::distro()) || preg_match("/^[Uu]buntu/", sysInfo::distro())) {
			$user = "www-data";
		}

		return $user;
	}

	public function backup($dir)
	{
		$opt = "-l --full-time --sort=time " . $dir;
		$res = executeprogram("ls", $opt);
		$ligne = explode("\n", $res);

		for ($i = 1; $i < sizeof($ligne); $i++) {
			preg_match_all("/(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)/", $ligne[$i], $tmp, PREG_SET_ORDER);
			preg_match_all("/(.*)\.(.*)/", $tmp[0][7], $tmp2, PREG_SET_ORDER);
			$nom = $tmp[0][9];
			$results[$nom]["date"] = $tmp[0][6] . " " . $tmp2[0][1];
			$results[$nom]["size"] = $tmp[0][5];
			$path = $dir . "/" . $nom;
			$res = executeprogram("md5sum", $path);
			preg_match_all("/(.*)\s+(.*)/", $res, $tmp, PREG_SET_ORDER);
			$results[$nom]["md5"] = $tmp[0][1];
		}

		return $results;
	}

	public function installedPackage($pName)
	{
		$version = exec("dpkg -l | grep -E \"^ii[ ]*" . $pName . "[ ]+\" | awk '{print \$3}'");

		if (empty($version)) {
			return false;
		}
		else {
			return $version;
		}
	}

	public function checkSoftDebian()
	{
		global $_modules;
		$return = array();
		$lesSoft = array("apache2", "libapache2-mod-php5", "php5", "php5-mysql", "php5-xsl", "php5-imap", "php-soap", "php-pear", "mysql-server", "mysql-client", "dovecot-common", "dovecot-imapd", "postfix", "fetchmail", "cups", "cups-bsd", "mytop", "htop", "bash", "ntp", "samba", "smbclient", "cvs", "zip", "unzip", "html2text", "xpdf", "antiword", "php-fpdf", "pdftk", "libtiff4", "vsftpd", "openvpn", "vtun");
		$lesSoftKalisil = array("ghostscript", "ted", "imagemagick", "libjpeg-progs", "php5-curl");

		if ($_modules->activated("Sil")) {
			$lesSoft = array_merge($lesSoft, $lesSoftKalisil);
		}

		sort($lesSoft);
		exec("dpkg -l | grep -E \"^ii *(" . implode(" |", $lesSoft) . ")\" |awk '{print \$2\"|\"\$3}'", $versions, $ret);
		$tab = array();

		foreach ($versions as $s ) {
			list($soft, $version) = explode("|", $s);
			$tab[$soft] = $version;
		}

		foreach ($lesSoft as $s ) {
			if (isset($tab[$s])) {
				$return[$s] = $tab[$s];
			}
			else {
				$return[$s] = false;
			}
		}

		return $return;
	}

	public function checkSoftIsInstalled($pkg)
	{
		if (preg_match("/^[A-Za-z0-9-]+$/", $pkg)) {
			if (preg_match("/^Debian/", $this->distro())) {
				return 0 < exec("dpkg -l | grep -E \"^ii *" . $pkg . "\" |wc -l");
			}
		}
		else {
			return false;
		}
	}

	public function listLsBackup()
	{
		$files = array();
		$backupDir = "/home/kalilab/backup/";

		if (file_exists($backupDir)) {
			$dir = @opendir($backupDir);

			if ($dir) {
				while ($file = readdir($dir)) {
					if (preg_match("/^LS_(.*)/", $file, $matches)) {
						$files[$matches[1]] = $backupDir . "/" . $file;
					}
				}

				return $files;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}

	public function parseLsBackup($pFile)
	{
		$return = array();

		if (file_exists($pFile)) {
			$fd = fopen($pFile, "r");

			while ($ligne = fgetcsv($fd, 10000, ";")) {
				if (!empty($ligne[0])) {
					$return[] = array($ligne[0], $ligne[1], affichetailleoctet($ligne[2]));
				}
			}

			fclose($fd);
		}

		return $return;
	}

	public function getLsBackupName($pName)
	{
		if ($pName == "LOCAL") {
			return _s("Sauvegarde locale");
		}
		else if (preg_match("/^SSH_(.*)/", $pName, $matches)) {
			return sprintf(_s("Sauvegarde distante s�curis�e sur %s"), $matches[1]);
		}
		else if (preg_match("/^SMB_(.*)/", $pName, $matches)) {
			return sprintf(_s("Sauvegarde distante sur partage sur %s"), $matches[1]);
		}
		else if (preg_match("/^FTP_(.*)/", $pName, $matches)) {
			return sprintf(_s("Sauvegarde distante FTP sur %s"), $matches[1]);
		}
	}

	public function getServerTime()
	{
		return date("d-m-Y H:i:s") . " GMT" . date("O");
	}

	public function listSambaShares()
	{
		exec("testparm -s", $out, $ret);

		if ($ret != 0) {
			echo "Erreur, le fichier de configuration samba n'est pas accessible.";
			return false;
		}
		else {
			$return = "";

			foreach ($out as $l ) {
				$return .= $l . PHP_EOL;
			}

			return "$return";
		}
	}

	public function getKaliVersion()
	{
		global $cBdUniq;
		$db = $cBdUniq->query("select version,build,nbPatch from kalilabUpdate where status=\"update ok\" ORDER BY date DESC LIMIT 1;");
		if ($db && $db->next()) {
			return array("version" => $db->get("version"), "build" => $db->get("build"), "nbPatch" => $db->get("nbPatch"));
		}

		return false;
	}

	public function getZendType()
	{
		$ZENDGUARD = "Zend Guard Loader";
		$ZENDOPTIMIZER = "Zend Optimizer";

		if (extension_loaded($ZENDGUARD)) {
			return "Guard";
		}

		if (extension_loaded($ZENDOPTIMIZER)) {
			return "Optimizer";
		}

		return "None";
	}
}

function getBackupInfo($amovible)
{
	$sysInfo = new sysInfo();
	$tmp = $sysInfo->backup("/home/kalilab/backup/archives");
	$results["hddbackup"] = $tmp;

	if ($amovible) {
		$tmp = $sysInfo->backup("/mnt/cdrom");
		$results["cdbackup"] = $tmp;
	}

	return $results;
}

function createBackupCache($integrite)
{
	$sysInfo = getbackupinfo($integrite);

	if ($integrite) {
		$integrity = verificationbackup($sysInfo["hddbackup"], $sysInfo["cdbackup"]);
		$text = "<TR class=titre><TD colspan=5>" . _s("Sauvegarde disque dur") . "</TD></TR>\n";
		$text .= htmlbackup($sysInfo["hddbackup"], 0, 0);
		$text .= "<TR class=titre><TD colspan=5>" . _s("Sauvegarde amovible") . "</TD></TR>\n";
		$text .= htmlbackup($sysInfo["cdbackup"], $integrity, 1);
	}
	else {
		$text = "<TR class=titre><TD colspan=5>" . _s("Sauvegarde disque dur") . "</TD></TR>\n";
		$text .= htmlbackup($sysInfo["hddbackup"], 0, 0);
	}

	$fp = fopen("/var/www/kalilab/cache/sysInfoBackup.cache", "w");
	fwrite($fp, $text);
	fclose($fp);
}

function createBackupFtpCache($dir)
{
	if ($fd = fopen("/root/.netrc", "r")) {
		while ($buf = fgets($fd, 4096)) {
			list($key, $value) = preg_split("/\s+/", trim($buf));

			switch ($key) {
			case "machine":
				$host[] = $value;
				break;

			case "login":
				$login[] = $value;
				break;

			case "password":
				$pass[] = $value;
				break;

			default:
				break;
			}
		}
	}

	$dirs = explode(" ", trim($dir));
	$text = "";

	foreach ($host as $key => $value ) {
		$connId = ftp_connect($value);
		$login_result = ftp_login($connId, $login[$key], $pass[$key]);
		$text .= "<TR class=titre><TD colspan=5>" . _s("Sauvegarde FTP sur ") . "<I>" . $value . "</I></TD></TR>\n";
		if ($connId && $login_result) {
			$text .= "<TR><TD><B>" . _s("Nom") . "</B></TD><TD><B>" . _s("Date") . "</B></TD><TD><B>" . _s("Taille") . "</B></TD><TD><B>" . _s("Etat") . "</B></TD></TR>\n";

			if ($dirs[$key] == "./") {
				$dirs[$key] = "";
			}

			$contents = ftp_nlist($connId, $dirs[$key] . "backCu*");
			sort($contents);

			foreach ($contents as $key2 => $value ) {
				$taille = ftp_size($connId, $value);
				$text .= "<TR><TD>" . $value . "</TD>";
				$text .= "<TD>" . affichedate(date(DATE_FORMAT . " H:i:s", ftp_mdtm($connId, $value))) . "</TD>";
				$text .= "<TD>" . affichetailleoctet($taille) . "</TD>";
				$text .= "<TD>" . verificationbackupftp($value, $taille) . "</TD></TR>";
			}

			$contents = ftp_nlist($connId, $dirs[$key] . "backI*");
			arsort($contents);

			foreach ($contents as $key2 => $value ) {
				$taille = ftp_size($connId, $value);
				$text .= "<TR><TD>" . $value . "</TD>";
				$text .= "<TD>" . affichedate(date(DATE_FORMAT . " H:i:s", ftp_mdtm($connId, $value))) . "</TD>";
				$text .= "<TD>" . affichetailleoctet($taille) . "</TD>";
				$text .= "<TD>" . verificationbackupftp($value, $taille) . "</TD></TR>";
			}

			ftp_close($connId);
		}
		else {
			$text .= "<TR><TD colspan=5><B>" . _s("Impossible de se connecter � l'h�te distant") . "</B></TD></TR>";
		}
	}

	$fp = fopen("/var/www/kalilab/cache/sysInfoBackupFtp.cache", "w");
	fwrite($fp, $text);
	fclose($fp);
}

function createBackupSftpCache()
{
	$text = "<TR class=titre><TD colspan=5>" . _s("Sauvegarde SFTP") . "<I>" . $value . "</I></TD></TR>\n";
	$text .= "<TR><TD><B>" . _s("Nom") . "</B></TD><TD><B>" . _s("Date") . "</B></TD><TD><B>" . _s("Taille") . "</B></TD><TD><B>" . _s("Etat") . "</B></TD></TR>\n";

	if (file_exists("/home/kalilab/sftpRecap")) {
		$fp = fopen("/home/kalilab/sftpRecap", "r");

		while ($buf = fgets($fp, 4096)) {
			preg_match_all("/(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+/", $buf, $tmp, PREG_SET_ORDER);

			if (strpos($tmp[0][5], "ackCu")) {
				$current[$tmp[0][5]] = $tmp[0];
			}

			if (strpos($tmp[0][5], "ackIn")) {
				$a = strpos($tmp[0][5], "r") + 1;
				$b = strpos($tmp[0][5], "-");
				$n = substr($tmp[0][5], $a, $b - $a);
				$incr[$n] = $tmp[0];
			}
		}

		ksort($current);
		krsort($incr);
		$text = affichagebackupftp($current);
		$text .= affichagebackupsftp($incr);
	}
	else {
		$text .= "<TR><TD colspan=5><B>" . _s("Fichier de r�capitulation inaccessible.") . "</B></TD></TR>";
	}

	$fp = fopen("/var/www/kalilab/cache/sysInfoBackupSftp.cache", "w");
	fwrite($fp, $text);
	fclose($fp);
}

function affichageBackupSftp($data)
{
	$text = "";

	foreach ($data as $key => $value ) {
		$text .= "<TR><TD>" . $value[5] . "</TD>\n";
		$text .= "<TD>" . $value[2] . " " . $value[3] . " " . $value[4] . "</TD>\n";
		$taille = substr($value[1], strrpos(trim($value[1]), " "));
		$text .= "<TD>" . affichetailleoctet($taille) . "</TD>\n";
		$text .= "<TD>" . verificationbackupftp($value[5], $taille) . "</TD></TR>";
	}

	return $text;
}

function verificationBackup($backup1, $backup2)
{
	while (list($name, $value) = each($backup1)) {
		if ($backup2[$name]) {
			if ($backup1[$name]["md5"] != $backup2[$name]["md5"]) {
				$results[] = $name;
			}
		}
		else {
			$results[] = $name;
		}
	}

	return $results;
}

function verificationBackupFtp($file, $distSize)
{
	if (strpos($file, "Current")) {
		return _s("Transf�r� p�riodiquement");
	}

	if (strpos($file, ".part")) {
		return "<FONT color=red>" . _s("D�faillant") . "</FONT>";
	}

	$local = "backIncr" . substr($file, strpos($file, "-") + 1);
	$localLs = executeprogram("ls", "-l /home/kalilab/backup/archives/" . $local);
	preg_match_all("/(.*)\s+(.*)\s+(.*)\s+(.*)\s+(.*)\s+/", $localLs, $tmp, PREG_SET_ORDER);

	if (!$tmp[0][2]) {
		return "<FONT color=green>" . _s("D�pass�e") . "</FONT>";
	}

	if ($tmp[0][2] != $distSize) {
		return "<FONT color=red>" . _s("D�faillant") . "</FONT>";
	}

	return _s("OK");
}

function htmlBackup($backup_type, $verif, $media)
{
	$text = "<TR><TD width=35%><b>Nom</b></TD>\n";
	$text .= "<TD width=25%><b>Date</b></TD>\n";
	$text .= "<TD width=15%><b>Taille</b></TD>\n";
	$text .= "<TD width=25%><b>Etat</b></TD></TR>\n";

	while (list($name, $value) = each($backup_type)) {
		if (($media == 0) && ($name != "backCurrent.tgz")) {
			$text .= "<TR><TD><A HREF=\"#\" onClick=\"makeRemote('descIncr', 'sysInfoBackupDetail.php?fichier=" . $name . "', 500, 400); return false;\">" . $name . "</A></TD>\n";
		}
		else {
			$text .= "<TR><TD>" . $name . "</TR></TD>\n";
		}

		$text .= "<TD>" . affichedatetime($value["date"]) . "</TD>\n";
		$text .= "<TD>" . affichetailleoctet($value["size"]) . "</TD>\n";
		$text .= "<TD>";
		if ($verif && in_array($name, $verif)) {
			$text .= "<FONT color=red>" . _s("D�faillant") . "</FONT>";
		}
		else {
			$text .= "OK";
		}

		$text .= "</TD></TR>\n";
	}

	return $text;
}

function createBargraph($percent)
{
	preg_match_all("/(\d+)(.*)/", $percent, $tmp, PREG_SET_ORDER);

	if ($tmp[0][1] < 90) {
		$_text = "<table><tr><td bgcolor=\"#66FF00\"><font size=\"-1\">";
	}
	else {
		$_text = "<table><tr><td bgcolor=\"red\"><font size=\"-1\">";
	}

	for ($i = 0; $i < ($tmp[0][1] / 2); $i++) {
		$_text .= "&nbsp;";
	}

	$_text .= "</td><td><font size=\"-1\">$percent</font></td></tr></font></table>";
	return $_text;
}

function findProgram($program)
{
	$path = array("/bin", "/sbin", "/usr/bin", "/usr/sbin", "/usr/local/bin", "/usr/local/sbin");

	if (function_exists("is_executable")) {
		while ($this_path = current($path)) {
			if (is_executable("$this_path/$program")) {
				return "$this_path/$program";
			}

			next($path);
		}
	}
	else {
		return strpos($program, ".exe");
	}

	return NULL;
}

function executeProgram($program, $args = "")
{
	$buffer = "";
	$program = findprogram($program);

	if (!$program) {
		return NULL;
	}

	if ($args) {
		$args_list = explode(" ", $args);

		for ($i = 0; $i < count($args_list); $i++) {
			if ($args_list[$i] == "|") {
				$cmd = $args_list[$i + 1];
				$new_cmd = findprogram($cmd);
				$args = str_replace("| $cmd", "| $new_cmd", $args);
			}
		}
	}

	if ($fp = popen("$program $args", "r")) {
		while (!feof($fp)) {
			$buffer .= fgets($fp, 4096);
		}

		return trim($buffer);
	}
}

function convertSecondesDHM($sec)
{
	global $text;
	$min = $sec / 60;
	$hours = $min / 60;
	$days = floor($hours / 24);
	$hours = floor($hours - ($days * 24));
	$min = floor($min - ($days * 60 * 24) - ($hours * 60));

	if ($days != 0) {
		$result = "" . _n("%s jour ", "%s jours ", $days);
	}

	if (false) {
		_s("%s jours ");
	}

	if ($hours != 0) {
		$result .= "" . _n("%s heure ", "%s heures ", $hours);
	}

	if (false) {
		_s("%s heures ");
	}

	$result .= "" . _n("%s minute ", "%s minutes ", $min);

	if (false) {
		_s("%s minutes ");
	}

	return $result;
}

function checkRequireTTY()
{
	if (preg_match("/^[Ff]edora/", sysInfo::distro())) {
		if (0 < exec("cat /etc/sudoers | grep \"requiretty\" | grep -Ev \"^#\" | wc -l")) {
			klog("Attention : l'instruction 'requiretty' dans le sudoers d�tect�e, il faut la supprimer avec visudo");
		}
	}
}

error_reporting(5);

?>
