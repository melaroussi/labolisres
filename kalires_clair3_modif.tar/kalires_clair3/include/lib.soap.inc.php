<?php

class SoapClientBase
{
	protected function init()
	{
		if (!empty($this->location)) {
			$context = stream_context_create(array(
	"ssl" => array("SNI_enabled" => false, "verify_peer" => false, "verify_peer_name" => false)
	));
			$this->client = new SoapClient(NULL, array("location" => $this->location, "uri" => "urn:xmethods-delayed-quotes", "encoding" => "UTF-8", "trace" => 1, "allow_self_signed" => 1, "stream_context" => $context));

			if (!$this->client) {
				exit("Impossible de se connecter au serveur SOAP");
			}
		}
	}

	protected function decodeObject($o)
	{
		if (is_array($o)) {
			$o2 = array();

			foreach ($o as $field => $value ) {
				$o2[utf8_decode($field)] = $this->decodeObject($value);
			}

			$o = $o2;
		}
		else if (is_object($o)) {
			foreach (get_object_vars($o) as $field => $value ) {
				$o->$field = $this->decodeObject($value);
			}
		}
		else if (is_string($o)) {
			$o = utf8_decode($o);
		}

		return $o;
	}

	protected function SoapEncodeObject($_object, $_func = "utf8_encode")
	{
		if (is_string($_object)) {
			return $_func($_object);
		}
		else if (is_object($_object)) {
			foreach (get_object_vars($_object) as $attribute => $value ) {
				$_object->$attribute = self::SoapEncodeObject($value);
			}
		}
		else if (is_array($_object)) {
			$_object2 = array();

			foreach ($_object as $field => $value ) {
				$_object2[$_func($field)] = self::SoapEncodeObject($value);
			}

			$_object = $_object2;
		}

		return $_object;
	}

	protected function handleError(SoapFault $e)
	{
		global $conf;
		global $patientLogged;
		@file_put_contents("/var/log/kalires/soap.log", "\n[" . date("Y-m-d H:i:s") . "] SOAP ERROR (CODE : " . $e->faultcode . ") : " . $e->getMessage(), FILE_APPEND);
		@file_put_contents("/var/log/kalires/soap.log", "\n[" . date("Y-m-d H:i:s") . "] TRACE DIST :\n" . $this->client->__getLastResponse() . "\n", FILE_APPEND);

		if ($e->faultcode == "DemandeCheckError") {
			$patientLogged->logout();
			klredir($conf["baseURL"] . "index.php", 5, _s("Une erreur est survenue. Veuillez vous reconnecter."));
			exit();
		}
	}
}

class SoapClientKalires extends SoapClientBase
{
	public function __construct()
	{
		global $conf;
		$this->location = $conf["serveurSoap"] . "kalires.php";
		$this->init();
	}

	public function getSrOptions()
	{
		try {
			$data = $this->client->getInfoLab();
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $this->decodeObject($data);
	}

	public function getSiteOptions()
	{
		try {
			$data = $this->client->getSiteOptions();
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $data;
	}

	public function getKey()
	{
		try {
			$key = $this->client->getKey();
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $key;
	}

	public function authKaliDom($codePreleveur, $token)
	{
		try {
			$data = $this->client->authKaliDom($codePreleveur, $token);
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $this->decodeObject($data);
	}

	public function initKaliDom($codePreleveur, $token)
	{
		try {
			$data = $this->client->initKaliDom($codePreleveur, $token);
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $this->decodeObject($data);
	}

	public function getSrOptionsUtilisateur($idUser, $type)
	{
		try {
			$data = $this->client->getSrOptionsUtilisateurs($idUser, $type);
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $this->decodeObject($data);
	}

	public function setSrOptionsUtilisateur($options, $idUser, $typeUtilisateur)
	{
		try {
			$data = $this->client->setSrOptionsUtilisateur($options, $idUser, $typeUtilisateur);
		}
		catch (SoapFault $ex) {
			self::handleError($ex);
			return false;
		}

		return $this->decodeObject($data);
	}

	public function loginPatient($pLogin, $pPassword, $numDossier = "")
	{
		if (empty($pLogin) || empty($pPassword)) {
			return false;
		}

		try {
			$pPassword = encodepassword("patient", $pPassword);
			$oPatient = $this->client->loginPatient($pLogin, $pPassword, $numDossier);
			return $this->decodeObject($oPatient);
		}
		catch (Exception $ex) {
			self::handleError($ex);
			return false;
		}
	}

	public function loginDemandeur($pLogin, $pPassword, $numDossier = "", $sha = false, $kalidom = false)
	{
		try {
			if (!$sha) {
				$pPassword = encodepassword("demandeur", $pPassword);
			}

			$oDemandeur = $this->client->loginDemandeur($pLogin, $pPassword, $numDossier, $sha, $kalidom);
			return $this->decodeObject($oDemandeur);
		}
		catch (Exception $ex) {
			self::handleError($ex);
			return false;
		}
	}

	public function changePassword($pNiveau, $pLogin, $pPasswordOld, $pPassword, $token = "")
	{
		try {
			$pPasswordOld = encodepassword($pNiveau, $pPasswordOld);
			$pPassword = encodepassword($pNiveau, $pPassword);
			$token = encodeusertoken($token, $pNiveau, $pLogin, $pPassword);
			$oDemandeur = $this->client->changePassword($pNiveau, $pLogin, $pPasswordOld, $pPassword, $token);
			return $this->decodeObject($oDemandeur);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function regenPassword($pNiveau, $pLogin, $pMail)
	{
		try {
			$oDemandeur = $this->client->regenPassword($pNiveau, $pLogin, $pMail);
			return $this->decodeObject($oDemandeur);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function valideCGU($pId, $pNiveau)
	{
		try {
			$oDemandeur = $this->client->valideCGU($pId, $pNiveau);
			return $this->decodeObject($oDemandeur);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function getKaliresLogo()
	{
		global $conf;

		try {
			$dataJpg = base64_decode($this->client->getLogo());
			file_put_contents($conf["dataDir"] . "/logo/logo-kalires-TN.jpg", $dataJpg);
			return true;
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function trace($type, $reference, $idType, $idReference, $traceUser = "")
	{
		$this->client->srTrace($type, $reference, $idType, $idReference, $traceUser);
	}

	public function getPassword($type, $login, $email)
	{
	}

	public function getKaliresReferentiel($type)
	{
		global $conf;

		try {
			$listeReferentiel = $this->decodeObject($this->client->getReferentiel($type));
			return $listeReferentiel;
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function majKaliresReferentiel($type, $arrayRef = array())
	{
		global $conf;
		global $patientLogged;

		try {
			list($listeFichierRef, $arrayFichierClean) = $this->client->majReferentiel($type, $arrayRef);
			if (is_array($listeFichierRef) && (0 < count($listeFichierRef))) {
				foreach ($listeFichierRef as $key => $value ) {
					$dataRef = base64_decode($value["file"]);
					file_put_contents($conf["dataDir"] . "referentiel/" . $patientLogged->niveau . "/" . $value["nomFile"] . ".pdf", $dataRef);
				}
			}

			foreach ($arrayRef as $key => $value ) {
				$fileNameTest = $value . "_" . $key . ".pdf";

				if (!in_array($fileNameTest, $arrayFichierClean)) {
					if (file_exists($conf["dataDir"] . "referentiel/" . $patientLogged->niveau . "/" . $fileNameTest)) {
						unlink($conf["dataDir"] . "referentiel/" . $patientLogged->niveau . "/" . $fileNameTest);
					}
				}
			}
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function encaisseDemande($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$data = $this->client->encaisseDemande($params["token"]);
			return $this->decodeObject($data);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function reglementDemandeOffline($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$data = $this->client->reglementDemandeOffline($params["numDemande"], $params["dateNaissance"]);
			return $this->decodeObject($data);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}
}

class SoapClientDemande extends SoapClientBase
{
	public function __construct()
	{
		global $conf;
		$this->location = $conf["serveurSoap"] . "demande.php";
		$this->init();
	}

	public function getFichierCR($idDemande, $numDemande, $typeDest, $idDest, $crSelected = 0, $fichierDest = "")
	{
		try {
			$dataCR = base64_decode($this->client->getCR($idDemande, $numDemande, $typeDest, $idDest, $crSelected));
			return $dataCR;
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function getFichierQuittance($idDemande, $fichierDest = "")
	{
		try {
			$dataQuittance = base64_decode($this->client->getQuittance($idDemande));

			if (empty($fichierDest)) {
				$fichierDest = tempnam("/tmp", "qui") . ".pdf";
			}

			file_put_contents($fichierDest, $dataQuittance);
			return $fichierDest;
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function changeMessageStatus($params = array())
	{
		$params = self::SoapEncodeObject($params);
		$data = $this->client->changeMessageStatus($params["idDemandeur"], $params["typeDemandeur"], $params["afficher"]);
		return $this->decodeObject($data);
	}

	public function getListeDemandePatient($params = array())
	{
		$params = self::SoapEncodeObject($params);
		$data = $this->client->getListeDemandePatient($params["patientId"], $params["numDemande"]);
		return $this->decodeObject($data);
	}

	public function getListeDemandePreleveur($params = array())
	{
		$params = self::SoapEncodeObject($params);
		$data = $this->client->getListeDemandePreleveur($params["preleveurId"], $params["filtre"]);
		return $this->decodeObject($data);
	}

	public function getListeDemandeDemandeur($params = array())
	{
		$params["filtre"]["isFromPermalink"] = $_SESSION["accesPermalink"];
		$params = self::SoapEncodeObject($params);
		$retourSoap = $this->decodeObject($this->client->getListeDemandeDemandeur($params["idDemandeur"], $params["typeDemandeur"], $params["filtre"]));
		$listeDemandes = $retourSoap["data"];
		$listeChapitres = array();

		foreach ($listeDemandes as $lesDemandes ) {
			foreach ($lesDemandes["analyses"] as $lesAnalyses ) {
				$codeChapitre = $lesAnalyses["codeChapitre"];
				$idChapitre = $lesAnalyses["idChapitre"];

				if (!in_array($codeChapitre, $listeChapitres)) {
					$listeChapitres[$codeChapitre] = array("idChapitre" => $lesAnalyses["idChapitre"], "nomChapitre" => $lesAnalyses["nomChapitre"], "codeChapitre" => $lesAnalyses["codeChapitre"]);
				}
			}
		}

		ksort($listeChapitres);
		$listeMedecins = array();

		foreach ($listeDemandes as $lesDemandes ) {
			foreach ($lesDemandes["medecins"] as $medecin ) {
				$idMedecin = $medecin["idMedecin"];

				if (!in_array($idMedecin, $listeMedecins)) {
					$listeMedecins[$idMedecin] = $medecin;
				}
			}
		}

		$listeCorrespondants = array();

		foreach ($listeDemandes as $lesDemandes ) {
			foreach ($lesDemandes["correspondants"] as $correspondant ) {
				$idCorrespondant = $correspondant["idCorrespondant"];

				if (!in_array($idCorrespondant, $listeCorrespondants)) {
					$listeCorrespondants[$idCorrespondant] = $correspondant;
				}
			}
		}

		return array($listeDemandes, $listeMedecins, $listeCorrespondants, $listeChapitres, $retourSoap);
	}

	public function getDataPatient($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$data = $this->client->getInfoDemande($params["numDemande"], $params["idDemande"], $params["typeDestinataire"], $params["patientId"], $params["referer"]);
			return $this->decodeObject($data);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function getDataAnalyse($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$data = $this->client->getDataDemande($params["idDemande"], $params["numDemande"], $params["patientId"], $params["patientNiveau"], $params["chapitreId"]);
			return $this->decodeObject($data);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}

	public function getDataAnteriorite($params = array())
	{
		$params = self::SoapEncodeObject($params);
		$data = $this->client->getDataAnteriorite($params["typeDestinataire"], $params["numPermanent"], $params["patientId"], $params["patientNiveau"]);
		return $this->decodeObject($data);
	}

	public function getDataPartiel($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$dataCR = base64_decode($this->client->getDataPartiel($params["numDemande"], $params["idDemande"], $params["typeDestinataire"], $params["idDestinataire"]));
			return $dataCR;
		}
		catch (Exception $ex) {
			echo _s("Erreur") . " : " . $ex->getMessage();
			return false;
		}
	}

	public function accesDemande($params = array())
	{
		try {
			$params = self::SoapEncodeObject($params);
			$data = $this->client->accesDemande($params["token"], $params["patientId"], $params["patientNiveau"]);
			return $this->decodeObject($data);
		}
		catch (Exception $ex) {
			echo self::handleError($ex);
			return false;
		}
	}
}

class SoapClientPrescription extends SoapClientBase
{
	public function __construct()
	{
		global $conf;
		$this->location = $conf["serveurSoap"] . "prescription.php";
		$this->init();
	}

	public function envoiDemandePresc($params = array())
	{
		$params = self::SoapEncodeObject($params);
		return $this->client->receptionDemandePresc($params);
	}

	public function getDataPrescription($params = array())
	{
		$params = self::SoapEncodeObject($params);
		$data = $this->client->getDataPrescription($params["idReference"], $params["idType"]);
		return $this->decodeObject($data);
	}

	public function getPrescription($arg = array())
	{
		$params = self::SoapEncodeObject($arg);
		$data = $this->client->getPrescription($params);
		return $this->decodeObject($data);
	}

	public function getListePrescriptionConnectee($params)
	{
		$params = self::SoapEncodeObject($params);
		$retourSoap = $this->decodeObject($this->client->getListePrescriptionConnectee($params["idDemandeur"], $params["typeDemandeur"], $params["filtre"]));
		return $retourSoap;
	}

	public function getInfoPatientIpp($params)
	{
		$param = self::SoapEncodeObject($params);
		$data = $this->decodeObject($this->client->getInfoPatientIpp($params["idIntervenant"], $params["typeIntervenant"], $params["numIPP"]));
		return $data;
	}
}

ini_set("soap.wsdl_cache_enabled", "0");
ini_set("display_errors", "1");
ini_set("html_errors", "1");

?>
