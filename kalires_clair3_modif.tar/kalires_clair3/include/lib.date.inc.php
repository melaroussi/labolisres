<?php

if (!defined("INCLUDE_LIB_DATE")) {
	function isTodayDMY($jour = -1, $mois = -1, $annee = -1)
	{
		return date("M-d-Y") == date("M-d-Y", mktime(0, 0, 0, $mois, $jour, $annee));
	}
	function afficheDate($date)
	{
		if (preg_match("/([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})/", $date, $regs)) {
			return sprintf("%02d", $regs[3]) . "-" . sprintf("%02d", $regs[2]) . "-" . $regs[1];
		}
		else {
			return $date;
		}
	}
	function afficheDateCourt($date)
	{
		if (preg_match("/([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})/", $date, $regs)) {
			return $regs[3] . "-" . $regs[2] . "-" . substr($regs[1], 2, 2);
		}
		else {
			return $date;
		}
	}
	function saisieDate($date)
	{
		if (!preg_match("/([0-9]{1,2})-([0-9]{1,2})-([0-9]{2,4})/", $date, $regs)) {
			if (!preg_match("/([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{2,4})/", $date, $regs)) {
				if (!preg_match("/([0-9]{1,2}) ([0-9]{1,2}) ([0-9]{2,4})/", $date, $regs)) {
					return false;
				}
			}
		}

		$regs[2] = sprintf("%02d", $regs[2]);
		$regs[1] = sprintf("%02d", $regs[1]);
		$regs[3] = (strlen($regs[3]) == 2 ? "20" . $regs[3] : $regs[3]);
		return $regs[3] . "-" . $regs[2] . "-" . $regs[1];
	}
	function saisieDateTime($date)
	{
		$time = substr($date, -9);
		$date = substr($date, 0, 10);
		return saisiedate($date) . $time;
	}
	function afficheDateTime($dateTime)
	{
		if (strlen($dateTime) == strlen("20061212203410")) {
			$dateTime = substr($dateTime, 0, 4) . "-" . substr($dateTime, 4, 2) . "-" . substr($dateTime, 6, 2) . " " . substr($dateTime, 8, 2) . ":" . substr($dateTime, 10, 2) . ":" . substr($dateTime, 12, 2) . "";
		}

		$date = substr($dateTime, 0, 10);
		$time = substr($dateTime, -9);
		return affichedate($date) . $time;
	}
	function afficheTime($dateTime)
	{
		$date = substr($dateTime, 0, 10);
		$time = substr($dateTime, -9);
		return $time;
	}
	function numToJour($nbr, $options = "all")
	{
		if ($nbr == 1) {
			$res = _s("Lundi", $options);
		}

		if ($nbr == 2) {
			$res = _s("Mardi", $options);
		}

		if ($nbr == 3) {
			$res = _s("Mercredi", $options);
		}

		if ($nbr == 4) {
			$res = _s("Jeudi", $options);
		}

		if ($nbr == 5) {
			$res = _s("Vendredi", $options);
		}

		if ($nbr == 6) {
			$res = _s("Samedi", $options);
		}

		if ($nbr == 0) {
			$res = _s("Dimanche", $options);
		}

		return $res;
	}
	function numToJourAbrege($nbr, $options = "all")
	{
		if ($nbr == 1) {
			$res = _s("Lun", $options);
		}

		if ($nbr == 2) {
			$res = _s("Mar", $options);
		}

		if ($nbr == 3) {
			$res = _s("Mer", $options);
		}

		if ($nbr == 4) {
			$res = _s("Jeu", $options);
		}

		if ($nbr == 5) {
			$res = _s("Ven", $options);
		}

		if ($nbr == 6) {
			$res = _s("Sam", $options);
		}

		if ($nbr == 0) {
			$res = _s("Dim", $options);
		}

		return $res;
	}
	function numToMoisSsClass($nbr, $options = "all")
	{
		if ($nbr == 1) {
			$res = _s("Janvier", $options);
		}

		if ($nbr == 2) {
			$res = _s("F�vrier", $options);
		}

		if ($nbr == 3) {
			$res = _s("Mars", $options);
		}

		if ($nbr == 4) {
			$res = _s("Avril", $options);
		}

		if ($nbr == 5) {
			$res = _s("Mai", $options);
		}

		if ($nbr == 6) {
			$res = _s("Juin", $options);
		}

		if ($nbr == 7) {
			$res = _s("Juillet", $options);
		}

		if ($nbr == 8) {
			$res = _s("Ao�t", $options);
		}

		if ($nbr == 9) {
			$res = _s("Septembre", $options);
		}

		if ($nbr == 10) {
			$res = _s("Octobre", $options);
		}

		if ($nbr == 11) {
			$res = _s("Novembre", $options);
		}

		if ($nbr == 12) {
			$res = _s("D�cembre", $options);
		}

		return $res;
	}
	function numToMoisAbrege($nbr, $options = "all")
	{
		if ($nbr == 1) {
			$res = _s("Jan", $options);
		}

		if ($nbr == 2) {
			$res = _s("Fev", $options);
		}

		if ($nbr == 3) {
			$res = _s("Mars", $options);
		}

		if ($nbr == 4) {
			$res = _s("Avr", $options);
		}

		if ($nbr == 5) {
			$res = _s("Mai", $options);
		}

		if ($nbr == 6) {
			$res = _s("Juin", $options);
		}

		if ($nbr == 7) {
			$res = _s("Juil", $options);
		}

		if ($nbr == 8) {
			$res = _s("Ao�t", $options);
		}

		if ($nbr == 9) {
			$res = _s("Sept", $options);
		}

		if ($nbr == 10) {
			$res = _s("Oct", $options);
		}

		if ($nbr == 11) {
			$res = _s("Nov", $options);
		}

		if ($nbr == 12) {
			$res = _s("D�c", $options);
		}

		return $res;
	}
	function numToMois($nbr, $options = "all")
	{
		return numtomoisssclass($nbr, $options);
	}
	function listeJour($nom, $selected = "")
	{
		echo "<SELECT  name=\"$nom\">\n";

		if ($selected == "") {
			$selected = date("d");
		}

		for ($i = 1; $i < 32; $i++) {
			$i = sprintf("%02d", $i);

			if ($i == $selected) {
				$BONUS = "selected";
			}
			else {
				$BONUS = "";
			}

			echo "<OPTION $BONUS value=$i>" . $i . "</OPTION>\n";
		}

		echo "</SELECT>\n";
	}
	function menuJour($nom, $selected = "")
	{
		echo "<SELECT  name=\"$nom\">\n";

		if ($selected == "") {
			$selected = 0;
		}

		for ($i = 0; $i < 7; $i++) {
			if ($i == $selected) {
				$BONUS = "selected";
			}
			else {
				$BONUS = "";
			}

			echo "<OPTION $BONUS value=$i>" . numtojour($i) . "</OPTION>\n";
		}

		echo "</SELECT>\n";
	}
	function listeMois($nom, $selected = "")
	{
		echo "<SELECT  name=\"$nom\">\n";

		if ($selected == "") {
			$selected = date("m");
		}

		for ($i = 1; $i < 13; $i++) {
			$i = sprintf("%02d", $i);

			if ($i == $selected) {
				$BONUS = "selected";
			}
			else {
				$BONUS = "";
			}

			echo "<OPTION $BONUS value=$i>" . numtomois($i) . "</OPTION>\n";
		}

		echo "</SELECT>\n";
	}
	function listeAnnee($nom, $selected = "")
	{
		echo "<SELECT  name=\"$nom\">\n";

		if ($selected == "") {
			$selected = date("Y");
		}

		for ($i = 2000; $i < 2010; $i++) {
			$i = sprintf("%04d", $i);

			if ($i == $selected) {
				$BONUS = "selected";
			}
			else {
				$BONUS = "";
			}

			echo "<OPTION $BONUS value=$i>" . $i . "</OPTION>\n";
		}

		echo "</SELECT>\n";
	}
	function listeAnneeF($nom, $selected = "")
	{
		echo "<SELECT  name=\"$nom\">\n";

		if ($selected == "") {
			$selected = date("Y");
		}

		for ($i = date("Y"); $i < 2010; $i++) {
			$i = sprintf("%04d", $i);

			if ($i == $selected) {
				$BONUS = "selected";
			}
			else {
				$BONUS = "";
			}

			echo "<OPTION $BONUS value=$i>" . $i . "</OPTION>\n";
		}

		echo "</SELECT>\n";
	}
	function jourSemaine($j, $m, $y)
	{
		$tt = date("w", mktime(0, 0, 0, $m, $j, $y));
		return $tt;
	}
	function dernierJour($j, $m, $y)
	{
		$tt = date("t", mktime(0, 0, 0, $m, $j, $y));
		return $tt;
	}
	function numSemaineOnce($date)
	{
		$res = explode("-", $date);
		return numsemaine($res[0], $res[1], $res[2]);
	}
	function numSemaineOnceTrace($date)
	{
		$res = explode("-", $date);
		return _s("Semaine") . " " . numsemaine($res[0], $res[1], $res[2]);
	}
	function premierJourSemaineFromDate($date)
	{
		list($d, $m, $y) = explode("-", $date);
		$dateUnix = mktime(0, 0, 0, $m, $d, $y);

		if (0 < $dateUnix) {
			while (($i < 8) && (date("w", $dateUnix) != 1)) {
				$i++;
				$dateUnix -= 24 * 60 * 60;
			}

			return date("d-m-Y", $dateUnix);
		}
		else {
			return false;
		}
	}
	function premierDernierJourSemaine($semaine, $annee)
	{
		$i = 1;

		while (numsemaine($i, 1, $annee) != 1) {
			$i++;
		}

		$dateUnixPremierJour = mktime(0, 0, 0, 1, $i, $annee);
		$numPremierJour = date("w", $dateUnixPremierJour);
		$dateUnixPremierLundi = $dateUnixPremierJour - ((($numPremierJour + 6) % 7) * 24 * 60 * 60);
		$dateUnixLundiSemaine = $dateUnixPremierLundi + (7 * 24 * 60 * 60 * ($semaine - 1));
		$dateUnixDimancheSemaine = $dateUnixLundiSemaine + (6 * 24 * 60 * 60);

		if (numsemaineonce(date("d-m-Y", $dateUnixLundiSemaine)) != $semaine) {
			return false;
		}
		else {
			return array(date("d-m-Y", $dateUnixLundiSemaine), date("d-m-Y", $dateUnixDimancheSemaine));
		}
	}
	function numSemaine($d, $m, $y)
	{
		$week = strftime("%W", mktime(0, 0, 0, $m, $d, $y));
		$dow0101 = getdate(mktime(0, 0, 0, 1, 1, $y));
		$dow3112 = getdate(mktime(0, 0, 0, 12, 31, $y));
		if ((1 < $dow0101["wday"]) && ($dow0101["wday"] < 5)) {
			$week++;
		}
		else if ($week == 0) {
			$week = 53;
		}

		if (($week == 53) && (0 < $dow3112["wday"]) && ($dow3112["wday"] < 4)) {
			$week = 1;
		}

		return substr("00" . $week, -2);
	}
	function dateExpire($jour, $mois, $annee)
	{
		if (checkdate($mois, $jour, $annee)) {
			$atester = mktime(0, 0, 0, $mois, $jour, $annee);
			$limite = mktime(0, 0, 0, date("m"), date("d"), date("Y") - 3);

			if ($limite <= $atester) {
				return false;
			}
			else {
				return true;
			}
		}
		else {
			return 0;
		}
	}
	class Date
	{
		/**                                  
  *   
  *                               
  * @var unknown $now 
  * @access private                             
  */
		public $now;
		/**                                  
  *   
  *                               
  * @var unknown $jour 
  * @access private                             
  */
		public $jour;
		/**                                  
  *   
  *                               
  * @var unknown $moisString 
  * @access private                             
  */
		public $moisString;
		/**                                  
  *   
  *                               
  * @var unknown $mois 
  * @access private                             
  */
		public $mois;
		/**                                  
  *   
  *                               
  * @var unknown $annee 
  * @access private                             
  */
		public $annee;

		public function __construct($mois = 0, $annee = 0)
		{
			$nowDate = getdate(time());
			if (($mois == 0) || ($annee == 0) || ($mois == "") || ($annee == "")) {
				$mois = $nowDate["mon"];
				$annee = $nowDate["year"];
			}

			if (($mois == $nowDate["mon"]) && ($annee == $nowDate["year"])) {
				$jour = $nowDate["mday"];
			}
			else {
				$jour = 1;
			}

			$now = mktime(0, 0, 0, $mois, $jour, $annee);
			$this->now = $now;
			$this->jour = $jour;
			$this->moisString = array(_s("Janvier"), _s("F�vrier"), _s("Mars"), _s("Avril"), _s("Mai"), _s("Juin"), _s("Juillet"), _s("Ao�t"), _s("Septembre"), _s("Octobre"), _s("Novembre"), _s("D�cembre"));
			$this->annee = $annee;
			$this->mois = $this->format($mois);
		}

		public function format($sStr)
		{
			if ($sStr < 10) {
				$sStr = "0" . $sStr;
			}

			return $sStr;
		}

		public function present()
		{
			$date = getdate($this->now);
			$resu["mois"] = $this->format($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $date["mday"];
			return $resu;
		}

		public function suivant()
		{
			if ($this->mois < 9) {
				$resu["mois"] = ("0" . $this->mois) + 1;
				$resu["annee"] = $this->annee;
			}
			else if ($this->mois < 12) {
				$resu["mois"] = $this->mois + 1;
				$resu["annee"] = $this->annee;
			}
			else {
				$resu["mois"] = 1;
				$resu["annee"] = $this->annee + 1;
			}

			return $resu;
		}

		public function precedent()
		{
			$date = $this->now - ($this->jour * 24 * 3600) - (24 * 3600);
			$date = getdate($date);
			$resu["mois"] = $this->format($date["mon"]);
			$resu["annee"] = $date["year"];
			return $resu;
		}

		public function numToMois($num)
		{
			return $this->moisString[$num - 1];
		}

		public function dayMax()
		{
			return date("t", mktime(0, 0, 0, $this->mois, 1, $this->annee));
		}

		public function mois($moisSeek)
		{
			$date = getdate(mktime(0, 0, 0, $this->mois + $moisSeek, $this->jour, $this->annee));
			$resu["mois"] = $this->format($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			return $resu;
		}

		public function annee($anneeSeek)
		{
			$date = getdate(mktime(0, 0, 0, $this->mois, $this->jour, $this->annee + $anneeSeek));
			$resu["mois"] = $this->format($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			return $resu;
		}
	}

	class DateJour
	{
		/**                                  
  *   
  *                               
  * @var unknown $now 
  * @access private                             
  */
		public $now;
		/**                                  
  *   
  *                               
  * @var unknown $jour 
  * @access private                             
  */
		public $jour;
		/**                                  
  *   
  *                               
  * @var unknown $mois 
  * @access private                             
  */
		public $mois;
		/**                                  
  *   
  *                               
  * @var unknown $annee 
  * @access private                             
  */
		public $annee;
		/**                                  
  *   
  *                               
  * @var unknown $present 
  * @access private                             
  */
		public $present;

		public function __construct($jour = "", $mois = "", $annee = "")
		{
			$nowDate = getdate(time());
			if (($jour == "") || ($mois == "") || ($annee == "")) {
				$jour = $nowDate["mday"];
				$mois = $nowDate["mon"];
				$annee = $nowDate["year"];
			}

			$now = mktime(0, 0, 0, $mois, $jour, $annee);
			$this->now = $now;
			$this->annee = $annee;
			$this->mois = $this->format($mois);
			$this->jour = $jour;
			$this->present = $this->present();
		}

		public function isGreaterOrEqualThan($dateJour)
		{
			if (($dateJour->annee < $this->annee) || (($this->annee == $dateJour->annee) && ($dateJour->mois < $this->mois)) || (($this->annee == $dateJour->annee) && ($this->mois == $dateJour->mois) && ($dateJour->jour <= $this->jour))) {
				return true;
			}
			else {
				return false;
			}
		}

		public function isLowerOrEqualThan($dateJour)
		{
			if (($this->annee < $dateJour->annee) || (($this->annee == $dateJour->annee) && ($this->mois < $dateJour->mois)) || (($this->annee == $dateJour->annee) && ($this->mois == $dateJour->mois) && ($this->jour <= $dateJour->jour))) {
				return true;
			}
			else {
				return false;
			}
		}

		public function jourSeek($jour)
		{
			$now = mktime(0, 0, 0, $this->mois, $this->jour + $jour, $this->annee);
			$nowDate = getdate($now);
			$jour = $nowDate["mday"];
			$mois = $nowDate["mon"];
			$annee = $nowDate["year"];
			$this->now = $now;
			$this->annee = $annee;
			$this->mois = $this->format($mois);
			$this->jour = $jour;
			$this->present = $this->present();
		}

		public function moisSeek($mois)
		{
			$now = mktime(0, 0, 0, $this->mois + $mois, $this->jour, $this->annee);
			$nowDate = getdate($now);
			$jour = $nowDate["mday"];
			$mois = $nowDate["mon"];
			$annee = $nowDate["year"];
			$this->now = $now;
			$this->annee = $annee;
			$this->mois = $this->format($mois);
			$this->jour = $jour;
			$this->present = $this->present();
		}

		public function numSemaine()
		{
			return numsemaine($this->jour, $this->mois, $this->annee);
		}

		public function format($sStr)
		{
			if ($sStr < 10) {
				$sStr = "0" . $sStr;
			}

			return $sStr;
		}

		public function present($type = "classic")
		{
			$date = getdate($this->now);
			$resu["mois"] = $this->format($date["mon"]);
			$resu["moisStr"] = numtomois($date["mon"]);
			$resu["moisStrAbrege"] = numtomoisabrege($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			$resu["jourStrAbrege"] = numtojourabrege($date["wday"]);
			$resu["jourDeLaSemaine"] = $date["wday"];
			$resu["jourStr"] = numtojour($date["wday"]);
			$resu["date"] = $resu["jour"] . "-" . $resu["mois"] . "-" . $resu["annee"];

			if ($type == "full") {
				$aujourdhui = getdate(time());
				$resu["estAujourdhui"] = ($date["yday"] == $aujourdhui["yday"]) && ($date["year"] == $aujourdhui["year"]);
				$resu["estFerie"] = dateestferie($resu["date"]);
				$resu["estOuvert"] = datejourestouvert($resu["jourDeLaSemaine"]);
			}

			return $resu;
		}

		public function jour($jourSeek, $type = "classic")
		{
			$date = getdate(mktime(0, 0, 0, $this->mois, $this->jour + $jourSeek, $this->annee));
			$resu["mois"] = $this->format($date["mon"]);
			$resu["moisStr"] = numtomois($date["mon"]);
			$resu["moisStrAbrege"] = numtomoisabrege($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			$resu["jourStrAbrege"] = numtojourabrege($date["wday"]);
			$resu["jourDeLaSemaine"] = $date["wday"];
			$resu["jourStr"] = numtojour($date["wday"]);
			$resu["date"] = $resu["jour"] . "-" . $resu["mois"] . "-" . $resu["annee"];

			if ($type == "full") {
				$aujourdhui = getdate(time());
				$resu["estAujourdhui"] = ($date["yday"] == $aujourdhui["yday"]) && ($date["year"] == $aujourdhui["year"]);
				$resu["estFerie"] = dateestferie($resu["date"]);
				$resu["estOuvert"] = datejourestouvert($resu["jourDeLaSemaine"]);
			}

			return $resu;
		}

		public function mois($moisSeek)
		{
			$date = getdate(mktime(0, 0, 0, $this->mois + $moisSeek, $this->jour, $this->annee));
			$resu["mois"] = $this->format($date["mon"]);
			$resu["moisStr"] = numtomois($date["mon"]);
			$resu["moisStrAbrege"] = numtomoisabrege($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			$resu["jourStrAbrege"] = numtojourabrege($date["wday"]);
			$resu["jourStr"] = numtojour($date["wday"]);
			$resu["date"] = $resu["jour"] . "-" . $resu["mois"] . "-" . $resu["annee"];
			return $resu;
		}

		public function annee($anneeSeek)
		{
			$date = getdate(mktime(0, 0, 0, $this->mois, $this->jour, $this->annee + $anneeSeek));
			$resu["mois"] = $this->format($date["mon"]);
			$resu["moisStr"] = numtomois($date["mon"]);
			$resu["moisStrAbrege"] = numtomoisabrege($date["mon"]);
			$resu["annee"] = $date["year"];
			$resu["jour"] = $this->format($date["mday"]);
			$resu["jourStrAbrege"] = numtojourabrege($date["wday"]);
			$resu["jourStr"] = numtojour($date["wday"]);
			$resu["date"] = $resu["jour"] . "-" . $resu["mois"] . "-" . $resu["annee"];
			return $resu;
		}

		public function dayMax()
		{
			return date("t", mktime(0, 0, 0, $this->mois, 1, $this->annee));
		}
	}

	function dateAnterieure($date1, $date2)
	{
		$jour1 = substr($date1, 8, 2);
		$mois1 = substr($date1, 5, 2);
		$anne1 = substr($date1, 0, 4);
		$jour2 = substr($date2, 8, 2);
		$mois2 = substr($date2, 5, 2);
		$anne2 = substr($date2, 0, 4);

		if ($anne1 < $anne2) {
			return 1;
		}
		else if ($anne1 == $anne2) {
			if ($mois1 < $mois2) {
				return 1;
			}
			else if ($mois1 == $mois2) {
				if ($jour1 <= $jour2) {
					return 1;
				}
				else {
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	function differenceHoraire($heure1, $heure2)
	{
		$h1["m"] = substr($heure1, 2, 2);
		$h1["h"] = substr($heure1, 0, 2);
		$h2["m"] = substr($heure2, 2, 2);
		$h2["h"] = substr($heure2, 0, 2);
		$diff = ($h2["h"] - $h1["h"]) * 60;
		$diff += $h2["m"] - $h1["m"];
		return $diff;
	}
	function differenceDate($date1, $date2)
	{
		list($y1, $m1, $d1) = explode("-", $date1);
		list($y2, $m2, $d2) = explode("-", $date2);
		$mktime1 = mktime(0, 0, 0, $m1, $d1, $y1);
		$mktime2 = mktime(0, 0, 0, $m2, $d2, $y2);
		$nbrJour = ($mktime2 - $mktime1) / 60 / 60 / 24;
		return $nbrJour;
	}
	function formInputHeure($nom, $selected = "", $type = "")
	{
		if ($selected != "") {
			$h = substr($selected, 0, 2);
			$m = substr($selected, 2, 2);
		}

		if ($type == "horaire") {
			$filtreH = ",Array(Array('lt',24),Array('ge',0))";
			$filtreM = ",Array(Array('lt',60),Array('ge',0))";
		}

		return "<nobr style=\"border:2px inset #FFFFFF;background-color:white\"><input name=\"" . $nom . "[HM]\" type=hidden value=\"" . $selected . "\"><input name=\"" . $nom . "[H]\" type=text value=\"" . $h . "\" size=\"2\" dataType=\"int\" maxlength=\"2\" onFocus=\"this.select()\" onKeyDown=\"myHTrackKeyDown(this);\" onKeyUp=\"myHTrackKeyUp(this,'" . $nom . "','" . $type . "');\"  onBlur=\"text_validate(this" . $filtreH . ");\"  STYLE=\"text-align:center;border:0px;\">H<input name=\"" . $nom . "[M]\" type=text value=\"" . $m . "\" dataType=\"int\" size=\"2\" onFocus=\"this.select()\"  onBlur=\"text_validate(this" . $filtreM . ");myHTrackRefresh(this,'" . $nom . "');\" maxlength=\"2\" STYLE=\"text-align:center;border:0px;\"></nobr>";
	}
	function afficheHeure($heure)
	{
		if ($heure != "") {
			return sprintf("%02d", substr($heure, 0, count($heure) - 3)) . ":" . sprintf("%02d", substr($heure, -2));
		}
		else {
			return "";
		}
	}
	function afficheMinuteEnHeure($minute)
	{
		if ($minute < 0) {
			$moins = true;
		}
		else {
			$moins = false;
		}

		$minute = abs($minute);
		$h = floor($minute / 60);
		$m = $minute % 60;
		return ($moins ? "-" : "") . afficheheure(sprintf("%02d%02d", $h, $m));
	}
	function afficheHeureEnMinute($heure)
	{
		$nbH = substr($heure, 0, 2);

		if (strpos($heure, ":") !== false) {
			$nbM = substr($heure, 3, 2);
		}
		else {
			$nbM = substr($heure, 2, 2);
		}

		return $nbM + ($nbH * 60);
	}
	function dateDiff($dateDe, $dateA)
	{
		list($jour, $mois, $an) = explode("-", $dateDe);
		list($jour2, $mois2, $an2) = explode("-", $dateA);
		$timestamp = mktime(1, 1, 1, (int) $mois, (int) $jour, (int) $an);
		$timestamp2 = mktime(1, 1, 1, (int) $mois2, (int) $jour2, (int) $an2);
		$diff = floor(($timestamp - $timestamp2) / (3600 * 24));
		return $diff;
	}
	define("INCLUDE_LIB_DATE", 1);
}

?>
