<?php

global $patientLogged;
global $conf;
if (isset($patientLogged) && $patientLogged->isAuth()) {
	$dataInter = array("nom" => $patientLogged->nom, "prenom" => isset($patientLogged->prenom) ? $patientLogged->prenom : "");
	$changePasswAutorise = false;

	if ($patientLogged->niveau == "patient") {
		$typeInter = "Patient";

		if (0 < getsroption("passwordPerso")) {
			$changePasswAutorise = true;
		}
	}
	else if ($patientLogged->niveau == "medecin") {
		$typeInter = "M�decin";
		$changePasswAutorise = true;
	}
	else if ($patientLogged->niveau == "correspondant") {
		$typeInter = "Correspondant";
		$changePasswAutorise = true;
	}
	else if ($patientLogged->niveau == "preleveur") {
		$typeInter = "Pr�leveur";
		$changePasswAutorise = true;
	}

	if ($dataInter !== false) {
		$strInter = "<img border=0 src=\"images/lock.gif\"> <b>" . $dataInter["prenom"] . " " . $dataInter["nom"] . ($patientLogged->traceUser != "" ? " (" . _secho($patientLogged->traceUser) . ")" : "") . "</b>";

		if ($changePasswAutorise) {
			echo "<a href='" . $conf["baseURL"] . "changePassword.php' title='" . _s("Cliquez pour changer votre mot de passe") . "'>" . $strInter . "</a>";
		}
		else {
			echo $strInter;
		}
	}

	if (!$_SESSION["accesPermalink"] || ($_SESSION["accesPermalinkLevel"] == 1)) {
		echo " <a href='" . $conf["baseURL"] . "consultation.php'><img border=0 src=\"images/liste.gif\"> " . _s("Liste des demandes") . "</a></li>";
	}

	echo "<a href='" . $conf["baseURL"] . "index.php?logout=1'><img border=0 src=\"images/logout.gif\"> " . _s("D�connexion") . "</a></li>";
}
else {
	echo "<a href='" . $conf["baseURL"] . "index.php'>Page d'identification</a></li>";
}

?>
