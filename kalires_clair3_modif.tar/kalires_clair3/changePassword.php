<?php

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");

// Add responsive styles
$responsiveCSS = <<<EOT
<style>
/* Responsive styles */
@media screen and (max-width: 768px) {
    table {
        width: 100% !important;
        max-width: 100% !important;
        font-size: 14px;
    }
    
    td, th {
        padding: 12px !important;
    }
    
    .corps {
        font-size: 14px;
    }
    
    .titre {
        font-size: 16px;
    }
    
    input[type="password"] {
        width: 100% !important;
        max-width: 100% !important;
        padding: 8px;
        font-size: 14px;
    }
    
    input[type="checkbox"] {
        transform: scale(1.2);
        margin-right: 8px;
    }
    
    label {
        font-size: 14px;
    }
    
    input[type="submit"] {
        width: 100% !important;
        max-width: 300px !important;
        padding: 12px;
        font-size: 16px;
        margin: 10px auto;
    }
    
    .message {
        font-size: 14px;
        padding: 10px;
        margin: 10px 0;
    }
    
    .error {
        color: #ff0000;
        font-size: 14px;
        padding: 10px;
        margin: 10px 0;
    }
}

/* Base styles */
table {
    border-collapse: collapse;
    margin: 20px auto;
    background-color: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.corps {
    color: #333;
}

.titre {
    background-color: #f5f5f5;
    font-weight: bold;
    padding: 15px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

input[type="password"] {
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    width: 250px;
}

input[type="checkbox"] {
    margin-right: 8px;
}

label {
    cursor: pointer;
    user-select: none;
}

input[type="submit"] {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    transition: background-color 0.3s;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

.message {
    text-align: center;
    padding: 15px;
    margin: 20px auto;
    max-width: 500px;
    border-radius: 4px;
    background-color: #f8f9fa;
}

.error {
    color: #ff0000;
    text-align: center;
    padding: 15px;
    margin: 20px auto;
    max-width: 500px;
    border-radius: 4px;
    background-color: #fff3f3;
}

form {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
}
</style>
EOT;

// Function to override standard affichehead function with responsive meta tag
function customAffichehead($titre, $script, $javascript = false) {
    global $conf;
    global $responsiveCSS;
    
    // Start HTML
    echo "<html><head><title>" . $titre . "</title>";
    
    // Add responsive viewport meta tag
    echo "\n\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">";
    
    // Add favicon
    echo "\n\t<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"" . $conf["baseURL"] . "favico.kalires.ico\" />";
    echo "\n\t<link rel=\"icon\" type=\"image/gif\" href=\"" . $conf["baseURL"] . "images/kalires.gif\" />";
    
    // Add stylesheets
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/kalires2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/calendar-system.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "style2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/qtip.css\">";
    
    // Add scripts
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/validator.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.plugin.qtip.js\" ></script>";
    
    // Add responsive styles
    echo $responsiveCSS;
    
    echo "\n</head><body topmargin=0 leftmargin=0 >";
}

$typeDestinataire = $patientLogged->niveau;
customAffichehead(_s("Options du compte") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
entete();

if ($choix == "changePassword") {
	if (($_SESSION["keyForm"] != "") && ($keyFormForm == $_SESSION["keyForm"])) {
		if (($sPasswordOld != "") && ($sPassword1 != "") && ($sPassword2 != "")) {
			if (5 <= strlen($sPassword1)) {
				if ($sPassword1 == $sPassword2) {
					$sc = new SoapClientKalires();
					$changePassw = $sc->changePassword($sNiveau, $sLogin, $sPasswordOld, $sPassword1);

					if ($changePassw->result == "1") {
						$sMsg = "" . _s("Le nouveau mot de passe a bien �t� enregistr�") . "";
					}
					else if ($changePassw->result == "2") {
						$sMsg = "<font color=red>" . _s("Erreur : le nouveau mot de passe doit �tre diff�rent de l'ancien") . "</font>";
					}
					else {
						$sMsg = "<font color=red>" . _s("Erreur : le changement de mot de passe a �chou�") . "</font>";
					}
				}
				else {
					$sMsg = "<font color=red>" . _s("Erreur : les 2 mots de passe ne sont pas identiques") . "</font>";
				}
			}
			else {
				$sMsg = "<font color=red>" . _s("Erreur : le mot de passe doit faire au minimum 5 caract�res") . "</font>";
			}
		}
		else {
			if (($sPassword1 != "") || ($sPassword2 != "")) {
				$sMsg = "<font color=red>" . _s("Erreur : veuillez remplir tous les champs requis pour le changement de mot de passe") . "</font>";
			}
		}

		$optSaved = false;

		if ($patientLogged->getOptionUtilisateur("kaliresMail") != $kaliResOpt["kaliresMail"]) {
			$patientLogged->setOptionUtilisateur(array("kaliresMail" => $kaliResOpt["kaliresMail"] ? $kaliResOpt["kaliresMail"] : "0"), $patientLogged->id, $patientLogged->niveau);
			$br = "";

			if ($sMsg != "") {
				$br = "</br>";
			}

			$sMsg .= $br . _s("Options personnelles enregistr�es") . "";
			$optSaved = true;
		}

		if ($patientLogged->userOption["clearFilter"] != $userOption["clearFilter"]) {
			$patientLogged->setOptionUtilisateur(array(
	"optionsUtilisateur" => array("clearFilter" => $userOption["clearFilter"] ? $userOption["clearFilter"] : "0")
	), $patientLogged->id, $patientLogged->niveau);
			$patientLogged->userOption["clearFilter"] = $userOption["clearFilter"];

			if (!$optSaved) {
				$br = "";

				if ($sMsg != "") {
					$br = "</br>";
				}

				$sMsg .= $br . _s("Options personnelles enregistr�es") . "";
				$optSaved = true;
			}
		}
	}
	else {
		$sMsg = "<font color=red>" . _s("Erreur : session incorrecte") . "</font>";
	}
}

unset($_SESSION["keyForm"]);
affichemessage($sMsg);
$keyForm = uniqid(date("YmdHis"));
$_SESSION["keyForm"] = $keyForm;
echo "<form name=principal action=\"changePassword.php\" method=post>";
echo "<input type=hidden name=choix value=\"changePassword\"><input type=\"hidden\" name=\"keyFormForm\" value=\"" . $keyForm . "\"><input type=\"hidden\" name=\"sLogin\" value=\"" . ($patientLogged->niveau == "patient" ? $patientLogged->numPermanent : $patientLogged->numIdentification) . "\"><input type=\"hidden\" name=\"sNiveau\" value=\"" . $patientLogged->niveau . "\">";
echo "\t<table class=\"corps\" align=center cellpadding=\"2\" cellspacing=\"3\" border=\"0\" style=\"border:1px solid #bbb;\" width=500>\n\t\t<tr class=titre><td align=center colspan=2>";
echo _s("Options personnelles :");
echo "</td></tr>\n\t\t<tr><td align=right>";
echo _s("Identifiant");
echo " : </td><td>";
echo $patientLogged->niveau == "patient" ? $patientLogged->numPermanent : $patientLogged->numIdentification;
echo "</td></tr>\n\t\t\n\t\t";
if (($patientLogged->niveau == "medecin") || ($patientLogged->niveau == "correspondant")) {
	echo "<tr>\n\t\t\t\t\t\t<td align=right>" . _s("Notification par mail pour chaque demande valid�e") . " : </td>\n\t\t\t\t\t\t<td><label><input TYPE=\"checkbox\" id=\"kaliResOpt[kaliresMail]\" NAME=\"kaliResOpt[kaliresMail]\" VALUE=\"1\" " . (0 < $patientLogged->getOptionUtilisateur("kaliresMail") ? "checked" : "") . " > " . _s("Oui") . "</label></td>\n\t\t\t\t\t</tr>";
}

if (($patientLogged->niveau == "medecin") || ($patientLogged->niveau == "correspondant") || ($patientLogged->niveau == "preleveur")) {
	echo "<tr>\n\t\t\t\t\t\t<td align=right>" . _s("Effacer les filtres de recherche � chaque connexion") . " : </td>\n\t\t\t\t\t\t<td><label><input TYPE=\"checkbox\" id=\"userOption[clearFilter]\" NAME=\"userOption[clearFilter]\" VALUE=\"1\" " . (0 < $patientLogged->userOption["clearFilter"] ? "checked" : "") . " > " . _s("Oui") . "</label></td>\n\t\t\t\t\t</tr>";
}

echo "\t\t\t\t\n\t\t<tr class=titre><td align=center colspan=2>";
echo _s("Changement de mot de passe :");
echo "</td></tr>\n\t\t<tr><td align=right>";
echo _s("Mot de passe actuel");
echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPasswordOld\" autocomplete=\"off\" ></td></tr>\n\t\t<tr><td align=right>";
echo _s("Nouveau mot de passe");
echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPassword1\" autocomplete=\"off\" ></td></tr>\n\t\t<tr><td align=right>";
echo _s("Nouveau mot de passe (v�rification)");
echo " : </td><td><input type=\"Password\" value=\"\" name=\"sPassword2\" autocomplete=\"off\" ></td></tr>\t\n\t</table>\n\t<br/>\n\t<center><input type=\"submit\" name=\"send\" value=\"";
echo _s("Enregistrer");
echo "\"></center>\n";
echo "</form>";
affichefoot();

?>
