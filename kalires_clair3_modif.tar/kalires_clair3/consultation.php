<?php

function getStrDate($data)
{
	if (($data["preleveHeure"] != "00:00:00") && ($data["preleveDate"] != "0000-00-00")) {
		$dateReference = $data["preleveDate"];
		$heureReference = substr($data["preleveHeure"], 0, -3);
		$strTooltip = sprintf(_s("Date de pr�l�vement : %s"), affichedate($dateReference) . " " . $heureReference);
	}
	else {
		$dateReference = $data["saisieDate"];
		$heureReference = substr($data["saisieHeure"], 0, -3);
		$strTooltip = sprintf(_s("Date de saisie : %s"), affichedate($dateReference) . " " . $heureReference);
	}

	if ($data["demandeDate"] != $dateReference) {
		return "<span " . tooltip_show(sprintf(_s("Date de demande : %s"), affichedate($data["demandeDate"])) . "<br/>" . $strTooltip) . ">" . affichedate($data["demandeDate"]) . "<br/>" . affichedate($dateReference) . " " . $heureReference . "</span>";
	}
	else {
		return affichedate($dateReference) . "<br/>" . $heureReference;
	}
}

// Add responsive styles
$responsiveCSS = <<<EOT
<style>
/* Responsive styles */
@media screen and (max-width: 768px) {
    table {
        width: 100% !important;
        font-size: 14px;
    }
    
    td, th {
        padding: 8px !important;
    }
    
    .corpsFonce {
        white-space: normal !important;
    }
    
    .descr {
        font-size: 12px;
    }
    
    .analyse {
        font-size: 9px;
    }
    
    .analysenew, .analysevalide {
        font-size: 12px;
    }
    
    input[type="text"], 
    input[type="password"],
    select {
        width: 100%;
        box-sizing: border-box;
        padding: 8px;
        font-size: 14px;
    }
    
    .titreBleu {
        font-size: 14px;
    }
    
    .corps {
        font-size: 14px;
    }
    
    .login-form {
        width: 100% !important;
        margin-bottom: 20px;
    }
    
    #div_content {
        padding: 10px;
    }
    
    .hand {
        display: block;
        padding: 5px;
    }
    
    .img {
        display: inline-block;
    }
}

/* Base styles */
table {
    border-collapse: collapse;
    margin: 10px 0;
}

.corpsFonce {
    background-color: #f5f5f5;
}

.descr {
    color: #666;
}

.analyse {
    font-style: italic;
    color: #666;
}

.analysenew {
    font-weight: bold;
    text-decoration: underline;
}

.analysevalide {
    color: #005020;
}

.analysehorsborne {
    background-color: #F7BC8C;
    padding: 2px;
}

.hand {
    cursor: pointer;
}

.img {
    text-decoration: none;
}
</style>
EOT;

// Function to override standard affichehead function with responsive meta tag
function customAffichehead($titre, $script, $javascript = false) {
    global $conf;
    global $responsiveCSS;
    
    // Start HTML
    echo "<html><head><title>" . $titre . "</title>";
    
    // Add responsive viewport meta tag
    echo "\n\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\">";
    
    // Add favicon
    echo "\n\t<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"" . $conf["baseURL"] . "favico.kalires.ico\" />";
    echo "\n\t<link rel=\"icon\" type=\"image/gif\" href=\"" . $conf["baseURL"] . "images/kalires.gif\" />";
    
    // Add stylesheets
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/kalires2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/calendar-system.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "style2.css\">";
    echo "\n\t<link rel=\"stylesheet\" href=\"" . $conf["baseURL"] . "include/qtip.css\">";
    
    // Add scripts
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/lib.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/validator.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.js\" ></script>";
    echo "\n\t<SCRIPT LANGUAGE='Javascript' src=\"" . $conf["baseURL"] . "include/jquery.plugin.qtip.js\" ></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar.js\"></script>";
    echo "\n\t<script type=\"text/javascript\" src=\"" . $conf["baseURL"] . "include/calendar-fr.js\"></script>";
    
    // Add responsive styles
    echo $responsiveCSS;
    
    echo "\n</head><body topmargin=0 leftmargin=0 >";
}

include_once ("include/conf.inc.php");
include_once ("include/lib.inc.php");
session_start();
$patientLogged = $_SESSION["patientLogged"];

// Use custom responsive head function
customAffichehead(_s("Liste des demandes") . " - " . getsroption("laboNom"), "", true);
filtrageacces("patient", "index.php", "index.php");
tooltip_init();
entete();
$affichAnt = getsroption("affichAnt");
$afficheDossierPaye = getsroption("afficheDossierPaye");
$afficheDossierPayeMin = getsroption("afficheDossierPayeMin");
$optionJours = getsroption("validPass");
if (($patientLogged->niveau == "preleveur") || ($patientLogged->niveau == "medecin") || ($patientLogged->niveau == "correspondant")) {
	echo "\t<script type=\"text/javascript\">\n\t\tfunction clickRecherche() {\n\t\t\tgetById('div_content').style.display = \"none\";\n\t\t\tgetById('div_wait').style.display = \"block\";\n\t\t}\n\t\tfunction setSort(type) {\n\t\t\tgetById('filter_sort').value = type;\n\t\t\tclickRecherche();\n\t\t\tgetById('form_filter').submit();\n\t\t}\n\t</script>\n\t<style type=\"text/css\">\n\t\t.analyse { font-style: italic; color:#666666; font-size: 10px; }\n\t\t.analysenew { font-style: normal; font-weight: bold; text-decoration: underline; color:#000000; }\n\t\t.analysevalide { font-style: normal; color:#005020; }\n\t\t.analysehorsborne { background-color: #F7BC8C; padding:2px; }\n\t</style>\n\t";
}

if ($patientLogged->niveau == "patient") {
	if (($patientLogged->niveau == "patient") && !isset($sNumDoss) && (getsroption("affichAnt") == 0)) {
		if ($patientLogged->numDemande != "") {
			$sNumDoss = $patientLogged->numDemande;
		}
		else {
			affichemessage(_s("Erreur de s�lection : impossible de trouver la demande"));
			affichefoot();
			exit();
		}
	}

	$scd = new SoapClientDemande();
	$params = array("patientId" => $patientLogged->id(), "numDemande" => $sNumDoss);
	$retourSoap = $scd->getListeDemandePatient($params);
	$dataListe = $retourSoap["data"];
	affichemessagesil($retourSoap["message"]);
	echo "<H1>" . _s("Liste des demandes") . "</H1>";
	if (is_array($dataListe) && (count($dataListe) == 1)) {
		klredir("afficheDossier.php?sNumDossier=" . $dataListe[0]["numDemande"] . "&sIdDossier=" . $dataListe[0]["id"], 0, _s("Redirection en cours ..."));
		affichefoot();
		exit();
	}

	$uneDemandeRegler = false;
	$strTable = "<table align=center cellpadding=1 cellspacing=1 border=0 width=600 style=\"border:1px solid #ccc;\">";
	$strTable .= "<tr class=titreBleu><td colspan=2>" . _s("Num�ro de demande") . "</td><td>" . _s("Date de la demande") . "</td></tr>";

	if (is_array($dataListe)) {
		foreach ($dataListe as $key => $data ) {
			$idSite = (isset($data["idSite"]) ? $data["idSite"] : 0);
			if ((0 < $data["restePatient"]) && (0 < $afficheDossierPaye) && ($afficheDossierPayeMin < $data["restePatient"])) {
				$strPaiement = getstrpaiement($data["id"], $data["numDemande"], $data["restePatient"], $idSite, "reduit");
				$bonusLienImg = _s("Demande � r�gler") . " (" . $data["restePatient"] . " " . getmonnaie("html") . ") " . $strPaiement;
				$bonusLienDmd = $data["numDemande"];
				$uneDemandeRegler = true;
			}
			else {
				$bonusLienImg = "<a class=img href=\"afficheDossier.php?sNumDossier=" . $data["numDemande"] . "&sIdDossier=" . $data["id"] . "\"><img border=0 src=\"" . imagepath("icoloupe.gif") . "\"></a>";
				$bonusLienDmd = "<nobr><a href=\"afficheDossier.php?sNumDossier=" . $data["numDemande"] . "&sIdDossier=" . $data["id"] . "\">" . $data["numDemande"] . "</a></nobr>";
			}

			$strTable .= "";
			$strTable .= "<tr style=\"height:25px\" class=\"corpsFonce\"><td width=250 align=center>" . $bonusLienImg . "</td><td width=200 align=\"center\">" . $bonusLienDmd . "</td><td width=150 align=\"center\">" . affichedate($data["saisieDate"]) . "</td></tr>";
		}
	}
	else if ($affichAnt == 0) {
		$strTable .= "<TR><TD colspan=3>" . _s("Aucune demande trouv�e. Pensez � saisir le num�ro de demande lors de l'identification !") . "</TD></TR>";
	}

	$strTable .= "</table>";
	echo "<H2>" . _s("Cliquez sur votre num�ro de demande pour la consulter") . "</h2>";
	if ($uneDemandeRegler && (getsroption("urlPaiement") != "")) {
		echo "<div style=\"padding-left:20px;\">" . sprintf(_s("Pour r�gler le reste � payer sur votre demande, veuillez cliquer sur l'ic�ne %s Vous pourrez ensuite acc�der � vos r�sultats."), "<img src=\"images/facture.gif\" border=\"0\"><br />") . "</div><br />";
	}

	echo $strTable;
}
else if ($patientLogged->niveau == "preleveur") {
	if ($_POST["choix"] == "reset") {
		unset($filter);
		unset($_SESSION["filter"]);
	}

	if ($_POST["choix"] == "filtrer") {
		$_SESSION["filter"] = $filter = $_POST["filter"];
	}

	if ((isset($_GET["numId"]) && ($_GET["numId"] != "")) || (isset($_GET["numIPP"]) && ($_GET["numIPP"] != ""))) {
		$filter = array("nomPatient" => "", "prenomPatient" => "", "numDemande" => $_GET["numId"], "numIPP" => $_GET["numIPP"], "nomNaissancePatient" => "", "dateNaissance" => "", "dateDebut" => "", "dateFin" => "", "sort" => "", "orderIntervenant" => "");
	}

	if (!isset($filter)) {
		if (isset($_SESSION["filter"])) {
			$filter = $_SESSION["filter"];
		}
		else {
			$filter = array("nomPatient" => "", "prenomPatient" => "", "numDemande" => "", "nomNaissancePatient" => "", "dateNaissance" => "", "dateDebut" => date("d-m-Y", time() - 2592000), "dateFin" => date("d-m-Y"), "sort" => "", "orderIntervenant" => "");
		}
	}

	$scd = new SoapClientDemande();
	$params = array("preleveurId" => $patientLogged->id(), "filtre" => $filter);
	$retourSoap = $scd->getListeDemandePreleveur($params);
	$listeDemandes = $retourSoap["data"];
	if ((isset($_GET["numId"]) || isset($_GET["numIPP"])) && (count($listeDemandes) == 1)) {
		klredir("afficheDossier.php?sNumDossier=" . $listeDemandes[0]["numDemande"] . "&sIdDossier=" . $listeDemandes[0]["idDemande"], 0, _s("Redirection en cours ..."));
		affichefoot();
		exit();
	}
	else {
		if ($_SESSION["accesPermalink"] && ($_SESSION["accesPermalinkLevel"] == 0)) {
			$_SESSION["loginError"] = 6;

			if ($patientLogged->isAuth()) {
				$patientLogged->logout();
			}

			klredir("denied.php?type=" . $_SESSION["loginError"], 1, "<span style=\"color:red;\">" . _s("L'authentification a �chou�") . "</span>");
			affichefoot();
			exit();
		}
	}

	affichemessagesil($retourSoap["message"]);
	echo "<H1>" . _s("Liste des demandes") . "</H1>";
	if (is_array($listeDemandes) && (0 < count($listeDemandes))) {
		if ($filter["orderIntervenant"] == 1) {
			$newListeDemandes[$patientLogged->nom() . " " . $patientLogged->prenom] = array();

			foreach ($listeDemandes as $dem ) {
				$newListeDemandes[$dem["nomPreleveur"] . " " . $dem["prenomPreleveur"]][] = $dem;
			}
		}
		else {
			foreach ($listeDemandes as $dem ) {
				$newListeDemandes[0][] = $dem;
			}
		}
	}

	echo "<FORM id=\"form_filter\" NAME=\"principal\" METHOD=\"POST\" ACTION=\"consultation.php\">\n\t<input id=\"form_choix\" type=\"hidden\" name=\"choix\" value=\"filtrer\" />\n\t<input id=\"filter_sort\" type=\"hidden\" name=\"filter[sort]\" value=\"";
	echo $filter["sort"];
	echo "\" />\n\t<table align=\"center\" width=\"98%\">\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("Nom usuel");
	echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[nomPatient]\" value=\"";
	echo $filter["nomPatient"];
	echo "\" /></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("Pr�nom");
	echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[prenomPatient]\" value=\"";
	echo $filter["prenomPatient"];
	echo "\"></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("NDemande");
	echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[numDemande]\" value=\"";
	echo $filter["numDemande"];
	echo "\"></td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("Nom naissance");
	echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[nomNaissancePatient]\" value=\"";
	echo $filter["nomNaissancePatient"];
	echo "\" /></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("Date naissance");
	echo "</td>\n\t\t\t<td>";
	echo navgetinputdate(array("id" => "dateNaissance", "name" => "filter[dateNaissance]", "dataType" => "date", "value" => $filter["dateNaissance"]), true, false, true, false, true);
	echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\"><label for=\"orderIntervenant\">";
	echo _s("Grouper");
	echo "</label></td>\n\t\t\t<td><label><input type=\"checkbox\" name=\"filter[orderIntervenant]\" id=\"orderIntervenant\" value=\"1\"  ";
	echo $filter["orderIntervenant"] == 1 ? "CHECKED" : "";
	echo "> ";
	echo _s("par pr�leveur");
	echo "</label></td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
	echo _s("P�riode du");
	echo "</td>\n\t\t\t<td>";
	echo navgetinputdate(array("id" => "dateDebut", "name" => "filter[dateDebut]", "dataType" => "date", "value" => $filter["dateDebut"]), true, false, true, false, true);
	echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">&nbsp;";
	echo _s("au");
	echo "</td>\n\t\t\t<td>";
	echo navgetinputdate(array("id" => "dateFin", "name" => "filter[dateFin]", "dataType" => "date", "value" => $filter["dateFin"]), true, false, true, false, true);
	echo "</td>\n\t\t</tr>\n\t\t<tr>\n\t\t\t<td colspan=\"6\">\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
	echo _s("Rechercher");
	echo "' onclick=\"clickRecherche();\" />\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
	echo _s("Effacer le filtre");
	echo "' onclick=\"getById('form_choix').value='reset'; clickRecherche();\" />\n\t\t\t</td>\n\t\t</tr>\n\t</table>\n</FORM>\n\n";
	$nbDemandes = 0;

	if (is_array($newListeDemandes)) {
		$nbDemandes = filterdemandes($newListeDemandes, $filter);
	}

	echo "<div id=\"div_content\">\n\t";

	if (100 <= $nbDemandes) {
		echo "<div align='center'>" . _s("L'affichage est limit� � 100 demandes.") . "</div>";
	}

	echo "\n\t<div align=\"center\">\n\t\t";
	echo sprintf(_s("%s demande(s) trouv�e(s)"), $nbDemandes);
	echo "&nbsp;\n\t</div>\t\t\n\t\t\n\t<table align=center cellpadding=1 cellspacing=1 border=0 width=98% style=\"border:1px solid #ccc;\">\n\t\t<tr class=titreBleu>\n\t\t\t<td colspan=2 width=23%><div onClick=\"setSort('dossier');\" class=hand>";
	echo _s("Demande");
	echo "&nbsp;\n\t\t\t\t";

	if ($filter["sort"] == "dossier") {
		echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
	}
	else {
		echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
	}

	echo "\t\t\t\t</div>\n\t\t\t</td>\n\t\t\t<td width=25%><div onClick=\"setSort('patient');\" class=hand>";
	echo _s("Patient");
	echo "&nbsp;\n\t\t\t\t";

	if ($filter["sort"] == "patient") {
		echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
	}
	else {
		echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
	}

	echo "\t\t\t\t</div>\n\t\t\t</td>\n\t\t\t<td width=40%>";
	echo _s("Analyses");
	echo "</td>\n\t\t\t<td width=12%><div onClick=\"setSort('date');\" class=hand>";
	echo _s("Date");
	echo " \n\t\t\t\t";
	if (($filter["sort"] == "date") || empty($filter["sort"]) || ($filter["sort"] == "")) {
		echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
	}
	else {
		echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
	}

	echo "</div>\n\t\t\t</td>\n\t\t</tr>\n\t\t";
	$iD = 0;
	$_SESSION["listeDemandesSess"] = array();
	$_SESSION["listeDemandesNomSess"] = array();
	$_SESSION["listeDemandesIdSess"] = array();

	if (is_array($newListeDemandes)) {
		foreach ($newListeDemandes as $nomInt => $listeDemandes ) {
			if (($filter["orderIntervenant"] == 1) && !empty($listeDemandes)) {
				echo "<tr class=titre>\n\t\t\t\t\t\t<td colspan=5 align=center><b>" . _s("Pr�leveur") . " : " . _secho($nomInt, "hde") . "</b></td>\n\t\t\t\t\t</tr>";
			}

			foreach ($listeDemandes as $key => $data ) {
				echo "\t\t\t\t";
				$nomPatient = strtoupper($data["nomPatient"]) . " " . ucfirst(strtolower($data["prenomPatient"]));
				$_SESSION["listeDemandesSess"][$iD] = $data["numDemande"];
				$_SESSION["listeDemandesNomSess"][$iD] = $nomPatient;
				$_SESSION["listeDemandesIdSess"][$iD] = $data["idDemande"];
				$iD++;
				echo "\t\t\t\t<tr style=\"height:25px\" class=\"";
				echo $data["dateVisu"] != "" ? "corps" : "corpsFonce";
				echo "\">\n\t\t\t\t\t";

				if (0 < $data["urgent"]) {
					$styleColor = "color:red";
				}
				else {
					$styleColor = "";
				}

				echo "\t\t\t\t\t\n\t\t\t\t\t<td >\t\t\t\n\t\t\t\t\t\t<nobr><a class='img' href='afficheDossier.php?sNumDossier=";
				echo $data["numDemande"];
				echo "&sIdDossier=";
				echo $data["idDemande"];
				echo "'><img border=0 src='";
				echo imagepath("icoloupe.gif");
				echo "' /></a>\n\t\t\t\t\t\t";

				if (is_array($data["derniereVisu"])) {
					echo "<img border=0 src=\"" . imagepath("icoInfo.gif") . "\" title=\"" . sprintf(_s("Dernier acc�s le %s par %s"), $data["derniereVisu"]["date"], $data["derniereVisu"]["nom"]) . "\" />";
				}

				echo "</nobr>\n\t\t\t\t\t</td> \n\t\t\t\t\t<td align=\"center\">\n\t\t\t\t\t\t<nobr><a style='";
				echo $styleColor;
				echo "' href='afficheDossier.php?sNumDossier=";
				echo $data["numDemande"];
				echo "&sIdDossier=";
				echo $data["idDemande"];
				echo "'>";
				echo $data["numDemande"];
				echo "</a></nobr>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td align=\"center\">\n\t\t\t\t\t\t";
				echo $nomPatient;
				echo "<BR><span class=descrFonce>";
				echo affichedate($data["dateNaissance"]);
				echo "</span>\n\t\t\t\t\t</td>\n\t\t\t\t\t<td align=\"center\" class=\"descr\">";
				echo afficheanalyses($data["analyses"], $filter);
				echo "</td>\n\t\t\t\t\t<td align=\"center\"><NOBR>\n\t\t\t\t\t\t";
				echo getstrdate($data);
				echo "\t\t\t\t\t\t<br />\n\t\t\t\t\t\t</NOBR>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t\t";
			}
		}
	}

	echo "\t</table>\n\n</div>\n\n<div id=\"div_wait\" style=\"display:none;\">\n\t\t<center><img src=\"";
	echo imagepath("wait16.gif");
	echo "\" /></center>\n</div>\t\n";
}
else {
	if (($patientLogged->niveau == "medecin") || ($patientLogged->niveau == "correspondant")) {
		if ($_POST["choix"] == "reset") {
			unset($filter);
			$numDemRecherche = $numIPPRecherche = "";
			if (isset($_SESSION["accesPermalinkLevel"]) && ($_SESSION["accesPermalinkLevel"] == 2)) {
				$numDemRecherche = $_SESSION["accesPermalinkNum"];
				$numIPPRecherche = $_SESSION["accesPermalinkNumIPP"];
			}

			unset($_SESSION["filter"]);
			$_SESSION["filter"]["numDemande"] = $numDemRecherche;
			$_SESSION["filter"]["numIPP"] = $numIPPRecherche;
		}

		if ($_POST["choix"] == "filtrer") {
			$_SESSION["filter"] = $filter = $_POST["filter"];
		}

		if ((isset($_GET["numId"]) && ($_GET["numId"] != "")) || (isset($_GET["numIPP"]) && ($_GET["numIPP"] != ""))) {
			$filter = array("nomPatient" => "", "prenomPatient" => "", "numDemande" => $_GET["numId"], "numIPP" => $_GET["numIPP"], "nomNaissancePatient" => "", "dateNaissance" => "", "dateDebut" => "", "dateFin" => "", "sort" => "", "orderIntervenant" => "");
		}

		if (!isset($filter)) {
			if (isset($_SESSION["filter"])) {
				if (isset($_SESSION["accesPermalinkLevel"]) && ($_SESSION["accesPermalinkLevel"] == 2)) {
					$_SESSION["filter"]["numDemande"] = $_SESSION["accesPermalinkNum"];
					$_SESSION["filter"]["numIPP"] = $_SESSION["accesPermalinkNumIPP"];
				}

				$filter = $_SESSION["filter"];
			}
			else {
				$filter = array("nomPatient" => "", "prenomPatient" => "", "numDemande" => "", "nomNaissancePatient" => "", "dateNaissance" => "", "dateDebut" => date("d-m-Y", time() - 2592000), "dateFin" => date("d-m-Y"), "etat" => "", "codeChapitre" => "", "idMedecin" => "", "idMedecin" => "", "idsCorresp" => "", "sort" => "", "orderIntervenant" => "");
			}
		}
		else {
			if (isset($_SESSION["accesPermalinkLevel"]) && ($_SESSION["accesPermalinkLevel"] == 2)) {
				$filter["numDemande"] = $_SESSION["accesPermalinkNum"];
				$filter["numIPP"] = $_SESSION["accesPermalinkNumIPP"];
			}
		}

		$scd = new SoapClientDemande();
		$params = array("idDemandeur" => $patientLogged->id(), "typeDemandeur" => $patientLogged->niveau, "filtre" => $filter);
		list($listeDemandes, $listeMedecins, $listeCorrespondants, $listeChapitres, $retourSoap) = $scd->getListeDemandeDemandeur($params);
		if ((isset($_GET["numId"]) || isset($_GET["numIPP"])) && (count($listeDemandes) == 1)) {
			klredir("afficheDossier.php?sNumDossier=" . $listeDemandes[0]["numDemande"] . "&sIdDossier=" . $listeDemandes[0]["idDemande"], 0, _s("Redirection en cours ..."));
			affichefoot();
			exit();
		}
		else {
			if ($_SESSION["accesPermalink"] && ($_SESSION["accesPermalinkLevel"] == 0)) {
				$_SESSION["loginError"] = 6;

				if ($patientLogged->isAuth()) {
					$patientLogged->logout();
				}

				klredir("denied.php?type=" . $_SESSION["loginError"], 1, "<span style=\"color:red;\">" . _s("L'authentification a �chou�") . "</span>");
				affichefoot();
				exit();
			}
		}

		affichemessagesil($retourSoap["message"]);
		echo "<H1>" . _s("Liste des demandes") . "</H1>";
		$newListeDemandes = array();

		if ($filter["orderIntervenant"] == 1) {
			$listeDemandeMedecin = array();
			$listeDemandeCorrespondant = array();

			if ($patientLogged->niveau == "medecin") {
				$listeDemandeMedecin["M:" . $patientLogged->nom] = array();
			}
			else if ($patientLogged->niveau == "correspondant") {
				$listeDemandeCorrespondant["C:" . $patientLogged->nom] = array();
			}

			foreach ($listeDemandes as $dem ) {
				if (!empty($dem["medecins"])) {
					foreach ($dem["medecins"] as $med ) {
						$listeDemandeMedecin["M:" . trim($med["identification"])][] = $dem;
					}
				}

				if (!empty($dem["correspondants"])) {
					foreach ($dem["correspondants"] as $cor ) {
						$listeDemandeCorrespondant["C:" . trim($cor["identification"])][] = $dem;
					}
				}
			}

			if ($patientLogged->niveau == "medecin") {
				$newListeDemandes = array_merge($listeDemandeMedecin, $listeDemandeCorrespondant);
			}
			else if ($patientLogged->niveau == "correspondant") {
				$newListeDemandes = array_merge($listeDemandeCorrespondant, $listeDemandeMedecin);
			}
		}
		else {
			foreach ($listeDemandes as $dem ) {
				$newListeDemandes[0][] = $dem;
			}
		}

		aasort($listeMedecins, "identification");
		aasort($listeCorrespondants, "identification");
		$labelNumRecherche = "";
		$valueNumRecherche = "";

		if ($_SESSION["accesPermalinkLevel"] == 2) {
			if ($filter["numDemande"] != "") {
				$labelNumRecherche = _s("ADM");
				$valueNumRecherche = $filter["numDemande"];
			}

			if ($filter["numIPP"] != "") {
				if ($labelNumRecherche != "") {
					$labelNumRecherche .= " / ";
					$valueNumRecherche .= " / ";
				}

				$labelNumRecherche .= _s("IPP");
				$valueNumRecherche .= $filter["numIPP"];
			}
		}
		else {
			$labelNumRecherche = _s("N�Dem/ADM/IPP");
		}

		echo "<FORM id=\"form_filter\" NAME=\"principal\" METHOD=\"POST\" ACTION=\"consultation.php\">\n\t<input id=\"form_choix\" type=\"hidden\" name=\"choix\" value=\"filtrer\" />\n\t<input id=\"filter_sort\" type=\"hidden\" name=\"filter[sort]\" value=\"";
		echo $filter["sort"];
		echo "\" />\n\t";

		if ($_SESSION["accesPermalinkLevel"] == 2) {
			echo " \n\t<INPUT NAME=\"filter[numIPP]\" value=\"";
			echo $filter["numIPP"];
			echo "\" TYPE=\"hidden\" />\n\t";
		}

		echo "\t<table align=\"center\" width=\"98%\">\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Nom usuel");
		echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[nomPatient]\" value=\"";
		echo $filter["nomPatient"];
		echo "\" ";
		echo $_SESSION["accesPermalinkLevel"] == 2 ? "disabled" : "";
		echo " /></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Pr�nom");
		echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[prenomPatient]\" value=\"";
		echo $filter["prenomPatient"];
		echo "\" ";
		echo $_SESSION["accesPermalinkLevel"] == 2 ? "disabled" : "";
		echo "></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo $labelNumRecherche;
		echo "</td>\n\t\t\t<td><INPUT style=\"font-size:11px;width:150px;\" NAME=\"filter[numDemande]\" value=\"";
		echo $filter["numDemande"];
		echo "\" ";
		echo $_SESSION["accesPermalinkLevel"] == 2 ? "TYPE=\"hidden\">" . $valueNumRecherche : "TYPE=\"text\">";
		echo "</td>\t\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Nom naissance");
		echo "</td>\n\t\t\t<td><INPUT size=\"14\" style=\"font-size:11px;\" TYPE=\"text\" NAME=\"filter[nomNaissancePatient]\" value=\"";
		echo $filter["nomNaissancePatient"];
		echo "\" ";
		echo $_SESSION["accesPermalinkLevel"] == 2 ? "disabled" : "";
		echo " /></td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Date naissance");
		echo "</td>\n\t\t\t<td>";
		$argsDateNaissance = array("style" => "font-size:11px;", "id" => "dateNaissance", "name" => "filter[dateNaissance]", "dataType" => "date", "value" => $filter["dateNaissance"]);
		$afficheIconeDate = true;

		if ($_SESSION["accesPermalinkLevel"] == 2) {
			$argsDateNaissance["disabled"] = "disabled";
			$afficheIconeDate = false;
		}

		echo navgetinputdate($argsDateNaissance, true, false, $afficheIconeDate, false, true, "16");
		echo "\t\t\t</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Etat de demande");
		echo "</td>\n\t\t\t<td>\n\t\t\t\t<select name=\"filter[etat]\" style=\"width:150px;font-size:11px;\">\n\t\t\t\t\t<option value=\"tout\" ";
		echo ($filter["etat"] != "enCours") && ($filter["etat"] != "valide") ? "selected" : "";
		echo ">";
		echo _s("Tout");
		echo "</option>\n\t\t\t\t\t<option value=\"enCours\" ";
		echo $filter["etat"] == "enCours" ? "selected" : "";
		echo ">";
		echo _s("En cours");
		echo "</option>\n\t\t\t\t\t<option value=\"valide\" ";
		echo $filter["etat"] == "valide" ? "selected" : "";
		echo ">";
		echo _s("Valid�");
		echo "</option>\n\t\t\t\t</select>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("P�riode du");
		echo "</td>\n\t\t\t<td>";
		echo navgetinputdate(array("style" => "font-size:11px;", "id" => "dateDebut", "name" => "filter[dateDebut]", "dataType" => "date", "value" => $filter["dateDebut"]), true, false, true, false, true, "16");
		echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">&nbsp;";
		echo _s("au");
		echo "</td>\n\t\t\t<td>";
		echo navgetinputdate(array("style" => "font-size:11px;", "id" => "dateFin", "name" => "filter[dateFin]", "dataType" => "date", "value" => $filter["dateFin"]), true, false, true, false, true, "16");
		echo "</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Consultation");
		echo "</td>\n\t\t\t<td>\n\t\t\t\t<select name=\"filter[consulte]\" style=\"width:150px;font-size:11px;\">\n\t\t\t\t\t<option value=\"tout\" ";
		echo ($filter["consulte"] != "pasVu") && ($filter["consulte"] != "dejaVu") ? "selected" : "";
		echo ">Tout</option>\n\t\t\t\t\t<option value=\"pasVu\" ";
		echo $filter["consulte"] == "pasVu" ? "selected" : "";
		echo ">Non consult�</option>\n\t\t\t\t\t<option value=\"dejaVu\" ";
		echo $filter["consulte"] == "dejaVu" ? "selected" : "";
		echo ">D�j� consult�</option>\n\t\t\t\t</select>\n\t\t\t</td>\n\t\t</tr>\n\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
		echo _s("Chapitre");
		echo "</td>\n\t\t\t<td colspan=\"3\">\n\t\t\t\t<select name=\"filter[codeChapitre]\" style=\"width:250px;font-size:11px;\">\n\t\t\t\t\t<option value=\"\">";
		echo _s("Choisissez un chapitre");
		echo "</option>\n\t\t\t\t\t";

		if (is_array($patientLogged->tabChapitre)) {
			foreach ($patientLogged->tabChapitre as $codeChapitre => $nomChapitre ) {
				echo "<option value=\"" . $codeChapitre . "\" " . (isset($filter["codeChapitre"]) && ($filter["codeChapitre"] == $codeChapitre) ? "selected" : "") . ">" . _secho($nomChapitre) . "</option>";
			}
		}
		else {
			foreach ($listeChapitres as $idChapitre => $dataChapitre ) {
				if (!empty($dataChapitre["codeChapitre"])) {
					echo "<option value=\"" . $dataChapitre["codeChapitre"] . "\" " . (isset($filter["codeChapitre"]) && ($filter["codeChapitre"] == $dataChapitre["codeChapitre"]) ? "selected" : "") . ">" . _secho($dataChapitre["nomChapitre"]) . "</option>";
				}
			}
		}

		echo "\t\t\t\t</select>\n\t\t\t</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\"><label for=\"orderIntervenant\">";
		echo _s("Grouper");
		echo "</label></td>\n\t\t\t<td>\n\t\t\t\t<label><input type=\"checkbox\" name=\"filter[orderIntervenant]\" id=\"orderIntervenant\" value=\"1\"  ";
		echo $filter["orderIntervenant"] == 1 ? "CHECKED" : "";
		echo "> ";
		echo _s("par prescripteur");
		echo "</label>\n\t\t\t</td>\n\t\t</tr>\n\t\t";

		if ($patientLogged->niveau == "correspondant") {
			echo "\t\t<tr class=corps>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
			echo _s("M�decin");
			echo "</td>\n\t\t\t<td colspan=\"3\">\n\t\t\t\t<select name=\"filter[idMedecin]\" style=\"width:250px;font-size:11px;\">\n\t\t\t\t\t<option value=\"\">";
			echo _s("Filtrer");
			echo "</option>\n\t\t\t\t\t\n\t\t\t\t\t";

			foreach ($listeMedecins as $id => $data ) {
				echo "\t\t\t\t\t\t<option value=\"";
				echo $id;
				echo "\" ";
				echo isset($filter["idMedecin"]) && ($filter["idMedecin"] == $id) ? "selected" : "";
				echo ">";
				echo _secho($data["identification"]);
				echo "</option>\n\t\t\t\t\t";
			}

			echo "\t\t\t\t</select>\n\t\t\t</td>\n\t\t\t<td class=\"corpsFonce\" align=\"right\">";
			echo _s("Correspondant");
			echo "</td>\n\t\t\t<td>\n\t\t\t\t<select name=\"filter[idCorrespondant]\" style=\"width:150px;font-size:11px;\">\n\t\t\t\t\t<option value=\"\">";
			echo _s("Filtrer");
			echo "</option>\n\t\t\t\t\t";

			foreach ($listeCorrespondants as $id => $data ) {
				echo "\t\t\t\t\t\t<option value=\"";
				echo $id;
				echo "\" ";
				echo isset($filter["idCorrespondant"]) && ($filter["idCorrespondant"] == $id) ? "selected" : "";
				echo ">";
				echo _secho($data["identification"]);
				echo "</option>\n\t\t\t\t\t";
			}

			echo "\t\t\t\t</select>\t\t\t\t\n\t\t\t</td> \n\t\t</tr>\n\t\t";
		}

		echo "\t\t<tr>\n\t\t\t<td colspan=\"4\">\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
		echo _s("Rechercher");
		echo "' onclick=\"clickRecherche();\" />\n\t\t\t\t<INPUT TYPE=\"submit\" VALUE='";
		echo _s("Effacer le filtre");
		echo "' onclick=\"getById('form_choix').value='reset'; clickRecherche();\" />\n\t\t\t</td>\n\t\t</tr>\n\t</table>\n</FORM>\n\n\t\n";
		$nbDemandes = 0;

		if (is_array($newListeDemandes)) {
			$nbDemandes = filterdemandes($newListeDemandes, $filter);
		}

		echo "\n<div id=\"div_content\">\n\t";

		if (100 <= $nbDemandes) {
			echo "<div align='center'>" . _s("L'affichage est limit� � 100 demandes.") . "</div>";
		}

		echo "\t\n\n\t<div align=\"center\">\n\t\t";
		echo sprintf(_s("%s demande(s) trouv�e(s)"), $nbDemandes);
		echo "&nbsp;\n\t\t<span class=\"analyse\">";
		echo _s("CODE");
		echo "</span> : ";
		echo _s("en cours");
		echo " &nbsp;\n\t\t<span class=\"analysevalide\">";
		echo _s("CODE");
		echo "</span> : ";
		echo _s("valid�");
		echo " &nbsp;\n\t\t<span class=\"analysenew\">";
		echo _s("CODE");
		echo "</span> : ";
		echo _s("nouveaux r�sultats");
		echo " &nbsp;\n\t\t<span class=\"analysehorsborne\">";
		echo _s("CODE");
		echo "</span> : ";
		echo _s("hors-borne");
		echo " &nbsp;\n\t</div>\t\t\n\t\t\n\t<table align=center cellpadding=1 cellspacing=1 border=0 width=98% style=\"border:1px solid #ccc;\">\n\t\t<tr class=titreBleu height=22>\n\t\t\t<td colspan=2 width=23%><div onClick=\"setSort('dossier');\" class=hand>";
		echo _s("Demande / ADM");
		echo "&nbsp;\n\t\t\t\t";

		if ($filter["sort"] == "dossier") {
			echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
		}
		else {
			echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
		}

		echo "\t\t\t\t</div>\n\t\t\t</td>\n\t\t\t<td width=25%><div onClick=\"setSort('patient');\" class=hand>";
		echo _s("Patient");
		echo "&nbsp;\n\t\t\t\t";

		if ($filter["sort"] == "patient") {
			echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
		}
		else {
			echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
		}

		echo "\t\t\t\t</div>\n\t\t\t</td>\n\t\t\t<td width=40%>";
		echo _s("Analyses");
		echo "</td>\n\t\t\t<td width=12%><div onClick=\"setSort('date');\" class=hand>";
		echo _s("Date");
		echo " \n\t\t\t\t";
		if (($filter["sort"] == "date") || empty($filter["sort"]) || ($filter["sort"] == "")) {
			echo "\t\t\t\t\t<img src=\"images/flecheBasHover.gif\">\n\t\t\t\t";
		}
		else {
			echo "\t\t\t\t\t<img src=\"images/flecheBas.gif\">\n\t\t\t\t";
		}

		echo "</div>\n\t\t\t</td>\n\t\t</tr>\n\n\n\t\t";
		$iD = 0;
		$_SESSION["listeDemandesSess"] = array();
		$_SESSION["listeDemandesNomSess"] = array();
		$_SESSION["listeDemandesIdSess"] = array();

		foreach ($newListeDemandes as $nomInt => $listeDemandes ) {
			if (($filter["orderIntervenant"] == 1) && !empty($listeDemandes)) {
				echo "\t\t\t\t\t\t<tr class=titre>\n\t\t\t\t\t\t\t<td colspan=5 align=center><b>\n\t\t\t\t\t\t\t\t";

				if ($nomInt[0] == "M") {
					echo "\t\t\t\t\t\t\t\t\t";
					echo _s("M�decin");
					echo " : ";
					echo _secho(substr($nomInt, 2));
					echo "\t\t\t\t\t\t\t\t";
				}
				else if ($nomInt[0] == "C") {
					echo "\t\t\t\t\t\t\t\t\t";
					echo _s("Correspondant");
					echo " : ";
					echo _secho(substr($nomInt, 2));
					echo "\t\t\t\t\t\t\t\t";
				}

				echo "\t\t\t\t\t\t\t</b></td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t";
			}

			if (is_array($listeDemandes)) {
				foreach ($listeDemandes as $key => $data ) {
					$nomPatient = strtoupper($data["nomPatient"]) . " " . ucfirst(strtolower($data["prenomPatient"]));
					$_SESSION["listeDemandesSess"][$iD] = $data["numDemande"];
					$_SESSION["listeDemandesNomSess"][$iD] = $nomPatient;
					$_SESSION["listeDemandesIdSess"][$iD] = $data["idDemande"];
					$iD++;
					$afficheDossierLien = false;
					if (($data["status"] == "valide") || ($data["status"] == "valideValab") || ($patientLogged->getOptionUtilisateur("kaliresNonValide") == 0) || ($patientLogged->getOptionUtilisateur("kaliresNonValide") == 1)) {
						$afficheDossierLien = true;
					}

					echo "\t\t\t\t\t\t<tr style=\"height:25px\" class=\"";
					echo $data["dateVisu"] != "" ? "corps" : "corpsFonce";
					echo "\">\n\t\t\t\t\t\t\t<td>";

					if ($afficheDossierLien) {
						echo "\t\t\t\t\t\t\t\t\t<nobr><a class=\"img\" href=\"afficheDossier.php?sNumDossier=";
						echo $data["numDemande"];
						echo "&sIdDossier=";
						echo $data["idDemande"];
						echo "\"><img border=0 src=\"";
						echo imagepath("icoloupe.gif");
						echo "\" /></a>\n\t\t\t\t\t\t\t\t\t";

						if (is_array($data["derniereVisu"])) {
							$strVisuTitle = sprintf(_s("Dernier acc�s le %s par %s"), $data["derniereVisu"]["date"], $data["derniereVisu"]["nom"]);
							echo "<img border=0 src=\"" . imagepath("icoInfo.gif") . "\" title=\"" . $strVisuTitle . "\" />";
						}

						echo "</nobr>\n\t\t\t\t\t\t\t\t";
					}
					else {
						echo "<img border=0 src=\"" . imagepath("icosablier.gif") . "\" title=\"" . _s("Demande non valid�") . "\" />";
					}

					echo "\t\t\t\t\t\t\t</td> \n\t\t\t\t\t\t\t<td align=\"center\"><nobr>\n\t\t\t\t\t\t\t\t";

					if ($afficheDossierLien) {
						echo "\t\t\t\t\t\t\t\t\t<a style=\"";
						echo 0 < $data["urgent"] ? "color:red" : "";
						echo "\" href=\"afficheDossier.php?sNumDossier=";
						echo $data["numDemande"];
						echo "&sIdDossier=";
						echo $data["idDemande"];
						echo "&chapitreId=";
						echo $data["chapitreId"];
						echo "\">\n\t\t\t\t\t\t\t\t\t\t";
						echo $data["numDemande"];
						echo "\t\t\t\t\t\t\t\t\t</a>\n\t\t\t\t\t\t\t\t";
					}
					else {
						echo "<span style=\"color:#444;\">" . $data["numDemande"] . "</span>";
					}

					echo "\t\t\t\t\t\t\t\t</nobr>\n\t\t\t\t\t\t\t\t<br /><nobr>\n\t\t\t\t\t\t\t\t";
					echo $data["numDemandeExterne"] != "" ? "<span class=descr>" . $data["numDemandeExterne"] . "</span>&nbsp;-&nbsp;" : "";
					echo "\t\t\t\t\t\t\t\t";
					echo getdemandestatusstr($data["status"]);
					echo "</nobr>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t<td align=\"center\">\n\t\t\t\t\t\t\t\t";
					echo $nomPatient . ($data["numChambreExterne"] != "" ? " (ch." . $data["numChambreExterne"] . ")" : "");
					echo "<BR><span class=descrFonce>";
					echo affichedate($data["dateNaissance"]);
					echo "</span>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t\t<td align=\"center\" class=\"descr\">";
					echo afficheanalyses($data["analyses"], $filter);
					echo "</td>\n\t\t\t\t\t\t\t<td align=\"center\"><NOBR>\n\t\t\t\t\t\t\t\t";
					echo getstrdate($data);
					echo "\t\t\t\t\t\t\t\t</NOBR>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t";
				}
			}
		}

		echo "\t</table>\n\n</div>\n\n\n<div id=\"div_wait\" style=\"display:none;\">\n\t\t<center><img src=\"";
		echo imagepath("wait16.gif");
		echo "\" /></center>\n</div>\n\n";
	}
}

echo "\t\n\n";
affichefoot();

?>
